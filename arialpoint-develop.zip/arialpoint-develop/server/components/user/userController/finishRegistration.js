const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");

const finishRegistration = async (req, res, next) => {
    try {
        const { body: { finishRegistrationCode, additionalFields } } = req;

        await UserService.finishRegistration(finishRegistrationCode, additionalFields);

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const finishRegistrationSchema = {
    body: {
        type: "object",
        required: ["finishRegistrationCode", "additionalFields"],
        additionalProperties: false,
        properties: {
            finishRegistrationCode: { type: "string" },
            additionalFields: { type: "object" }
        }
    }
};

module.exports = [
    requestValidation(finishRegistrationSchema),
    finishRegistration
];