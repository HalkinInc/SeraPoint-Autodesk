const request = require("supertest");
const expect = require("expect");

const { server } = require("../../../../server");
const { users } = require("./seeds");

it("error if user id is invalid", async () => {
    const { body: { value, errors } } = await request(server)
        .patch("/user/12345")
        .set("Authorization", users[1].jwt)
        .send({ email: "patched email" });

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'params/id' should be valid 'objectId'");

    expect(value).not.toBeDefined();
});

it("user:edit:any can edit another user", async () => {
    const { body: { value, errors } } = await request(server)
        .patch(`/user/${users[3]._id.toString()}`)
        .set("Authorization", users[0].jwt)
        .send({ email: "patched email" });

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value).toBe(true);
});

it("user:edit:own can edit himself", async () => {
    const { body: { value, errors } } = await request(server)
        .patch(`/user/${users[3]._id.toString()}`)
        .set("Authorization", users[3].jwt)
        .send({ email: "patched email" });

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value).toBe(true);
});

it("user:edit:own can't edit another user", async () => {
    const { body: { value, errors } } = await request(server)
        .patch(`/user/${users[3]._id.toString()}`)
        .set("Authorization", users[1].jwt)
        .send({ email: "patched email" });

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Permission denied");

    expect(value).not.toBeDefined();
});

it("root can reasign role to another admin", async () => {
    const { body: { value, errors } } = await request(server)
        .patch(`/user/${users[0]._id.toString()}?newRootId=${users[10]._id.toString()}`)
        .set("Authorization", users[0].jwt);

    expect(errors.length).toBe(0);

    expect(value).toBeTruthy();
});

it("moderator:update:any can reassign moderator role to another tenant user", async () => {
    const { body: { value, errors } } = await request(server)
        .patch(`/user/${users[1]._id.toString()}?newModeratorId=${users[3]._id.toString()}`)
        .set("Authorization", users[0].jwt);

    expect(errors.length).toBe(0);

    expect(value).toBeTruthy();
});