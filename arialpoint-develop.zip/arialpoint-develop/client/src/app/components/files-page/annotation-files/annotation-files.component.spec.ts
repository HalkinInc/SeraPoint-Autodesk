import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnotationFilesComponent } from './annotation-files.component';

describe('AnnotationFilesComponent', () => {
  let component: AnnotationFilesComponent;
  let fixture: ComponentFixture<AnnotationFilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnnotationFilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnnotationFilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
