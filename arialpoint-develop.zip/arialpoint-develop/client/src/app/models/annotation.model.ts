export class Annotation {
  constructor(
    public blockIndex?: string,
    public createdAt?: number,
    public creatorFirstname?: string,
    public creatorId?: string,
    public creatorLastname?: string,
    public deleted?: boolean,
    public dxfFileId?: string,
    public dxfFileName?: string,
    public fileName?: string,
    public fileSize?: number,
    public hasFile?: boolean,
    public name?: string,
    public screenshot?: string,
    public select?: boolean,
    public tenantId?: string,
    public tenantName?: string,
    public text?: string,
    public _id?: string
  ) {}
}
