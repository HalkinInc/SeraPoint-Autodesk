import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReassignRoleDialogComponent } from './reassign-role-dialog.component';

describe('ReassignRoleDialogComponent', () => {
  let component: ReassignRoleDialogComponent;
  let fixture: ComponentFixture<ReassignRoleDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReassignRoleDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReassignRoleDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
