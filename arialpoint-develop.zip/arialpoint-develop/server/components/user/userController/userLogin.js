const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");

const userLogin = async (req, res, next) => {
    try {
        const { body: { password, email } } = req;

        const jwt = await UserService.loginUser(email, password);

        return res.send({ errors: [], value: jwt });
    } catch (error) { return next(error); }
};
const userLoginSchema = {
    body: {
        type: "object",
        required: ["email", "password"],
        additionalProperties: false,
        properties: {
            // required
            email: { type: "string" },
            password: { type: "string" }
        }
    }
};

module.exports = [
    requestValidation(userLoginSchema),
    userLogin
];