import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-files-page',
  templateUrl: './files-page.component.html',
  styleUrls: [ './files-page.component.scss' ]
})
export class FilesPageComponent implements OnInit {
  navLinks = [
    { label: 'Properties', link: './properties', index: 0 },
    { label: 'Annotation', link: './annotation-files', index: 1 }
  ];
  activeLinkIndex = 0;

  constructor(private router: Router) {}

  ngOnInit() {
    this.router.events.subscribe(() => {
      this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find(tab => tab.link === '.' + this.router.url));
    });
  }
}
