import { ForgotPasswordPage } from './forgot-password.po';
import { sendSeeds } from './seeds';

describe('Forgot password', () => {
    let page: ForgotPasswordPage;

    beforeEach(async () => {
        page = new ForgotPasswordPage();
        await sendSeeds();
    });

    describe('Step 1:', () => {
        it('should redirect to step 2 if email is correct', () => {
            page.navigateTo();
            page.enterEmail('pm@code-care.pro');
            expect(page.isStepTwo()).toBeTruthy();
        });


    });

    describe('Step 2:', () => {
        it('should redirect to step 3 if answer is entered', () => {
            page.navigateTo();
            page.enterEmail('pm@code-care.pro');
            page.enterAnswer('moose');
            expect(page.isStepTree()).toBeTruthy();
        });

        it('should redirect from step 2 to step 1 if back button is clicked', () => {
            page.navigateTo();
            page.enterEmail('pm@code-care.pro');
            page.moveBackFromStepTwoToStepOne();
            expect(page.isStepOne()).toBeTruthy();
        });
    });

    describe('Step 3:', () => {
        it('should redirect to step four if password is entered', () => {
            page.navigateTo();
            page.enterEmail('pm@code-care.pro');
            page.enterAnswer('moose');
            page.enterPassword('password');
            expect(page.isStepFour()).toBeTruthy();
        });

        it('should error message if new password field is empty', () => {
            page.navigateTo();
            page.enterEmail('pm@code-care.pro');
            page.enterAnswer('moose');
            page.enterPassword('');
            expect(page.errorMessageSnackbar()).toBe('\'body/password\' should NOT be shorter than 6 characters');
        });

        it('should redirect from step 3 to step 2 if back button is clicked', () => {
            page.navigateTo();
            page.enterEmail('pm@code-care.pro');
            page.enterAnswer('moose');
            page.moveBackFromStepThreeToStepTwo();
            expect(page.isStepTwo()).toBeTruthy();
        });
    });

    describe('Step 4:', () => {
        it('should redirect login page if return to login button is clicked', () => {
            page.navigateTo();
            page.enterEmail('pm@code-care.pro');
            page.enterAnswer('moose');
            page.enterPassword('password');
            page.clickOnReturnToLogin();
            expect(page.isLoginPage()).toBeTruthy();
        });

        it('should redirect from step 4 to step 3 if back button is clicked', () => {
            page.navigateTo();
            page.enterEmail('pm@code-care.pro');
            page.enterAnswer('moose');
            page.enterPassword('password');
            page.moveBackFromStepFourToStepThree();
            expect(page.isStepTree()).toBeTruthy();
        });
    });
});
