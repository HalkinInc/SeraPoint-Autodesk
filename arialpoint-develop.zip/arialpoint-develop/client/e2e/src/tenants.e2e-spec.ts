import { TenantsPage } from './tenants.po';
import { sendSeeds } from './seeds';

describe('Tenants', () => {
    let page: TenantsPage;

    beforeEach(async () => {
        page = new TenantsPage();
        await sendSeeds();
    });

    describe('Delete', () => {
        describe('Root', () => {
            it('should delete tenant if root clicked yes in popup', () => {
                page.navigateToAsRoot();
                page.clickDeleteButton('code-care');
                page.clickOkButton();
                expect(page.doesTenantExist('code-care')).toBeFalsy();
            });

            it('should NOT delete tenant if root clicked no in popup', () => {
                page.navigateToAsRoot();
                page.clickDeleteButton('code-care');
                page.clickNoButton();
                expect(page.doesTenantExist('code-care')).toBeTruthy();
            });
        });

        describe('Admin', () => {
            it('should delete tenant if admin clicked yes in popup', () => {
                page.navigateToAsAdmin();
                page.clickDeleteButton('code-care');
                page.clickOkButton();
                expect(page.doesTenantExist('code-care')).toBeFalsy();
            });

            it('should NOT delete tenant if admin clicked no in popup', () => {
                page.navigateToAsAdmin();
                page.clickDeleteButton('code-care');
                page.clickNoButton();
                expect(page.doesTenantExist('code-care')).toBeTruthy();
            });
        });
    });

    it('should show tooltip on loop icon hover', () => {
        page.navigateToAsRoot();
        page.hoverLoopIcon('code-care');
        expect(page.doesTooltipVisible('Click to view current tenant information')).toBeTruthy();
    });

    it('should redirect to tenant page if loop icon is clicked', () => {
        page.navigateToAsRoot();
        page.clickLoopIcon('code-care');
        expect(page.isTenantPage()).toBeTruthy();
    });

    it('should show tooltip on arrow icon hover', () => {
        page.navigateToAsRoot();
        page.hoverArrowIcon('code-care');
        expect(page.doesTooltipVisible('Click to upload DXF file')).toBeTruthy();
    });

    it('should upload dxf file', () => {
        page.navigateToAsRoot();
        page.clickArrowIcon('code-care');
        page.browseFile();
        page.clickSaveButton();
        expect(page.getDxfFilesCount('code-care')).toBe('2');
    });
});
