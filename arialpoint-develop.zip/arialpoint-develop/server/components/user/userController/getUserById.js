const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const getUserById = async (req, res, next) => {
    try {
        const { authUser, params: { id } } = req;

        const foundUser = await UserService.getUserById(id);

        if (authUser.permissions.includes("user:read:tenant") && authUser.tenantId !== foundUser.tenantId) throw new appErrors.AuthorizationError();

        return res.send({ errors: [], value: [foundUser] });
    } catch (error) { return next(error); }
};

const getUserByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true },
        }
    }
};

module.exports = [
    authorization(["user:read:any", "user:read:tenant"]),
    requestValidation(getUserByIdSchema),
    getUserById
];