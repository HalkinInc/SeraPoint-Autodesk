const request = require("supertest");
const expect = require("expect");
const { ObjectId } = require("mongodb");

const { server, db } = require("../../../../server");
const { users, tenants } = require("./seeds");

it("error if user id is not valid", async () => {
    const userId = "1234567890";
    const url = `/user/${userId}`;
    const token = users[0].jwt;

    const response = await request(server).delete(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'params/id' should be valid 'objectId'");

    expect(value).not.toBeDefined();
});

it("error if user id is valid but user doesn't exists", async () => {
    const userId = ObjectId().toString();
    const url = `/user/${userId}`;
    const token = users[0].jwt;

    const response = await request(server).delete(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("User not found");

    expect(value).not.toBeDefined();
});

it("root can't be deleted", async () => {
    const userId = users[0]._id.toString();
    const url = `/user/${userId}`;
    const token = users[0].jwt;

    const response = await request(server).delete(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Permission denied");

    expect(value).not.toBeDefined();
});

it("user:delete:any can delete any user", async () => {
    const userId = users[3]._id.toString();
    const url = `/user/${userId}`;
    const token = users[0].jwt;

    const response = await request(server).delete(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(0);

    expect(value).toBe(true);

    const userCollection = await (await db).collection("users");
    const foundUser = await userCollection.findOne({ _id: users[3]._id });

    expect(foundUser.deleted).toBe(true);
});

it("moderator:delete:any can delete moderator if new tenant moderator is provided", async () => {
    const userId = users[1]._id.toString();
    const url = `/user/${userId}?newModeratorId=${users[8]._id.toString()}`;
    const token = users[0].jwt;

    const response = await request(server).delete(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(0);

    expect(value).toBe(true);

    const userCollection = await (await db).collection("users");
    const foundUser = await userCollection.findOne({ _id: users[8]._id });

    expect(foundUser.tenantId).toBe(tenants[0]._id.toString());
});

it("moderator:delete:any can't delete moderator if new tenant moderator is not provided", async () => {
    const userId = users[1]._id.toString();
    const url = `/user/${userId}`;
    const token = users[0].jwt;

    const response = await request(server).delete(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("New moderator id is not provided");

    expect(value).not.toBeDefined();
});

it("user:delete:tenant can delete user of his tenant", async () => {
    const userId = users[5]._id.toString();
    const url = `/user/${userId}`;
    const token = users[1].jwt;

    const response = await request(server).delete(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(0);

    expect(value).toBe(true);

    const userCollection = await (await db).collection("users");
    const foundUser = await userCollection.findOne({ _id: users[5]._id });

    expect(foundUser.deleted).toBe(true);
});

it("user:delete:tenant can't delete user of not his tenant", async () => {
    const userId = users[7]._id.toString();
    const url = `/user/${userId}`;
    const token = users[1].jwt;

    const response = await request(server).delete(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Permission denied");

    expect(value).not.toBeDefined();
});

it("user with no permission to delete can't delete another user", async () => {
    const userId = users[1]._id.toString();
    const url = `/user/${userId}`;
    const token = users[3].jwt;

    const response = await request(server).delete(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Permission denied");

    expect(value).not.toBeDefined();
});

it("can hard delete user", async () => {
    const { body: { value, errors } } = await request(server)
        .delete(`/user/${users[3]._id.toString()}?method=hard`)
        .set("Authorization", users[0].jwt);

    expect(errors.length).toBe(0);

    expect(value).toBe(true);

    const userCollection = await (await db).collection("users");
    const foundUser = await userCollection.findOne({ _id: users[3]._id });

    expect(foundUser).toBeNull();
});