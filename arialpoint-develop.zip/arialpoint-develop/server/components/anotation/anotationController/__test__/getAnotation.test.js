const assert = require("assert");

const request = require("supertest");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { dxfFiles, users, anotations, tenants } = require("./seed");

it("error if dxf file id is invalid", async () => {
    const { body: { errors, value } } = await request(server)
        .get("/anotation?dxfFileId=123")
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'query/dxfFileId' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if dxf file with provided id not exists", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?dxfFileId=${ObjectId().toString()}`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Dxf file not found");

    assert.strictEqual(value, undefined);
});

it("error if dxf file with provided is deleted", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?dxfFileId=${dxfFiles[2]._id.toString()}`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Dxf file was deleted");

    assert.strictEqual(value, undefined);
});

it("error if created by id is invalid", async () => {
    const { body: { errors, value } } = await request(server)
        .get("/anotation?creatorId=123")
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'query/creatorId' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if user with created by id not exists", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?creatorId=${ObjectId().toString()}`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "User not found");

    assert.strictEqual(value, undefined);
});

it("error if user with created by id is deleted", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?creatorId=${users[3]._id.toString()}`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "User was deleted");

    assert.strictEqual(value, undefined);
});

it("error if tenant id is invalid", async () => {
    const { body: { errors, value } } = await request(server)
        .get("/anotation?tenantId=123")
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'query/tenantId' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if tenant is not exists", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?tenantId=${ObjectId().toString()}`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Tenant not found");

    assert.strictEqual(value, undefined);
});

it("should return tenant anotations without deleted if tenant id is provided", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?tenantId=${tenants[0]._id.toString()}`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value.length, 3);
});

it("should return tenant deleted anotations", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?tenantId=${tenants[0]._id.toString()}&deleted=true`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value.length, 1);
});

it("anotation:read:any can get anotations of dxf file", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?dxfFileId=${dxfFiles[0]._id.toString()}`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value[0].name, anotations[0].name);
});

it("anotation:read:any can get deleted anotations of dxf file", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?dxfFileId=${dxfFiles[0]._id.toString()}&deleted=true`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value[0].name, anotations[3].name);
});

it("anotation:get:any can get anotations of user", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?creatorId=${users[2]._id.toString()}`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value[0].name, anotations[1].name);
});

it("anotation:get:any can get deleted anotations of user", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?creatorId=${users[2]._id.toString()}&deleted=true`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value[0].name, anotations[3].name);
});

it("anotation:read:any can get anotations of user and dxfile", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?creatorId=${users[1]._id.toString()}&dxfFileId=${dxfFiles[0]._id.toString()}`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value[0].name, anotations[0].name);
});

it("anotation:read:any can get deleted anotations of user and dxfile", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?creatorId=${users[1]._id.toString()}&dxfFileId=${dxfFiles[0]._id.toString()}&deleted=true`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value[0].name, anotations[3].name);
});

it("anotation:read:tenant can get anotations of dxf file of his tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?dxfFileId=${dxfFiles[0]._id.toString()}`)
        .set("authorization", users[1].jwt);

    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value[0].name, anotations[0].name);
});

it("anotation:read:tenant can get deleted anotations of dxf file of his tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?dxfFileId=${dxfFiles[0]._id.toString()}&deleted=true`)
        .set("authorization", users[1].jwt);

    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value[0].name, anotations[3].name);
});

it("anotation:read:tenant can get anotations of user of his tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?creatorId=${users[2]._id.toString()}`)
        .set("authorization", users[1].jwt);

    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value[0].name, anotations[1].name);
});

it("anotation:read:tenant can get deleted anotations of user of his tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?creatorId=${users[2]._id.toString()}&deleted=true`)
        .set("authorization", users[1].jwt);

    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value[0].name, anotations[3].name);
});

it("anotation:read:tenant can get anotations of user and dxfile of his tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?creatorId=${users[1]._id.toString()}&dxfFileId=${dxfFiles[0]._id.toString()}`)
        .set("authorization", users[0].jwt);

    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value[0].name, anotations[0].name);
});

it("anotation:read:tenant can't get anotations of dxf file of not his tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?dxfFileId=${dxfFiles[1]._id.toString()}`)
        .set("authorization", users[1].jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("anotation:read:tenant can't get anotations of user of not his tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?creatorId=${users[4]._id.toString()}`)
        .set("authorization", users[1].jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("anotation:read:tenant can't get anotations of user and dxfile of not his tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/anotation?creatorId=${users[4]._id.toString()}&dxfFileId=${dxfFiles[1]._id.toString()}`)
        .set("authorization", users[1].jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});