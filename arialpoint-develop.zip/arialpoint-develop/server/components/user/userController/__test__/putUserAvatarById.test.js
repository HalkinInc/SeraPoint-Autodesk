const path = require("path");

const request = require("supertest");
const expect = require("expect");

const { server } = require("../../../../server");
const { users } = require("./seeds");

it("error if user id is invalid", async () => {
    const { body: { value, errors } } = await request(server)
        .put("/user/asd/avatar")
        .set("Authorization", users[1].jwt)
        .attach("avatar", path.resolve(__dirname, "avatar.png"));

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'params/id' should be valid 'objectId'");

    expect(value).not.toBeDefined();
});

it("error if multipart boundary is not provided", async () => {
    const { body: { value, errors } } = await request(server)
        .put(`/user/${users[2]._id.toString()}/avatar`)
        .set("Authorization", users[0].jwt);

    expect(errors).toBeDefined();
    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'Content-Type' should be 'multipart/form-data'");

    expect(value).not.toBeDefined();
});

it("error if avatar file is not provided", async () => {
    const { body: { value, errors } } = await request(server)
        .put(`/user/${users[2]._id.toString()}/avatar`)
        .set("Authorization", users[0].jwt)
        .field("avatar", "avatar");

    expect(errors).toBeDefined();
    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'formData/avatar' should be a file");

    expect(value).not.toBeDefined();
});

it("error if invalid avatar file format", async () => {
    const { body: { value, errors } } = await request(server)
        .put(`/user/${users[3]._id.toString()}/avatar`)
        .set("Authorization", users[3].jwt)
        .attach("avatar", path.resolve(__dirname, "avatar.notPng"));

    expect(errors).toBeDefined();
    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'formData/avatar' should have ['.png', '.jpg', '.jpeg'] file extension");

    expect(value).not.toBeDefined();
});


it("user:edit:any can put any user avatar", async () => {
    const { body: { value, errors } } = await request(server)
        .put(`/user/${users[3]._id.toString()}/avatar`)
        .set("Authorization", users[0].jwt)
        .attach("avatar", path.resolve(__dirname, "avatar.png"));

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value).toBe(true);
});

it("user:edit:own can put his avatar", async () => {
    const { body: { value, errors } } = await request(server)
        .put(`/user/${users[3]._id.toString()}/avatar`)
        .set("Authorization", users[3].jwt)
        .attach("avatar", path.resolve(__dirname, "avatar.png"));

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value).toBe(true);
});

it("user:edit:own can't put not his avatar", async () => {
    const { body: { value, errors } } = await request(server)
        .put(`/user/${users[3]._id.toString()}/avatar`)
        .set("Authorization", users[1].jwt)
        .attach("avatar", path.resolve(__dirname, "avatar.png"));

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Permission denied");

    expect(value).not.toBeDefined();
});
