import { Component, OnInit } from '@angular/core';
import { DXFFilesService } from '../../../services/dxffiles.service';
import { Location } from '@angular/common';
import { UsersService } from '../../../services/users.service';
import { DXFFile } from '../../../models/dxf.model';
import { SettingsService } from '../../../services/settings.service';

@Component({
  selector: 'app-delete-dxffiles',
  templateUrl: './delete-dxffiles.component.html',
  styleUrls: ['./delete-dxffiles.component.scss']
})
export class DeleteDxffilesComponent implements OnInit {
  dxfFiles: Array<DXFFile> = new Array();
  searchDXF: string;
  tenantId: string;
  daysToDelete = 30;
  currentUserRole: string;

  constructor(
    private location: Location,
    private usersService: UsersService,
    private dxfFilesService: DXFFilesService,
    private settingsService: SettingsService) { }

  ngOnInit() {
    this.getUser();
  }

  getUser() {
    this.usersService.getUser().subscribe((res) => {
      if (res.value.tenantId) {
        this.tenantId = res.value.tenantId;
      }
      this.currentUserRole = res.value.role;
      this.getSettings();
      this.getDeleteDXFFiles(this.tenantId);
    });
  }

  getSettings() {
    this.settingsService.getSettings().subscribe((result) => {
      if (result.value) {
        this.daysToDelete = result.value.deletedDxfFilesDaysLimit;
      }
    });
  }

  getDeleteDXFFiles(tenantId: string, search?: string) {
    this.dxfFilesService.getDeleteDXFFiles(tenantId).subscribe((res) => {
      if (res.errors.length === 0) {
        let result = res.value;
        result.map(element => {
          element['select'] = false;
        });
        if (search) {
          search = search.toLowerCase();
          result = result.filter((item) => {
            return item ? (item.fileName.toLowerCase().indexOf(search) >= 0) : false;
          });
        }
        this.dxfFiles = result;
      }
    });
  }

  back() {
    this.location.back();
  }

  search(search: string) {
    this.getDeleteDXFFiles(this.tenantId, search);
  }

  onRestoreSelect() {
    const selectedDXF = this.dxfFiles.filter((file) => {
      return file.select;
    });
    if (selectedDXF.length > 0) {
      selectedDXF.filter((element) => {
        this.dxfFilesService.editDXF(element._id, { deleted: false }).subscribe((res) => {
          if (res.value) {
            this.getDeleteDXFFiles(this.tenantId);
          }
        });
      });
    }
  }

  changeDaysToDelete(days: number) {
    this.settingsService.updateSettings('deletedDxfFilesDaysLimit', days).subscribe((res) => {
      this.getSettings();
    });
  }

  trackByFn(index, item) {
    return item.id;
  }
}
