import { InviteDialog, Roles } from './invite.po';
import { sendSeeds } from './seeds';
import { browser, protractor } from 'protractor';

describe('Invite dialog', () => {
    let dialog: InviteDialog;

    beforeEach(async () => {
        dialog = new InviteDialog();
        await sendSeeds();
    });

    it('moderator can invite user', () => {
        dialog.navigateToAsModerator();
        dialog.addDetails('New', 'User', 'newuser@gmail.com', null, Roles.user);
        dialog.navigateToSendInviteStep();
        dialog.enterMessage('Hello, New User!');
        dialog.sendInvite();
        expect(dialog.isUserExists('New', 'User')).toBeTruthy();
    });

    describe('Firstname and Lastname fields:', () => {
        it('should send invite if fill in correct value in Firstname and Lastname field', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'Admin', 'newadmin@gmail.com', null, Roles.admin);
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, New Admin!');
            dialog.sendInvite();
            expect(dialog.isUserExists('New', 'Admin')).toBeTruthy();
        });

        it('should alert if Firstname is empty field', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            expect(dialog.getFirstnameErrorValue()).toBe('You must enter a first name');
        });

        it('should alert if Firstname has spaces in name', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails(' New user ', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            expect(dialog.getFirstnameErrorValue()).toBe('The first name contains illegal characters');
        });

        it('should alert if Firstname has special symbols', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('!"@#$^%^&*()_+=?/.,}{][', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            expect(dialog.getFirstnameErrorValue()).toBe('The first name contains illegal characters');
        });

        it('should alert if Firstname has numbers', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('new1234user', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            expect(dialog.getFirstnameErrorValue()).toBe('The first name contains illegal characters');
        });

        it('should send invite if First name length equal 63 symbols', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('Newaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
             'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, New Admin!');
            dialog.sendInvite();
            expect(dialog.isUserExists('New', 'Admin')).toBeTruthy();
        });

        it('should send invite if First name length equal 1 symbols', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('N', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, New Admin!');
            dialog.sendInvite();
            expect(dialog.isUserExists('New', 'Admin')).toBeTruthy();
        });

        it('should send invite if First name has \'-\' symbol', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New-User', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, New Admin!');
            dialog.sendInvite();
            expect(dialog.isUserExists('New', 'Admin')).toBeTruthy();
        });

        it('should alert if Firstname has \'.\' symbol', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('NewUser.', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            expect(dialog.getFirstnameErrorValue()).toBe('The first name contains illegal characters');
        });

        it('should alert if Firstname empty and last name empty', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('', '', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            expect(dialog.getFirstnameErrorValue()).toBe('You must enter a first name');
            expect(dialog.getLastnameErrorValue()).toBe('You must enter a last name');
        });
    });

    describe('Check email:', () => {
        it('should alert if field is empty', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'User', '', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            expect(dialog.getEmailErrorValue()).toBe('You must enter a email');
        });

        it('should alert if fill in incorrect value email', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'User', 'Alex123.!-_@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            expect(dialog.getEmailErrorValue()).toBe('The email contains illegal characters');
        });
    });

    describe('Check Tenant:', () => {
        it('should send invite after edit Tenant field', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.editTenantField('gmail');
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, New Admin!');
            dialog.sendInvite();
            expect(dialog.isTenantEdit('gmail')).toBeTruthy();
        });

        it('tenant field is automatically filled out with the tenant name Moderator belongs to', () => {
            dialog.navigateToAsModerator();
            expect(dialog.getTenantInputValue()).toBe('code-care');
        });

        it('moderator can\'t edit tenant field', () => {
            dialog.navigateToAsModerator();
            expect(dialog.tenantInput.getAttribute('disabled')).toBeTruthy();
        });

        it('moderator has\'t have empty field', () => {
            dialog.navigateToAsModerator();
            expect(dialog.getTenantInputValue().then(text => {
                return text.length > 0;
            })).toBeTruthy();
        });
    });

    describe('Check Role:', () => {
        it('should display dropdown menu after click', () => {
            dialog.navigateToAsRoot();
            dialog.rolesSelect.click();
            expect(dialog.isRoleOptionVisible);
        });

        it('root can invite admin', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'Admin', 'newadmin@gmail.com', null, Roles.admin);
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, New Admin!');
            dialog.sendInvite();
            expect(dialog.isUserExists('New', 'Admin')).toBeTruthy();
        });

        it('admin can invite admin', () => {
            dialog.navigateToAsAdmin();
            dialog.addDetails('New', 'Admin', 'newadmin@gmail.com', null, Roles.admin);
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, New Admin!');
            dialog.sendInvite();
            expect(dialog.isUserExists('New', 'Admin')).toBeTruthy();
        });

        it('Tenant field should be empty by default', () => {
            dialog.navigateToAsRoot();
            expect(dialog.getTenantInputValue().then(text => {
                return text.length === 0;
            })).toBeTruthy();
        });

        it('root can invite moderator', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'Moderator', 'newmoderator@thiswillbetenantname.com', null, Roles.moderator);
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, New Moderator!');
            dialog.sendInvite();
            expect(dialog.isUserExists('New', 'Moderator')).toBeTruthy();
        });

        it('admin can invite moderator', () => {
            dialog.navigateToAsAdmin();
            dialog.addDetails('New', 'Moderator', 'newmoderator@thiswillbetenantname.com', null, Roles.moderator);
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, New Moderator!');
            dialog.sendInvite();
            expect(dialog.isUserExists('New', 'Moderator')).toBeTruthy();
        });

        it('Tenant field is should automatically field in with domain name of Moderator\'s email and field is editable', () => {
            dialog.navigateToAsRoot();
            dialog.editEmailField('newmoderator@thiswillbetenantname.com');
            expect(dialog.getTenantInputValue()).toBe('thiswillbetenantname');
        });

        it('should alert message if check moderator role and tenant field stay empty', async () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'Moderator', 'newmoderator@thiswillbetenantname.com', null, Roles.moderator);
            dialog.tenantInput.clear();
            dialog.tenantInput.sendKeys('a');
            dialog.tenantInput.sendKeys(protractor.Key.BACK_SPACE);
            expect(dialog.getTenantErrorValue()).toBe('You must enter a tenant name');
        });

        it('root can invite user', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, New User!');
            dialog.sendInvite();
            expect(dialog.isUserExists('New', 'User')).toBeTruthy();
        });

        it('admin can invite user', () => {
            dialog.navigateToAsAdmin();
            dialog.addDetails('New', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, New User!');
            dialog.sendInvite();
            expect(dialog.isUserExists('New', 'User')).toBeTruthy();
        });

        it('tenant field is automatically filled automatically filled in with Standard User', () => {
            dialog.navigateToAsModerator();
            dialog.addDetails('New', 'User', 'newuser@gmail.com', null, Roles.user);
            expect(dialog.getTenantInputValue()).toBe('code-care');
        });

        it('should redirects to screen Send Invite after click on next button', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            expect(dialog.isSendInviteStep()).toBeTruthy();
        });
    });

    describe('Send Invite:', () => {
        it('fill in the text input field with text, numbers and special symbols', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            dialog.enterMessage('Hello, 123 !"@#$^%^&*()_+=?/.,}{][\'!');
            dialog.sendInvite();
            expect(dialog.isUserExists('New', 'Admin')).toBeTruthy();
        });

        it('select "Send Invite" button', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            dialog.sendInvite();
            expect(dialog.inviteDialog()).toBeFalsy();
            expect(dialog.isUserExists('New', 'Admin')).toBeTruthy();
        });

        it('should redirects to Add Details tab after click on Back button', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            dialog.navigateToAddInvitesStep();
            expect(dialog.isAddDetailsStep()).toBeTruthy();
        });

        it('should close the pop up window after click on Close button', () => {
            dialog.navigateToAsRoot();
            dialog.addDetails('New', 'User', 'newuser@gmail.com', 'code-care', Roles.user);
            dialog.navigateToSendInviteStep();
            dialog.closeInviteModal();
            expect(dialog.inviteDialog()).toBeFalsy();
        });
    });
});
