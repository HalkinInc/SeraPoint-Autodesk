const CronJob = require("cron").CronJob;

const logger = require("../utils/logger");
const DxfFileService = require("../components/dxfFile/dxfFileService");
const DxfFileModel = require("../components/dxfFile/dxfFileModel");
const SettingsModel = require("../components/aux/settingsModel");

const UNIX_DAY_MIL = 86400000;

module.exports = new CronJob("0 3 * * *", async () => {
    try {
        const { deletedDxfFilesDaysLimit: DAYS_AGO } = await SettingsModel.findOne({ name: "main" });
        const limit = Date.now() - UNIX_DAY_MIL * DAYS_AGO;
        const filesToDelete = await DxfFileModel.findMany({ deletedAt: { $lte: limit } });
        await Promise.all(filesToDelete.map(async (file) => {
            await DxfFileService.deleteFileFromS3AndAutodesk(file.fileKey);
            await DxfFileModel.deleteOne({ _id: file._id });
        }));
        logger.info(`Dxf files flagged as deleted ${DAYS_AGO} days ago removed from database, S3 and AutoDesk`);
    } catch (error) { logger.error(error, "Error while deleting dxf files flagged as deleted from database, S3 and AutoDesk"); }
});