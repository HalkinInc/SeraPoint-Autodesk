export class DialogData {
  constructor(
    public firstName?: string,
    public lastName?: string,
    public email?: string,
    public tenant?: string,
    public role?: string,
    public message?: string
  ) {}
}
