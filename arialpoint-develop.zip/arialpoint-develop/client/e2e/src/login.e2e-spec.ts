import { browser } from 'protractor';
import { LoginPage } from './login.po';
import { sendSeeds } from './seeds';

describe('Login', () => {
  let page: LoginPage;

  beforeEach(async () => {
    page = new LoginPage();
    await sendSeeds();
  });

  it('should successfuly log in with correct login and correct password', () => {
    page.navigateTo();
    page.enterCredentials('pm@code-care.pro', 'password');
    expect(browser.getCurrentUrl()).toContain('/dashboard/peoples');
  });

  it('should alert login and password error messages if login and password fields are empty', () => {
    page.navigateTo();
    page.enterCredentials('', '');
    expect(page.getEmailErrorValue()).toBe('Please enter your email');
    expect(page.getPasswordErrorValue()).toBe('Please enter your password');
  });

  it('should alert login error message if login field is empty and password is filled', () => {
    page.navigateTo();
    page.enterCredentials('', 'password');
    expect(page.getEmailErrorValue()).toBe('Please enter your email');
    expect(page.isPasswordErrorVisible()).toBeFalsy();
  });

  it('should alert password error message if password field is empty and login is filled', () => {
    page.navigateTo();
    page.enterCredentials('pm@code-care.pro', '');
    expect(page.getPasswordErrorValue()).toBe('Please enter your password');
    expect(page.isLoginErrorVisible()).toBeFalsy();
  });

  it('should error snackbar message if correct login and wrong password', () => {
    page.navigateTo();
    page.enterCredentials('pm@code-care.pro', 'passwerd');
    expect(page.errorMessageSnackbar()).toBe('Password is invalid');
  });

  it('should error snackbar message if wrong login and correct password', () => {
    page.navigateTo();
    page.enterCredentials('pm1@code-care.pro', 'password');
    expect(page.errorMessageSnackbar()).toBe('User not found');
  });

  it('should error snackbar message if wrong login and wrong password', () => {
    page.navigateTo();
    page.enterCredentials('pm1@code-care.pro', 'passwerd');
    expect(page.errorMessageSnackbar()).toBe('User not found');
  });

  it('should error snackbar message if login filed with correct password and password field with correct login', () => {
    page.navigateTo();
    page.enterCredentials('password', 'pm@code-care.pro');
    expect(page.getPasswordErrorValue()).toBe('A password must be no more than 10 characters');
    expect(page.isLoginErrorVisible());
    expect(page.isPasswordErrorVisible());
  });

  it('should error snackbar message if correct login and password has different register letters', () => {
    page.navigateTo();
    page.enterCredentials('pm@code-care.pro', 'PaSsWoRd');
    expect(page.errorMessageSnackbar()).toBe('Password is invalid');
  });

  it('should error snackbar message if login has different register letters and correct password', () => {
    page.navigateTo();
    page.enterCredentials('PM@CODE-CARE.PRO', 'password');
    expect(page.errorMessageSnackbar()).toBe('User not found');
  });
});
