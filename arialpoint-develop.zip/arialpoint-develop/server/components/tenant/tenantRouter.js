const { Router } = require("express");

const authentication = require("../../middleware/authentication");
const tenantController = require("./tenantController/tenantController");

const tenantRouter = new Router();

tenantRouter.use(authentication());

tenantRouter.get("/tenant", tenantController.getTenant);
tenantRouter.get("/tenant/:id", tenantController.getTenantById);
tenantRouter.patch("/tenant/:id", tenantController.patchTenantById);
tenantRouter.delete("/tenant/:id", tenantController.deleteTenantById);

module.exports = tenantRouter;
