import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { NgForm } from '@angular/forms';
import { AnotationsService } from '../../../../services/anotations.service';
import { UpdateAnnotationFormGroup } from '../../../../models/update-annotation-form.model';
import { Annotation } from '../../../../models/annotation.model';

@Component({
  selector: 'app-update-annotation',
  templateUrl: './update-annotation.component.html',
  styleUrls: ['./update-annotation.component.scss']
})
export class UpdateAnnotationComponent {
  updateFormGroup: UpdateAnnotationFormGroup = new UpdateAnnotationFormGroup();
  annotation: Annotation = new Annotation();
  formSubmitted = false;
  files: Array<File>;

  constructor(
    private anotationsService: AnotationsService,
    public dialogRef: MatDialogRef<UpdateAnnotationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Annotation
  ) {
    this.annotation = {...data};
  }

  addFile(event) {
    const target = event.target || event.srcElement;
    this.files = target.files;
  }

  checkBeforeUpdate(form: NgForm) {
    this.formSubmitted = true;
    if (typeof this.files !== 'undefined') {
      this.submit(form);
    } else {
      const responseType = this.checkResponseType(this.annotation.fileName);
      this.anotationsService.downloadAnotation(this.annotation._id).subscribe((res) => {
        if (res.value) {
          const datas = new Uint8Array(res.value.Body.data);
          const blob = new Blob([datas], {type: responseType});
          this.files = [new File([blob], this.annotation.fileName)];
          this.submit(form);
        }
      });
    }
  }

  checkResponseType(file: any) {
    const type = file.match(/(doc|docx|pdf|csv|jpg|jpeg|png|gif|bmp|tiff)/gm, (m, g1) => {
      return `${g1}`;
    });
    switch (type[0]) {
      case 'doc':
      case 'docx':
        return  'application/msword';
      case 'pdf':
        return 'application/pdf';
      case 'csv':
        return 'text/csv';
      case 'jpg':
      case 'jpeg':
        return 'image/jpeg';
      case 'png':
        return 'image/png';
      case 'gif':
        return 'image/gif';
      case 'bmp':
        return 'image/vnd.wap.wbmp';
      case 'tiff':
        return 'image/tiff';
    }
  }

  submit(form: NgForm): void {
    if (form.valid) {
      const dialogResult = {
        name: form.controls['name'].value,
        text: form.controls['description'].value,
        file: this.files
      };
      this.dialogRef.close(dialogResult);
      this.annotation = new Annotation();
      form.reset();
      this.formSubmitted = false;
    }
  }

  onNoClick() {
    this.dialogRef.close();
  }
}
