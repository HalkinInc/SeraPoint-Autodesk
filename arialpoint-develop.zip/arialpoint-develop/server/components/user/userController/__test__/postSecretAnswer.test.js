const assert = require("assert");

const request = require("supertest");

const { server } = require("../../../../server");
const { users } = require("./seeds");

it("error if email is not provided", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/user/secret-answer");

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'body' should have required property 'email'");

    assert.strictEqual(value, undefined);
});

it("error if answer is not provided", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/user/secret-answer")
        .send({
            email: users[1].email,
            password: "password"
        });

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'body' should have required property 'answer'");

    assert.strictEqual(value, undefined);
});

it("error if password is not valid", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/user/secret-answer")
        .send({
            email: users[1].email,
            answer: "hello",
            password: "abc"
        });

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'body/password' should NOT be shorter than 6 characters");

    assert.strictEqual(value, undefined);
});

it("error if user not found", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/user/secret-answer")
        .send({
            email: "netTakogoEmeila@email.com",
            answer: "correct",
            password: "newPassword"
        });

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "User not found");

    assert.strictEqual(value, undefined);
});

it("error if answer is not correct", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/user/secret-answer")
        .send({
            email: users[1].email,
            answer: "notCorrect",
            password: "newPassword"
        });

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Answer is not correct");

    assert.strictEqual(value, undefined);
});

it("check answer if password is not provided", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/user/secret-answer")
        .send({
            email: users[1].email,
            answer: users[1].secretQuestionAnswer,
        });

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});

it("update password if answer is correct", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/user/secret-answer")
        .send({
            email: users[1].email,
            answer: users[1].secretQuestionAnswer,
            password: "newPassword"
        });

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});