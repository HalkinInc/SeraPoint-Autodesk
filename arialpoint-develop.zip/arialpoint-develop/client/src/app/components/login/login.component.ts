import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { NgForm } from '@angular/forms';
import { LoginFormGroup } from '../../models/login-form.model';

export class LoginUser {
    constructor(public email: string, public password: string) {}
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
    hidePassword = true;
    loginForm: LoginFormGroup = new LoginFormGroup();
    newUser: LoginUser = new LoginUser('', '');
    formSubmitted = false;

    constructor(private authService: AuthService,
        private router: Router) {}

    submitForm(form: NgForm) {
        this.formSubmitted = true;
        if (form.valid) {
            this.authService.authenticate(form.controls.email.value, form.controls.password.value)
                .subscribe((res) => {
                    this.formSubmitted = false;
                    this.router.navigateByUrl('/dashboard');
                });
        }
    }
}
