const { db } = require("../server");
const appErrors = require("../utils/appErrors");

const createModel = (col) => {
    const insertOne = async (doc) => {
        const dataBase = await db;
        const { result: { n, ok } } = await dataBase.collection(col).insertOne(doc);
        if (n !== 1 || ok !== 1) throw new appErrors.DataAccessError(`Can't insert one into '${col}' collection`);
    };

    const insertMany = async (docs) => {
        const dataBase = await db;
        const { result: { ok } } = await dataBase.collection(col).insertMany(docs);
        if (ok !== 1) throw new appErrors.DataAccessError(`Can't insert many into '${col}' collection`);
    };

    const findOne = async (query) => {
        const dataBase = await db;
        return await dataBase.collection(col).findOne(query);
    };

    const findMany = async (query, limit = 0, skip = 0, projection) => {
        const dataBase = await db;
        return await dataBase.collection(col).find(query, { limit, skip, projection }).toArray();
    };

    const updateOne = async (filter, update) => {
        const dataBase = await db;
        const { result: { n, ok } } = await dataBase.collection(col).updateOne(filter, update);
        if (n !== 1 || ok !== 1) throw new appErrors.DataAccessError(`Can't update one in '${col}' collection`);
    };

    const updateMany = async (filter, update) => {
        const dataBase = await db;
        const { result: { ok } } = await dataBase.collection(col).updateMany(filter, update);
        if (ok !== 1) throw new appErrors.DataAccessError(`Can't update many in '${col}' collection`);
    };

    const deleteOne = async (filter) => {
        const dataBase = await db;
        const { result: { n, ok } } = await dataBase.collection(col).deleteOne(filter);
        if (n !== 1 || ok !== 1) throw new appErrors.DataAccessError(`Can't delete one in '${col}' collection`);
    };

    const deleteMany = async (filter) => {
        const dataBase = await db;
        const { result: { ok } } = await dataBase.collection(col).deleteMany(filter);
        if (ok !== 1) throw new appErrors.DataAccessError(`Can't delete many in '${col}' collection`);
    };

    const countDocuments = async (filter) => {
        const dataBase = await db;
        return await dataBase.collection(col).countDocuments(filter);
    };

    return {
        insertOne,
        insertMany,
        findOne,
        findMany,
        updateOne,
        updateMany,
        deleteOne,
        deleteMany,
        countDocuments
    };
};

module.exports = createModel;
