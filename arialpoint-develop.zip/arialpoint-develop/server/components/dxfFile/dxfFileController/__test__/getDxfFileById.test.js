const assert = require("assert");

const request = require("supertest");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { dxfFiles, users } = require("./seeds");

it("error if provided dxf file id is invalid", async () => {
    const token = users[0].jwt;
    const dxfFileId = "12345";

    const response = await request(server).get(`/dxf-file/${dxfFileId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'params/id' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if dxf file with provided id not exists", async () => {
    const token = users[0].jwt;
    const dxfFileId = ObjectId().toString();

    const response = await request(server).get(`/dxf-file/${dxfFileId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Dxf file not found");

    assert.strictEqual(value, undefined);
});

it("error if dxf file is deleted", async () => {
    const token = users[0].jwt;
    const dxfFileId = dxfFiles[2]._id.toString();

    const response = await request(server).get(`/dxf-file/${dxfFileId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Dxf file was deleted");

    assert.strictEqual(value, undefined);
});

it("dxf-file:read:tenant can't get files of not his tenant", async () => {
    const token = users[1].jwt;
    const dxfFileId = dxfFiles[1]._id.toString();

    const response = await request(server).get(`/dxf-file/${dxfFileId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("dxf-file:read:tenant can get files of his tenant", async () => {
    const token = users[1].jwt;
    const dxfFileId = dxfFiles[0]._id.toString();

    const response = await request(server).get(`/dxf-file/${dxfFileId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value.name, dxfFiles[0].name);
});

it("dxf-file:read:any can get any files", async () => {
    const token = users[0].jwt;
    const dxfFileId = dxfFiles[1]._id.toString();

    const response = await request(server).get(`/dxf-file/${dxfFileId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value.name, dxfFiles[1].name);
});