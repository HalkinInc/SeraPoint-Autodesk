const AnotationService = require("../anotationService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const deleteAnotationById = async (req, res, next) => {
    try {
        const { authUser, params: { id } } = req;

        const foundAnotation = await AnotationService.getAnotationById(id);
        if (authUser.permissions.includes("anotation:delete:tenant") && authUser.tenantId !== foundAnotation.tenantId) throw new appErrors.AuthorizationError();
        if (authUser.permissions.includes("anotation:delete:own") && authUser._id.toString() !== foundAnotation.creatorId) throw new appErrors.AuthorizationError();

        await AnotationService.flagAnotationAsDeleted(id);

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const deleteAnotationByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true }
        }
    }
};

module.exports = [
    authorization(["anotation:delete:any", "anotation:delete:tenant", "anotation:delete:own"]),
    requestValidation(deleteAnotationByIdSchema),
    deleteAnotationById
];