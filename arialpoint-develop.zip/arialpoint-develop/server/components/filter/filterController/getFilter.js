const FilterService = require("../filterService");
const requestValidation = require("../../../middleware/requestValidation");

const getFilter = async (req, res, next) => {
    try {
        const { authUser } = req;

        res.send({ errors: [], value: await FilterService.getUserFilters(authUser._id.toString()) });
    } catch (error) { return next(error); }
};

module.exports = [
    requestValidation(),
    getFilter
];