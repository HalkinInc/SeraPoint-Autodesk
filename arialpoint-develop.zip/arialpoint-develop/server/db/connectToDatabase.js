const MongoClient = require("mongodb").MongoClient;
const config = require("config");

const logger = require("../utils/logger");

const url = `mongodb://${config.db.username}:${config.db.password}@mongodb:27017`;
const client = new MongoClient(url, { useNewUrlParser: true });

const createIndexes = async (db) => {
    return {
        users: await db.collection("users").createIndex({ email: 1 }, { unique: true }),
        tenants: await db.collection("tenants").createIndex({ name: 1 }, { unique: true })
    };
};

const connectToDatabase = async () => {
    try {
        await client.connect();

        const dataBase = await client.db(config.db.name);
        logger.info("Connected to database:", dataBase.s.databaseName);

        const createdIndexes = await createIndexes(dataBase);
        logger.info("Created indexes:", createdIndexes);

        return dataBase;
    } catch (error) {
        logger.error(error, "Database initialization error");
        process.exit(1);
    }
};

module.exports = connectToDatabase;
