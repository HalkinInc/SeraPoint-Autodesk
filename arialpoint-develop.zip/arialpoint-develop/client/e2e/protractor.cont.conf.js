const protractorConf = require('./protractor.conf');

const protractorContConf = { ...protractorConf };

protractorContConf.config.capabilities.chromeOptions.args = [
  ...protractorContConf.config.capabilities.chromeOptions.args,
  '--headless',
];


module.exports = protractorContConf;