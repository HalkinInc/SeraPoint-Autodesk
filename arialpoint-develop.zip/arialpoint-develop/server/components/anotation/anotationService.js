const path = require("path");

const { Long, ObjectId } = require("mongodb");
const AWS = require("aws-sdk");
const config = require("config");
const uuidv4 = require("uuid");

const AnotationModel = require("./anotationModel");
const DxfFileService = require("../dxfFile/dxfFileService");
const validate = require("../../utils/validate");
const appErrors = require("../../utils/appErrors");

const s3 = new AWS.S3({
    params: { Bucket: "serapoint-anotations" },
    credentials: { accessKeyId: config.aws.accessKey, secretAccessKey: config.aws.secretAccessKey }
});

const createAnotationSchema = {
    type: "object",
    required: ["name", "creatorId", "dxfFileId", "text", "blockIndex", "screenshot", "createdAt", "deleted"],
    additionalProperties: false,
    properties: {
        // required
        name: { type: "string", minLength: 3, maxLength: 100 },
        creatorId: { type: "string" },
        dxfFileId: { type: "string" },
        text: { type: "string" },
        blockIndex: { type: "string" },
        screenshot: { type: "string" },
        createdAt: { type: "integer" },
        deleted: { type: "boolean", default: false },
        // not required,
        fileKey: { type: "string" },
        fileName: { type: "string" },
        fileSize: { type: "integer" },
    }
};

const createAnotation = async (anotation) => {
    anotation.createdAt = Date.now();

    const validationError = validate(createAnotationSchema, anotation);
    if (validationError !== null) throw new appErrors.RequestError(validationError);

    anotation.createdAt = Long.fromNumber(anotation.createdAt);
    if (anotation.fileSize !== undefined) anotation.fileSize = Long.fromInt(anotation.fileSize);

    await AnotationModel.insertOne(anotation);
};

const uploadAnotationScreenshot = async (screenshot) => {
    if (screenshot === undefined) return {};
    if (process.env.NODE_ENV === "test") return { screenshot: "test screenshotKey" };

    const screenshotKey = uuidv4();
    await s3.upload({ Key: screenshotKey, Body: screenshot.read() }).promise();
    return { screenshot: screenshotKey };
};

const deleteAnotationScreenshot = async (screenshot) => {
    if (process.env.NODE_ENV === "test") return;
    await s3.deleteObject({ Key: screenshot }).promise();
};

const uploadAnotationFile = async (file) => {
    if (file === undefined) return {};
    if (process.env.NODE_ENV === "test") return { fileKey: "test fileKey", fileName: "test fileName", fileSize: 777 };

    const fileKey = uuidv4() + path.extname(file.name);
    await s3.upload({ Key: fileKey, Body: file.read() }).promise();
    return { fileKey, fileName: file.name, fileSize: file.size };
};

const deleteAnotationFile = async (fileKey) => {
    if (process.env.NODE_ENV === "test") return;
    await s3.deleteObject({ Key: fileKey }).promise();
};

const uploadAnotation = async (file, screenshot) => {
    const [fileUploadResult, screenshotUploadResult] = await Promise.all([uploadAnotationFile(file), uploadAnotationScreenshot(screenshot)]);
    return { ...fileUploadResult, ...screenshotUploadResult };
};

const getAnotationById = async (id, deleted = false) => {
    const foundAnotation = await AnotationModel.findAndEnrichOne({ _id: ObjectId(id) });
    if (foundAnotation === null) throw new appErrors.NotFoundError("Anotation not found");
    if (!deleted && foundAnotation.deleted) throw new appErrors.NotFoundError("Anotation was deleted");

    return foundAnotation;
};

const getTenantAnotations = async (tenantId, deleted = false) => {
    const foundDxfFiles = await DxfFileService.getTenantDxfFiles(tenantId);

    const foundTenantAnotations = await foundDxfFiles.reduce(async (acc, foundDxfFile) => {
        const foundDxfFileAnotations = await AnotationModel.findAndEnrichMany({ dxfFileId: foundDxfFile._id.toString(), deleted });
        return [...await acc, ...foundDxfFileAnotations];
    }, []);

    return foundTenantAnotations;
};

const getCreatorAnotations = async (creatorId, deleted = false) => {
    return await AnotationModel.findAndEnrichMany({ creatorId, deleted });
};

const getDxfFileAnotations = async (dxfFileId, deleted = false) => {
    return await AnotationModel.findAndEnrichMany({ dxfFileId, deleted });
};

const getAllAnotations = async (deleted = false) => {
    return await AnotationModel.findAndEnrichMany({ deleted });
};

const flagAnotationAsDeleted = async (id) => {
    await AnotationModel.updateOne({ _id: ObjectId(id) }, { $set: { deleted: true, deletedAt: Date.now() } });
};

const unflagAnotationAsDeleted = async (id) => {
    await getAnotationById(id, true);
    await AnotationModel.updateOne({ _id: ObjectId(id) }, { $set: { deleted: false }, $unset: { deteledAt: "" } });
};
const flagDxfFileAnotationsAsDeleted = async (dxfFileId) => {
    await AnotationModel.updateMany({ dxfFileId }, { $set: { deleted: true, deletedAt: Date.now() } });
};

const updateAnotation = async (id, set = {}, unset = {}) => {
    const update = {};
    if (Object.entries(unset).length > 0) update.$unset = unset;
    if (Object.entries(set).length > 0) update.$set = set;
    await AnotationModel.updateOne({ _id: ObjectId(id) }, update);
};

const getAnotationFile = async (id) => {
    const foundAnotation = await getAnotationById(id);
    if (foundAnotation.fileKey === undefined) throw new appErrors.AppError("Anotation is text", "validation", 409, true);

    if (process.env.NODE_ENV === "test") return "file";

    return await s3.getObject({ Key: foundAnotation.fileKey }).promise();
};

const getAnotationScreenshot = async (id) => {
    const foundAnotation = await getAnotationById(id);

    if (process.env.NODE_ENV === "test") return "screenshot";

    return await s3.getObject({ Key: foundAnotation.screenshot }).promise();
};

module.exports = {
    createAnotation,
    uploadAnotation,
    uploadAnotationFile,
    deleteAnotationFile,
    uploadAnotationScreenshot,
    deleteAnotationScreenshot,
    getAnotationById,
    getTenantAnotations,
    getCreatorAnotations,
    getDxfFileAnotations,
    getAllAnotations,
    flagAnotationAsDeleted,
    unflagAnotationAsDeleted,
    flagDxfFileAnotationsAsDeleted,
    getAnotationFile,
    getAnotationScreenshot,
    updateAnotation,
};