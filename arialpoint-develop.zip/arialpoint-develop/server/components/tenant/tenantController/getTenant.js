const TenantService = require("../tenantService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");

const getTenant = async (req, res, next) => {
    try {
        let { query: { deleted, limit, skip } } = req;
        deleted = deleted === "true" ? true : false;

        return res.send({ errors: [], value: await TenantService.getAllTenants(deleted, limit, skip) });
    } catch (error) { return next(error); }
};

const getTenantSchema = {
    query: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            limit: { type: "string" },
            skip: { type: "string" },
            deleted: { type: "string" }
        }
    }
};

module.exports = [
    authorization(["tenant:read:any"]),
    requestValidation(getTenantSchema),
    getTenant
];