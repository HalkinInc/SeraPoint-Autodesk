const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const handleRootPatching = async (req, res) => {
    const { foundUser, authUser, body: fields, params: { id }, query: { newRootId } } = req;
    if (!foundUser._id.equals(authUser._id)) throw new appErrors.AuthorizationError();
    if (fields.role !== undefined || fields.deleted === true) throw new appErrors.AuthorizationError();

    if (newRootId !== undefined) {
        await UserService.reasignRootRole(id, newRootId);
        return res.send({ errors: [], value: true });
    }

    await UserService.updateUserbyId(id, fields);

    return res.send({ errors: [], value: true });

};

const handleAdminPatching = async (req, res) => {
    const { authUser, params: { id }, body: fields } = req;

    if (!authUser.permissions.includes("admin:update:any")) throw new appErrors.AuthorizationError();

    if (fields.deleted === false) await UserService.unflagUserAsDeleted(id);
    await UserService.updateUserbyId(id, fields);

    return res.send({ errors: [], value: true });
};

const handleModeratorPatching = async (req, res) => {
    const { authUser, params: { id }, body: fields, query: { newModeratorId } } = req;

    if (!authUser.permissions.includes("moderator:update:any")) throw new appErrors.AuthorizationError();

    if (fields.deleted === false) await UserService.unflagUserAsDeleted(id);
    if (newModeratorId !== undefined) {
        await UserService.reasignModeratorRole(id, newModeratorId);
        return res.send({ errors: [], value: true });
    }
    await UserService.updateUserbyId(id, fields);

    return res.send({ errors: [], value: true });
};

const handleUserPatching = async (req, res) => {
    const { foundUser, authUser, body: fields, params: { id } } = req;

    if (authUser.permissions.includes("user:update:own") && authUser._id.toString() !== foundUser._id.toString()) throw new appErrors.AuthorizationError();

    if (fields.deleted === false) await UserService.unflagUserAsDeleted(id);
    await UserService.updateUserbyId(id, fields);

    return res.send({ errors: [], value: true });
};

const patchUserById = async (req, res, next) => {
    try {
        const { params: { id }, body: fields } = req;

        req.foundUser = fields.deleted === false ? await UserService.getDeletedUserById(id) : await UserService.getUserById(id);

        const userPatchingHanlders = {
            root: handleRootPatching,
            admin: handleAdminPatching,
            moderator: handleModeratorPatching,
            user: handleUserPatching
        };

        await userPatchingHanlders[req.foundUser.role](req, res);
    } catch (error) { return next(error); }
};

const patchUserByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true },
        }
    },
    body: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            email: { type: "string" },
            firstname: { type: "string" },
            lastname: { type: "string" },
            role: { type: "string", enum: ["admin", "moderator", "user"] },
            tenantId: { type: "string" },
            deleted: { type: "boolean" },
            address: { type: "string" },
            city: { type: "string" },
            state: { type: "string" },
            phoneNumber: { type: "string" },
            secretQuestionAnswer: { type: "string" },
            secretQuestionId: { type: "integer" },
        }
    },
    query: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            newRootId: { type: "string", objectId: true },
            newModeratorId: { type: "string", objectId: true }
        }
    }
};

module.exports = [
    authorization(["admin:update:any", "moderator:update:any", "user:update:any", "user:update:own"]),
    requestValidation(patchUserByIdSchema),
    patchUserById
];