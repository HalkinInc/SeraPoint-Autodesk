const conn = new Mongo();

const users = [
    {
        '_id': ObjectId('5cdd701d5d189d76a1c87887'),
        'email': 'pm@code-care.pro',
        'role': 'root',
        'firstname': 'Kateryna',
        'lastname': 'Feoktistova',
        'password': '$2a$10$8AtwmYZaCeVCc.H4RiGgOONlgG25.kGoniDF.wHXtUyp1uLewdO1W',
        'secretQuestionId': NumberLong(0),
        'secretQuestionAnswer': 'moose',
        'deleted': false,
        'lastActive': NumberLong(1558016282672),
        'lastLogin': NumberLong(1558016282383),
        'loginCount': NumberLong(2)
    },
    {
        '_id': ObjectId('5cdd701d5d189d76a1c87888'),
        'email': 'andrii@code-care.pro',
        'role': 'admin',
        'firstname': 'Andrii',
        'lastname': 'Danko',
        'password': '$2a$10$8AtwmYZaCeVCc.H4RiGgOONlgG25.kGoniDF.wHXtUyp1uLewdO1W',
        'secretQuestionId': NumberLong(0),
        'secretQuestionAnswer': 'cat',
        'deleted': false,
        'lastActive': NumberLong(1558016235428),
        'lastLogin': NumberLong(1558016235174),
        'loginCount': NumberLong(1)
    },
    {
        '_id': ObjectId('5cdd701d5d189d76a1c87889'),
        'email': 'alex.semenec@code-care.pro',
        'firstname': 'Alexandr',
        'lastname': 'Semenet',
        'tenantId': '5cdd4415fcc605003b897d7e',
        'role': 'moderator',
        'deleted': false,
        'address': 'Cool Street, 17',
        'city': 'New York',
        'hasAvatar': false,
        'password': '$2a$10$WT6imWpWo5nHadOcYC9nteddJxnQKcwdkA2WkqKV8wYWDnehViBrO',
        'secretQuestionAnswer': 'dog',
        'secretQuestionId': NumberLong(0),
        'state': 'New York',
        'lastActive': NumberLong(1558016295402),
        'lastLogin': NumberLong(1558016295143),
        'loginCount': NumberLong(2)
    },
    {
        '_id': ObjectId('5cdd701d5d189d76a1c87890'),
        'email': 'kate@legacybeta.com',
        'firstname': 'Kateryna',
        'lastname': 'Legacy',
        'tenantId': '5cdd4415fcc605003b897d7e',
        'role': 'user',
        'deleted': false,
        'address': 'Bright Street, 19',
        'city': 'Miami',
        'hasAvatar': false,
        'password': '$2a$10$WT6imWpWo5nHadOcYC9nteddJxnQKcwdkA2WkqKV8wYWDnehViBrO',
        'secretQuestionAnswer': 'hog',
        'secretQuestionId': NumberLong(0),
        'state': 'Florida',
        'lastActive': NumberLong(1558016295408),
        'lastLogin': NumberLong(1558016295178),
        'loginCount': NumberLong(3)
    }
];

const tenants = [
    {
        '_id': ObjectId('5cdd4415fcc605003b897d7e'),
        'name': 'code-care',
        'deleted': false
    }
];

const dxfFiles = [
    {
        "_id": ObjectId("5d31b9291e3aec0059e66819"),
        "urn": "urn:adsk.viewing:fs.file:dXJuOmFkc2sub2JqZWN0czpvcy5vYmplY3Q6YWVyaWFsLXBvaW50L2FiZTQzMzM1LTU5NmYtNDRiZC04NWZmLTZjOTQ5MWM1Nzg0ZS5keGY/output/dwg.svf",
        "creatorId": "5cdd701d5d189d76a1c87888",
        "tenantId": "5cdd4415fcc605003b897d7e",
        "fileName": "EZRoof_halkin_20190213224145.dxf",
        "fileKey": "abe43335-596f-44bd-85ff-6c9491c5784e.dxf",
        "fileSize": NumberLong(4612922),
        "createdAt": NumberLong(1563539753268),
        "deleted": false
    }
];

const anotations = [
    {
        "_id": ObjectId("5d31b9781e3aec0059e6683d"),
        "name": "Cool annotation",
        "dxfFileId": "5d31b9291e3aec0059e66819",
        "text": "Cool description",
        "blockIndex": "25182",
        "fileKey": "d34468fd-636e-4d27-91d9-bf04a3913cef.pdf",
        "fileName": "sample.pdf",
        "fileSize": NumberLong(3028),
        "screenshot": "a00c9051-9d36-4681-8c39-83e1a8fd7f25",
        "creatorId": "5cdd701d5d189d76a1c87888",
        "createdAt": NumberLong(1563539832730),
        "deleted": false
    }
];

const settings = [
    {
        "_id": ObjectId("5cf62de85e19d7ea00b28e91"),
        "name": "main",
        "deletedUsersDaysLimit": NumberLong(30),
        "deletedDxfFilesDaysLimit": NumberLong(30),
        "deletedAnnotationsDaysLimit": NumberLong(30)
    }
];

const developmentDb = conn.getDB('development');

developmentDb.users.insertMany(users);
developmentDb.tenants.insertMany(tenants);
developmentDb.dxffiles.insertMany(dxfFiles);
developmentDb.anotations.insertMany(anotations);
developmentDb.settings.insertMany(settings);