const request = require("supertest");
const assert = require("assert");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { users } = require("./seeds");

it("error if user id is invalid", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/user/abc123/invitation")
        .set("Authorization", users[0].jwt);

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'params/id' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if user not found", async () => {
    const { body: { errors, value } } = await request(server)
        .post(`/user/${ObjectId()}/invitation`)
        .set("Authorization", users[0].jwt);

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "User not found");

    assert.strictEqual(value, undefined);
});

it("user:create:tenant can't resend invitation to user of another tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .post(`/user/${users[7]._id.toString()}/invitation`)
        .set("Authorization", users[1].jwt);

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("user:create:tenant can resend invitaion to user of his tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .post(`/user/${users[9]._id.toString()}/invitation`)
        .set("Authorization", users[1].jwt);

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});

it("user:create:any can resend invitaion to any user", async () => {
    const { body: { errors, value } } = await request(server)
        .post(`/user/${users[9]._id.toString()}/invitation`)
        .set("Authorization", users[0].jwt);

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});
