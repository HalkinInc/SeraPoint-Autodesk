import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'size'
})
export class SizePipe implements PipeTransform {
  transform(value: number): string {
    if (Math.round(value / 1000000) > 0) {
      return `${(value / 1000000).toFixed(2)} MB`;
    }
    return `${Math.round(value / 1000).toFixed(2)} KB`;
  }
}
