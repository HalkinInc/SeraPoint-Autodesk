const assert = require("assert");
const path = require("path");

const request = require("supertest");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { tenants, users } = require("./seeds");


it("error if file extension is not dxf", async () => {
    const token = users[0].jwt;
    const filePath = path.resolve(__dirname, "test.notDxf");

    const response = await request(server).post("/dxf-file")
        .set("authorization", token)
        .attach("newFile", filePath);

    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'formData/file' should be a file");

    assert.strictEqual(value, undefined);
});

// it('error if dxf file with same name exists', async () => {
//     const token = users[0].jwt
//     const tenantId = tenants[1]._id.toString()
//     const filePath = path.resolve(__dirname, 'test.dxf')

//     const response = await request(server).post(`/dxf-file`)
//         .set('authorization', token)
//         .field('tenantId', tenantId)
//         .attach('file', path.resolve(__dirname, filePath))

//     const { errors, value } = response.body

//     assert.notStrictEqual(errors, undefined)
//     assert.strictEqual(errors.length, 1)
//     assert.strictEqual(errors[0], 'File with such name already exists')

//     assert.strictEqual(value, undefined)
// })

it("error if tenant id is not provided", async () => {
    const token = users[0].jwt;
    const filePath = path.resolve(__dirname, "test.dxf");

    const response = await request(server).post("/dxf-file")
        .set("authorization", token)
        .attach("file", path.resolve(__dirname, filePath));

    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'formData' should have required property 'tenantId'");

    assert.strictEqual(value, undefined);
});

it("error if tenant id is not valid", async () => {
    const token = users[0].jwt;
    const filePath = path.resolve(__dirname, "test.dxf");
    const tenantId = "12345";

    const response = await request(server).post("/dxf-file")
        .set("authorization", token).field("tenantId", tenantId)
        .attach("file", path.resolve(__dirname, filePath));

    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'formData/tenantId' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if tenant with provided id not exists", async () => {
    const token = users[0].jwt;
    const filePath = path.resolve(__dirname, "test.dxf");
    const tenantId = ObjectId().toString();

    const response = await request(server).post("/dxf-file")
        .set("authorization", token)
        .field("tenantId", tenantId)
        .attach("file", path.resolve(__dirname, filePath));

    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Tenant not found");

    assert.strictEqual(value, undefined);
});

it("user without permission can't add dxf file", async () => {
    const token = users[1].jwt;

    const response = await request(server).post("/dxf-file")
        .set("authorization", token)
        .attach("file", path
            .resolve(__dirname, "test.dxf"));

    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("dxf-file:create:any can add dxf file", async () => {
    const token = users[0].jwt;
    const tenantId = tenants[0]._id.toString();

    const response = await request(server).post("/dxf-file")
        .set("authorization", token)
        .field("tenantId", tenantId)
        .attach("file", path.resolve(__dirname, "test.dxf"));

    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});