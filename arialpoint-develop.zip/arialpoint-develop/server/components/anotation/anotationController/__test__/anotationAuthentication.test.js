const assert = require("assert");

const request = require("supertest");
const jsonwebtoken = require("jsonwebtoken");
const config = require("config");

const { server } = require("../../../../server");
const { anotations } = require("./seed");

it("error if token is not provided", async () => {
    const anotationId = anotations[0]._id.toString();

    const response = await request(server).delete(`/anotation/${anotationId}`);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Token is not provided");

    assert.strictEqual(value, undefined);
});

it("error if token is not valid", async () => {
    const anotationId = anotations[0]._id.toString();
    const token = jsonwebtoken.sign("blabla", config.app.secret);

    const response = await request(server).delete(`/anotation/${anotationId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Supplied token is invalid");

    assert.strictEqual(value, undefined);
});

it("error if user with provided token not exists", async () => {
    const anotationId = anotations[0]._id.toString();
    const token = jsonwebtoken.sign({ email: "notExist@email.com" }, config.app.secret);

    const response = await request(server).delete(`/anotation/${anotationId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Supplied token is invalid");

    assert.strictEqual(value, undefined);
});