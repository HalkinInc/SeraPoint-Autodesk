import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsersService } from '../../services/users.service';
import { MatStepper } from '@angular/material';
import secretQuestions from '../../consts/secretQuestions';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})

export class ForgotPasswordComponent implements OnInit {
    isLinear = true;
    firstFormGroup: FormGroup;
    secondFormGroup: FormGroup;
    thirdFormGroup: FormGroup;
    secretQuestion: number;
    questions: Array<string> = secretQuestions;
    hide = true;

    @ViewChild('stepper') stepper: MatStepper;

    getErrorMessage() {
        return this.firstFormGroup.controls['emailCtrl'].hasError('required') ? 'You must enter a value' :
            this.firstFormGroup.controls['emailCtrl'].hasError('email') ? 'Not a valid email' :
                '';
    }

    constructor(
        private _formBuilder: FormBuilder,
        private usersService: UsersService) {}

    ngOnInit() {
        this.firstFormGroup = this._formBuilder.group({
            emailCtrl: ['', Validators.compose([Validators.required, Validators.email])]
        });
        this.secondFormGroup = this._formBuilder.group({
            answerCtrl: ['', Validators.required]
        });
        this.thirdFormGroup = this._formBuilder.group({
            passwordCtrl: ['', Validators.required]
        });
    }

    getSecretQuestion() {
        this.usersService.secretQuestion(this.firstFormGroup.controls['emailCtrl'].value).subscribe((res) => {
            if (res.errors.length === 0) {
                this.secretQuestion = res.value;
                this.stepper.next();
            }
        });
    }

    checkSecretAnswer() {
        this.usersService.secretAnswer(
            this.firstFormGroup.controls['emailCtrl'].value,
            this.secondFormGroup.controls['answerCtrl'].value).subscribe((res) => {
            if (res.errors.length === 0) {
                this.stepper.next();
            }
        });
    }

    secretAnswer() {
        this.usersService.secretAnswer(
            this.firstFormGroup.controls['emailCtrl'].value,
            this.secondFormGroup.controls['answerCtrl'].value,
            this.thirdFormGroup.controls['passwordCtrl'].value).subscribe((res) => {
                if (res.errors.length === 0) {
                    this.stepper.next();
                } else {
                    this.stepper.previous();
                    this.secondFormGroup.controls['answerCtrl'].setValue('');
                }
            });
    }
}

