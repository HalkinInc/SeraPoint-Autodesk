const FilterService = require("../filterService");
const requestValidation = require("../../../middleware/requestValidation");

const postFilter = async (req, res, next) => {
    try {
        const { authUser, body } = req;

        await FilterService.createFilter(authUser._id.toString(), body);

        res.status(201).send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const postFilterSchema = {
    body: {
        type: "object",
        required: [],
        minProperties: 1,
        additionalProperties: false,
        properties: {
            title: { type: "string" },
            description: { type: "string" },
            users: { type: "array", items: { type: "string" } },
            date: { type: "string" }
        }
    }
};

module.exports = [
    requestValidation(postFilterSchema),
    postFilter
];