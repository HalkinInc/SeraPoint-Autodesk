describe("USER", () => require("./components/user/userController/__test__/userController.test"));

describe("FILTER", () => require("./components/filter/filterController/__test__/filterController.test"));

describe("TENANT", () => require("./components/tenant/tenantController/__test__/tenantController.test"));

describe("DXF FILE", () => require("./components/dxfFile/dxfFileController/__test__/dxfFileController.test"));

describe("ANOTATION", () => require("./components/anotation/anotationController/__test__/anotationController.test"));