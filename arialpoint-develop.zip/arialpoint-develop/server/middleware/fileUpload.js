const path = require("path");
const fs = require("fs");
const { promisify } = require("util");

const formidable = require("formidable");

const appErrors = require("../utils/appErrors");

const unlink = promisify(fs.unlink);

module.exports = (config) => {
    return async (req, res, next) => {
        try {
            if (req.headers["content-type"] === undefined || !req.headers["content-type"].includes("multipart/form-data")) throw new appErrors.RequestError("'Content-Type' should be 'multipart/form-data'");

            const form = new formidable.IncomingForm();
            // form.uploadDir = path.resolve(__dirname, '../uploads')

            form.parse(req, async (err, fields, files) => {
                try {
                    if (err !== null) throw new appErrors.RequestError(err);

                    const deleteFiles = async () => {
                        res.removeListener("finish", deleteFiles);
                        res.removeListener("close", deleteFiles);

                        await Promise.all(Object.values(files).map(async (file) => {
                            await unlink(file.path);
                        }));
                    };

                    res.on("finish", deleteFiles);
                    res.on("close", deleteFiles);

                    const configFields = Object.keys(config);
                    const filesFields = Object.keys(files);

                    // check if form data contains all config file
                    for (const field of configFields) if (config[field].required && files[field] === undefined) throw new appErrors.RequestError(`'formData/${field}' should be a file`);

                    // check if form data doesn't contain files not in config
                    for (const field of filesFields) if (!configFields.includes(field)) throw new appErrors.RequestError(`'formData' should NOT have additional file '${field}'`);

                    // check if files have correct extensions
                    for (const field of filesFields) if (config[field].extensions.length > 0 && !config[field].extensions.includes(path.extname(files[field].name).toLocaleLowerCase())) throw new appErrors.RequestError(`'formData/${field}' should have ${createExtensionsString(config[field].extensions)} file extension`);

                    req.formData = fields;
                    req.body = {};
                    req.files = files;

                    // add func to file that creates readable stream
                    for (const field of filesFields) req.files[field].read = () => fs.createReadStream(req.files[field].path);

                    next();
                } catch (error) { return next(error); }
            });
        } catch (error) { return next(error); }
    };
};

const createExtensionsString = (extsArr) => extsArr.reduce((acc, ext, ind, arr) => {
    if (ind === 0) return acc + `['${ext}'`;
    if (ind === arr.length - 1) return acc + `, '${ext}']`;
    return acc + `, '${ext}'`;
}, "");