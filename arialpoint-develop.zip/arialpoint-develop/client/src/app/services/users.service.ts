import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { BehaviorSubject, Subject } from 'rxjs';

export const CURRENT_USER = new Subject;

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' })
};

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  auth_token: string;
  private currentUserSubject: BehaviorSubject<any>;

  constructor(private http: HttpClient) { }

  authenticate(email: string, password: string) {
    return this.http.post('/api/user/login', { email, password })
      .pipe(
        tap((res: any) => {
          this.auth_token = res ? res.value : null;
          localStorage.setItem('currentUser', JSON.stringify(this.auth_token));
          return res;
        }));
  }

  inviteUser({
    email,
    firstname,
    lastname,
    message,
    role,
    tenantName
  }) {
    let data: any;
    if (role === 'admin') {
      data = { firstname, lastname, email, role, message };
    } else {
      data = { firstname, lastname, email, role, tenantName, message };
    }
    return this.http.post('/api/user', data)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  finishRegistration(finishRegistrationCode, additionalFields) {
    return this.http.post('/api/user/finish-registration', { finishRegistrationCode, additionalFields }, httpOptions)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  getUser() {
    this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('currentUser')));
    const jwt = this.currentUserSubject.value;
    return this.http.post('/api/user/byJwt', { jwt })
      .pipe(
        tap((res: any) => {
          CURRENT_USER.next(res.value);
          // return res;
        }));
  }

  getUserById(id) {
    return this.http.get(`/api/user/${id}`)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  getUsers(id?: string) {
    let url = '/api/user';
    if (id.length > 0) {
      url += `?tenantId=${id}`;
    }
    return this.http.get(url)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  getDeletedUsers() {
    return this.http.get('/api/user?deleted=true')
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  editUser(id, data) {
    return this.http.patch(`/api/user/${id}`, data)
      .pipe(tap((res: any) => {
        return res;
      }));
  }

  deleteUser(id) {
    return this.http.delete(`/api/user/${id}`)
      .pipe(
        tap((res: any) => {
          return res;
        })
      );
  }

  secretQuestion(email: string) {
    return this.http.get(`/api/user/secret-question?email=${email}`)
      .pipe(tap((res: any) => {
        return res;
      }));
  }

  secretAnswer(email: string, answer: string, password?: string) {
    return this.http.post('/api/user/secret-answer', { email, answer, password })
      .pipe(tap((res: any) => {
        return res;
      }));
  }

  resendInvite(userId: string, message: string) {
    return this.http.post(`/api/user/${userId}/invitation`, { message })
      .pipe(tap((res: any) => {
        return res;
      }));
  }

  getAvatar(userId) {
    return this.http.get(`/api/user/${userId}/avatar`)
      .pipe(tap((res: any) => {
        return res;
      }));
  }

  updateUserAvatar(userId, avatar) {
    const formData = new FormData();
    formData.append('avatar', avatar, avatar.name);
    return this.http.put(`/api/user/${userId}/avatar`, formData)
      .pipe(tap((res: any) => {
        return res;
      }));
  }

  deleteUserAvatar(userId) {
    return this.http.delete(`/api/user/${userId}/avatar`)
      .pipe(tap((res: any) => {
        return res;
      }));
  }

  deleteUserForever(id) {
    return this.http.delete(`/api/user/${id}?method=hard`)
      .pipe(tap((res: any) => {
        return res;
      }));
  }

  changeRole(url: string) {
    return this.http.patch(url, '')
      .pipe(tap((res: any) => {
        return res;
      }));
  }
}
