const { Router } = require("express");

const filterRouter = require("../filter/filterRouter");
const authentication = require("../../middleware/authentication");
const userController = require("./userController/userController");

const userRouter = new Router();

userRouter.post("/user/login", userController.userLogin);
userRouter.post("/user/finish-registration", userController.finishRegistration);
userRouter.get("/user/secret-question", userController.getSecretQuestion);
userRouter.post("/user/secret-answer", userController.postSecretAnswer);

userRouter.use(authentication());

userRouter.use(filterRouter);

userRouter.put("/user/:id/avatar", userController.putUserAvatarById);
userRouter.get("/user/:id/avatar", userController.getUserAvatarById);
userRouter.delete("/user/:id/avatar", userController.deleteUserAvatarById);
userRouter.get("/user", userController.getUser);
userRouter.get("/user/:id", userController.getUserById);
userRouter.post("/user/byJwt", userController.getUserByJwt);
userRouter.patch("/user/:id", userController.patchUserById);
userRouter.delete("/user/:id", userController.deleteUserById);
userRouter.post("/user", userController.postUser);
userRouter.post("/user/:id/invitation", userController.sendInvitation);

module.exports = userRouter;
