const DxfFileService = require("../dxfFileService");
const TenantService = require("../../tenant/tenantService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const getDxfFile = async (req, res, next) => {
    try {
        let { authUser, query: { tenantId, deleted } } = req;

        deleted = deleted === "true" ? true : false;

        if (authUser.permissions.includes("dxf-file:read:tenant") && authUser.tenantId !== tenantId) throw new appErrors.AuthorizationError();

        if (tenantId !== undefined) {
            await TenantService.getTenantById(tenantId);
            return res.send({ errors: [], value: await DxfFileService.getTenantDxfFiles(tenantId, deleted) });
        }

        return res.send({ errors: [], value: await DxfFileService.getAllDxfFiles(deleted) });
    } catch (error) { return next(error); }
};

const getDxfFileSchema = {
    query: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            tenantId: { type: "string", objectId: true },
            deleted: { type: "string", emun: ["true", "false"] }
        }
    }
};

module.exports = [
    authorization(["dxf-file:read:any", "dxf-file:read:tenant"]),
    requestValidation(getDxfFileSchema),
    getDxfFile
];