const request = require("supertest");
const expect = require("expect");

const { server } = require("../../../../server");
const { users } = require("./seeds");

it("error if password is not provided", async () => {
    const body = { email: "email" };

    const response = await request(server).post("/user/login").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'body' should have required property 'password'");

    expect(value).not.toBeDefined();
});

it("error if email is not provided", async () => {
    const body = { password: "password" };

    const response = await request(server).post("/user/login").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'body' should have required property 'email'");

    expect(value).not.toBeDefined();

});

it("error if password is not valid", async () => {
    const body = { email: "email", password: "pas" };

    const response = await request(server).post("/user/login").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);

    expect(value).not.toBeDefined();
});

it("error if user with provided email not exists", async () => {
    const body = { email: "email", password: "password" };

    const response = await request(server).post("/user/login").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("User not found");

    expect(value).not.toBeDefined();
});

it("error if user is not finished registration", async () => {
    const body = { email: users[4].email, password: "password" };

    const response = await request(server).post("/user/login").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("You need to finish your registration process");

    expect(value).not.toBeDefined();
});

it("error if password doesn't match", async () => {
    const body = { email: users[0].email, password: "passwordAAAA" };

    const response = await request(server).post("/user/login").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Password is invalid");

    expect(value).not.toBeDefined();
});

it("return token if password does match", async () => {
    const body = { email: users[0].email, password: "password" };

    const response = await request(server).post("/user/login").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
});

it("falged as deleted user can't login", async () => {
    const body = { email: users[2].email, password: "password" };

    const response = await request(server).post("/user/login").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("User was deleted");

    expect(value).not.toBeDefined();
});