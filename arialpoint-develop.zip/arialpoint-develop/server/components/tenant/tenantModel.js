const createModel = require("../../db/createModel");

const TenantModel = createModel("tenants");
const LocalUserModel = createModel("users");
const LocalDxfFileModel = createModel("dxffiles");
const LocalAnotationModel = createModel("anotations");

TenantModel.enrichTenant = async (tenant) => {
    if (tenant === null) return tenant;

    const userCount = await LocalUserModel.countDocuments({ tenantId: tenant._id.toString(), deleted: false });
    const foundTenantDxfFiles = await LocalDxfFileModel.findMany({ tenantId: tenant._id.toString(), deleted: false });
    const anotationCount = await foundTenantDxfFiles.reduce(async (acc, cur) => {
        const count = await LocalAnotationModel.countDocuments({ dxfFileId: cur._id.toString(), deleted: false });
        return await acc + count;
    }, 0);

    return { ...tenant, userCount, dxfFileCount: foundTenantDxfFiles.length, anotationCount };
};

TenantModel.enrichTenants = async function (tenants) {
    return await Promise.all(tenants.map((cur) => this.enrichTenant(cur)));
};

TenantModel.findAndEnrichOne = async function (query) {
    const foundOne = await this.findOne(query);
    return await this.enrichTenant(foundOne);
};

TenantModel.findAndEnrichMany = async function (query, limit = 0, skip = 0) {
    const foundMany = await this.findMany(query, limit, skip);
    return this.enrichTenants(foundMany);
};

module.exports = TenantModel;
