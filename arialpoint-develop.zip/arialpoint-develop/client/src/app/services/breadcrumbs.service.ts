import { Injectable } from '@angular/core';
import { filter, map } from 'rxjs/operators';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { BreadcrumbModel } from '../models/breadcrumb.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BreadcrumbsService {

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
  ) { }

  public loadRouting(): Observable<BreadcrumbModel> {
    return this.router.events
      .pipe(
        filter(event => event instanceof NavigationEnd),
        map(() => this.activatedRoute),
        map(route => this.getBreadcrumb(route))
      );
  }

  getUrlFormParents(route: ActivatedRoute): string {
    const urls = [route.snapshot.url.join('')];
    let currentRoute = route;
    while (!!currentRoute.parent) {
      urls.push(currentRoute.parent.snapshot.url.join(''));
      currentRoute = currentRoute.parent;
    }
    return urls.reverse().join('/');
  }

  getBreadcrumb(route: ActivatedRoute): BreadcrumbModel {
    if (route.firstChild) {
      return this.getBreadcrumb(route.firstChild);
    }
    return {
      url: this.getUrlFormParents(route),
      label: route.snapshot.data.breadcrumb,
    };
  }

}
