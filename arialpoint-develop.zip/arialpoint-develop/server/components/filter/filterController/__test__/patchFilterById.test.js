const assert = require("assert");

const request = require("supertest");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { users, filters } = require("./filterController.test");
const FilterModel = require("../../filterModel");

it("error if filter not found", async () => {
    const { body: { value, errors } } = await request(server)
        .patch(`/user/filter/${ObjectId().toString()}`)
        .set("Authorization", users.firstUser.jwt)
        .send({ title: "new title" });

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Filter not found");

    assert.strictEqual(value, undefined);

    const foundFilter = await FilterModel.findOne({ _id: filters.firstUserFilter._id });
    assert.strictEqual(foundFilter.title, filters.firstUserFilter.title);
});

it("error if filter of another user", async () => {
    const { body: { value, errors } } = await request(server)
        .patch(`/user/filter/${filters.secondUserFilter._id.toString()}`)
        .set("Authorization", users.firstUser.jwt)
        .send({ title: "new title" });

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);

    const foundFilter = await FilterModel.findOne({ _id: filters.secondUserFilter._id });
    assert.strictEqual(foundFilter.title, filters.secondUserFilter.title);
});

it("patches filter", async () => {
    const { body: { value, errors } } = await request(server)
        .patch(`/user/filter/${filters.firstUserFilter._id.toString()}`)
        .set("Authorization", users.firstUser.jwt)
        .send({ title: "new title" });

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);

    const foundFilter = await FilterModel.findOne({ _id: filters.firstUserFilter._id });
    assert.strictEqual(foundFilter.title, "new title");
});