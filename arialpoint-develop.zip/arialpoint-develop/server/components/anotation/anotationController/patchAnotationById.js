const AnotationService = require("../anotationService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const fileUpload = require("../../../middleware/fileUpload");
const appErrors = require("../../../utils/appErrors");

const patchAnotationById = async (req, res, next) => {
    try {
        const { authUser, params: { id: anotationId }, formData, files: { file, screenshot } } = req;
        let fileUploadResult = {};
        let screenshotUploadResult = {};
        let fileDeleteResult = {};

        if (formData.deleted !== undefined) formData.deleted = formData.deleted === "true";

        if (formData.deleted === false) await AnotationService.unflagAnotationAsDeleted(anotationId);

        const foundAnotation = await AnotationService.getAnotationById(anotationId);

        if (authUser.permissions.includes("anotation:update:tenant") && authUser.tenantId !== foundAnotation.tenantId) throw new appErrors.AuthorizationError();
        if (authUser.permissions.includes("anotation:update:own") && authUser._id.toString() !== foundAnotation.creatorId) throw new appErrors.AuthorizationError();

        if (file !== undefined) {
            [fileUploadResult] = await Promise.all([
                AnotationService.uploadAnotationFile(file),
                foundAnotation.fileKey !== undefined ? AnotationService.deleteAnotationFile(foundAnotation.fileKey) : null
            ]);
        }

        if (screenshot !== undefined) {
            [screenshotUploadResult] = await Promise.all([
                AnotationService.uploadAnotationScreenshot(screenshot),
                AnotationService.deleteAnotationScreenshot(foundAnotation.screenshot)
            ]);
        }

        if (formData.hasFile === "false" && foundAnotation.fileKey !== undefined) {
            await AnotationService.deleteAnotationFile(foundAnotation.fileKey);
            fileDeleteResult = { fileKey: "", fileName: "", fileSize: "" };
        }

        delete formData.hasFile;

        await AnotationService.updateAnotation(anotationId, { ...formData, ...fileUploadResult, ...screenshotUploadResult }, { ...fileDeleteResult });

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const patchAnotationByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true },
        }
    },
    formData: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            name: { type: "string" },
            text: { type: "string" },
            hasFile: { type: "string", enum: ["false"] },
            deleted: { type: "string", enum: ["true", "false"] },
        }
    }
};

module.exports = [
    authorization(["anotation:update:any", "anotation:update:tenant", "anotation:update:own"]),
    fileUpload({ file: { required: false, extensions: [".doc", ".docx", ".pdf", ".csv", ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff"] }, screenshot: { required: false, extensions: [] } }),
    requestValidation(patchAnotationByIdSchema),
    patchAnotationById
];