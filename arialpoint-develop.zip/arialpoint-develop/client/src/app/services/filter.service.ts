import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { FilterData } from '../models/filter.model';

@Injectable({
  providedIn: 'root'
})
export class FilterService {

  constructor(private http: HttpClient) { }

  createFilter(data: FilterData) {
    return this.http.post('/api/user/filter', data)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  getFilters() {
    return this.http.get('/api/user/filter')
      .pipe(
        tap((res: any) => {
          return res;
        })
      );
  }

  deleteFilter(id: string) {
    return this.http.delete(`/api/user/filter/${id}`)
      .pipe(
        tap((res: any) => {
          return res;
        })
      );
  }

  editFilter(filter: FilterData) {
    const data = {
      title: filter.title,
      description: filter.description,
      users: filter.users,
      date: filter.date
    };
    return this.http.patch(`/api/user/filter/${filter._id}`, data)
      .pipe(tap((res: any) => {
        return res;
      }));
  }
}
