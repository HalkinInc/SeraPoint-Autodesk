import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { InviteDialogComponent } from './invite-dialog/invite-dialog.component';
import { User } from '../../models/user.model';
import { UsersService } from '../../services/users.service';
import { UserTableComponent } from '../user-table/user-table.component';

@Component({
  selector: 'app-invite',
  templateUrl: './invite.component.html',
  styleUrls: ['./invite.component.scss']
})
export class InviteComponent implements OnInit {
  displayedColumns = ['edit', 'firstname', 'lastname', 'tenantId', 'email', 'role'];
  firstName: string;
  lastName: string;
  email: string;
  tenantId: string;
  role: string;
  message: string;
  user: User = new User();

  @ViewChild(UserTableComponent) tableRef: UserTableComponent;

  constructor(
    public dialog: MatDialog,
    private usersService: UsersService
  ) { }

  ngOnInit() {
    this.usersService.getUser()
      .subscribe(res => {
        this.user = res.value;
        this.getUsers(this.user);
        if (this.user.role === 'moderator') {
          this.displayedColumns = ['edit', 'firstname', 'lastname', 'email'];
        }
      });
  }

  openDialog(): void {
    const datas = {
      email: this.email,
      firstName: this.firstName,
      lastName: this.lastName,
      message: this.message,
      role: this.role,
      tenant: this.user.role === 'moderator' ? this.user.tenantName : this.tenantId,
      user: this.user,
      tenantAdmin: this.user.role === 'moderator'
    };
    const dialogRef = this.dialog.open(InviteDialogComponent, {
      width: '685px',
      data: datas
    });

    dialogRef.afterClosed().subscribe(result => {
      this.usersService.inviteUser({
        email: result.email,
        firstname: result.firstName,
        lastname: result.lastName,
        message: result.message,
        tenantName: result.tenant,
        role: result.role
      })
        .subscribe(res => {
          this.getUsers(this.user);
        });
    });
  }

  getUsers(user, search?: string) {
    let id = '';
    if (user.role !== 'root' && user.role !== 'admin') {
      id = user.tenantId;
    }
    this.tableRef.getUsers(id, search);
  }
}
