const AnotationService = require("../anotationService");
const DxfFileService = require("../../dxfFile/dxfFileService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const fileUpload = require("../../../middleware/fileUpload");
const appErrors = require("../../../utils/appErrors");

const postAnotation = async (req, res, next) => {
    try {
        const { authUser, formData, files: { file, screenshot } } = req;

        const foundDxfFile = await DxfFileService.getDxfFileById(formData.dxfFileId);
        if (authUser.permissions.includes("anotation:create:tenant") && authUser.tenantId !== foundDxfFile.tenantId) throw new appErrors.AuthorizationError();

        const uploadResult = await AnotationService.uploadAnotation(file, screenshot);
        await AnotationService.createAnotation({ ...formData, ...uploadResult, creatorId: authUser._id.toString() });

        return res.status(201).send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const postAnotationSchema = {
    formData: {
        type: "object",
        required: ["name", "dxfFileId", "text", "blockIndex"],
        additionalProperties: false,
        properties: {
            name: { type: "string" },
            dxfFileId: { type: "string", objectId: true },
            text: { type: "string" },
            blockIndex: { type: "string" },
        }
    }
};

module.exports = [
    authorization(["anotation:create:any", "anotation:create:tenant"]),
    fileUpload({ file: { required: false, extensions: [".doc", ".docx", ".pdf", ".csv", ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff"] }, screenshot: { required: true, extensions: [] } }),
    requestValidation(postAnotationSchema),
    postAnotation
];