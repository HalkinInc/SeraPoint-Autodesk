const UserService = require("../components/user/userService");

const authentication = () => {
    return async (req, res, next) => {
        try {
            const jwt = req.headers.authorization;

            req.authUser = await UserService.authenticateUser(jwt);

            next();
        } catch (error) { return next(error); }
    };
};

module.exports = authentication;