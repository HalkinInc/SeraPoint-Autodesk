const AnotationService = require("../anotationService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const getAnotationByIdScreenshot = async (req, res, next) => {
    try {
        const { authUser, params: { id } } = req;

        const foundAnotation = await AnotationService.getAnotationById(id);
        if (authUser.permissions.includes("anotation:read:tenant") && authUser.tenantId !== foundAnotation.tenantId) throw new appErrors.AuthorizationError();

        const screenshot = await AnotationService.getAnotationScreenshot(id);

        return res.send({ errors: [], value: screenshot });
    } catch (error) { return next(error); }
};

const getAnotationByIdScreenshotSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true },
        }
    }
};

module.exports = [
    authorization(["anotation:read:any", "anotation:read:tenant"]),
    requestValidation(getAnotationByIdScreenshotSchema),
    getAnotationByIdScreenshot
];
