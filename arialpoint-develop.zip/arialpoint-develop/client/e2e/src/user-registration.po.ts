import { browser, by, element } from 'protractor';

export enum SecretQuestion { animal = 'Your favorite animal?', color = 'Your favorite color?', three = 'Three' }

export class UserRegistrationPage {
  firstnameInput = element(by.name('firstname'));
  lastnameInput = element(by.name('lastname'));
  passwordInput = element(by.name('password'));
  phoneNumberInput = element(by.name('phoneNumber'));
  addressInput = element(by.name('address'));
  cityInput = element(by.name('city'));
  stateInput = element(by.name('state'));
  secretQuestionAnswerInput = element(by.name('secretQuestionAnswer'));
  registerBtn = element(by.name('register'));
  secretSelect = element(by.name('secretQuestionId'));
  secretQuestionOption = (secretQuestionId: SecretQuestion) => element(by.name(secretQuestionId));

  navigateTo() {
    browser.get('/user-registration?code=bWdDQiTRFUS2dTi1p7bq37');
  }

  enterCredentials = (firstname: string, lastname: string, password: string, phoneNumber: string, address: string,
     city: string, state: string, secretQuestionId: SecretQuestion, secretQuestionAnswer: string) => {
      this.firstnameInput.sendKeys(firstname);
      this.lastnameInput.sendKeys(lastname);
      this.passwordInput.sendKeys(password);
      this.phoneNumberInput.sendKeys(phoneNumber);
      this.addressInput.sendKeys(address);
      this.cityInput.sendKeys(city);
      this.stateInput.sendKeys(state);
      this.secretQuestionAnswerInput.sendKeys(secretQuestionAnswer);
      this.secretSelect.click();
      this.secretQuestionOption(secretQuestionId).click();
      this.registerBtn.click();
  }

  clickOnEyeIcon = () => {
    element(by.id('eye-icon')).click();
  }

  getFirstnameErrorValue = () => element(by.id('firstname-error')).getText();
  getLastnameErrorValue = () => element(by.id('lastname-error')).getText();
  getPasswordErrorValue = () => element(by.id('password-error')).getText();
  getPhonenumberErrorValue = () => element(by.id('phoneNumber-error')).getText();
  getAddressErrorValue = () => element(by.id('address-error')).getText();
  getCityErrorValue = () => element(by.id('city-error')).getText();
  getStateErrorValue = () => element(by.id('state-error')).getText();
  getSecretQuestionIdErrorValue = () => element(by.id('secretQuestionId-error')).getText();
  getSecretQuestionAnswerErrorValue = () => element(by.id('secretQuestionAnswer-error')).getText();

  getPasswordType = () => this.passwordInput.getAttribute('type');

  errorMessageSnackbar = () => element.all(by.css('.mat-simple-snackbar span')).first().getText();

  isSecretQuestionOptionVisible = () => element.all(by.css('.mat-option')).isPresent();
}
