const { ObjectId } = require("mongodb");

const FilterModel = require("./filterModel");
const appErrors = require("../../utils/appErrors");

const createFilter = async (creatorId, filter) => {
    await FilterModel.insertOne({ creatorId, ...filter });
};

const getUserFilters = async (id) => {
    return await FilterModel.findMany({ creatorId: id });
};

const deleteFilter = async (id) => {
    await FilterModel.deleteOne({ _id: ObjectId(id) });
};

const updateFilter = async (id, props) => {
    await FilterModel.updateOne({ _id: ObjectId(id) }, { $set: props });
};

const getFilterById = async (id) => {
    const foundFilter = await FilterModel.findOne({ _id: ObjectId(id) });
    if (foundFilter === null) throw new appErrors.NotFoundError("Filter not found");

    return foundFilter;
};

module.exports = {
    createFilter,
    getUserFilters,
    deleteFilter,
    updateFilter,
    getFilterById
};