import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dateDifference'
})
export class DateDifferencePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    const deleteDate = new Date(value);
    const nowDate = new Date();

    const deleteObj = {
      years: deleteDate.getFullYear(),
      months: deleteDate.getMonth(),
      days: deleteDate.getDate(),
      hours: deleteDate.getHours(),
      minutes: deleteDate.getMinutes(),
      seconds: deleteDate.getSeconds()
    };

    const nowObj = {
      years: nowDate.getFullYear(),
      months: nowDate.getMonth(),
      days: nowDate.getDate(),
      hours: nowDate.getHours(),
      minutes: nowDate.getMinutes(),
      seconds: nowDate.getSeconds()
    };

    const key = Object.keys(deleteObj).find(prop => nowObj[prop] - deleteObj[prop] > 0);
    return `${nowObj[key] - deleteObj[key]} ${key} ago`;
  }
}
