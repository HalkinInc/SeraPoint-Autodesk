module.exports = {
    postDxfFile: require("./postDxfFile"),
    getDxfFile: require("./getDxfFile"),
    getDxfFileById: require("./getDxfFileById"),
    patchDxfFileById: require("./patchDxfFileById"),
    deleteDxfFileById: require("./deleteDxfFileById"),
    authenticateAutodesk: require("./authenticateAutodesk"),
    autodesk: require("./autodesk")
};