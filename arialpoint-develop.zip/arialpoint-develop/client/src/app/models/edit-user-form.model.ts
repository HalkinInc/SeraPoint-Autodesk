import { FormControl, FormGroup, Validators } from '@angular/forms';

export class EditUserFormControl extends FormControl {
  label: string;
  modelProperty: string;

  constructor(label: string, property: string, value: any, validator: any) {
    super(value, validator);
    this.label = label;
    this.modelProperty = property;
  }

  getValidationMessages() {
    const messages: string[] = [];
    if (this.errors) {
      for (const errorName in this.errors) {
        if (errorName === 'required') {
          messages.push(`You must enter a ${this.label}`);
        } else if (errorName === 'minlength') {
          messages.push(`A ${this.label} must be at least ${this.errors['minlength'].requiredLength} characters`);
        } else if (errorName === 'maxlength') {
          messages.push(`A ${this.label} must be no more than ${this.errors['maxlength'].requiredLength} characters`);
        } else if (errorName === 'pattern') {
          messages.push(`The ${this.label} contains illegal characters`);
        }
      }
    }
    return messages;
  }
}

export class EditUserFormGroup extends FormGroup {
  constructor() {
    super({
      email: new EditUserFormControl('Enter your email', 'email', '',
        Validators.compose([Validators.required, Validators.email])),
      password: new EditUserFormControl('Enter your password', 'password', '',
        Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(10)])
      )
    });
  }

  get editUserControls(): EditUserFormControl[] {
    return Object.keys(this.controls)
      .map(k => this.controls[k] as EditUserFormControl);
  }

  getFormValidationMessages(form: any): string[] {
    const messages: string[] = [];
    this.editUserControls.forEach(c => c.getValidationMessages()
        .forEach(m => messages.push(m)));
    return messages;
  }
}
