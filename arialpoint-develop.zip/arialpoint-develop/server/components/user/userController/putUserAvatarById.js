const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const fileUpload = require("../../../middleware/fileUpload");
const appErrors = require("../../../utils/appErrors");

const putUserAvatarById = async (req, res, next) => {
    try {
        const { authUser, params: { id }, files: { avatar } } = req;

        const foundUser = await UserService.getUserById(id);

        if (authUser.permissions.includes("user:update:own") && authUser._id.toString() !== foundUser._id.toString()) throw new appErrors.AuthorizationError();

        await UserService.addUserAvatar(id, avatar);

        return res.status(201).send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const putUserAvatarByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            // required
            id: { type: "string", objectId: true }
        }
    }
};

module.exports = [
    authorization(["user:update:any", "user:update:own"]),
    fileUpload({ avatar: { required: true, extensions: [".png", ".jpg", ".jpeg"] } }),
    requestValidation(putUserAvatarByIdSchema),
    putUserAvatarById
];

