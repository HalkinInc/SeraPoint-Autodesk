const authentication = require("../../../middleware/authentication");
const authorization = require("../../../middleware/authorization");
const requestValidation = require("../../../middleware/requestValidation");
const SettingsModel = require("../settingsModel");

const patchSettings = async (req, res, next) => {
    try {
        const { body } = req;
        await SettingsModel.updateOne({ name: "main" }, { $set: { ...body } });
        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const patchSettingsSchema = {
    body: {
        type: "object",
        required: [],
        minProperties: 1,
        additionalProperties: false,
        properties: {
            deletedUsersDaysLimit: { type: "integer" },
            deletedDxfFilesDaysLimit: { type: "integer" },
            deletedAnnotationsDaysLimit: { type: "integer" }
        }
    }
};

module.exports = [
    authentication(),
    authorization(["settings:update"]),
    requestValidation(patchSettingsSchema),
    patchSettings
];