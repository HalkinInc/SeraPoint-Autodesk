const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const getUser = async (req, res, next) => {
    try {
        let { authUser, query: { tenantId, deleted, limit, skip } } = req;
        deleted = deleted === "true" ? true : false;

        if (tenantId !== undefined) {
            if (authUser.permissions.includes("user:read:tenant") && authUser.tenantId !== tenantId) throw new appErrors.AuthorizationError();
            return res.send({ errors: [], value: await UserService.getTenantUsers(tenantId, deleted, limit, skip) });
        }

        if (!authUser.permissions.includes("user:read:any")) throw new appErrors.AuthorizationError();

        return res.send({ errors: [], value: await UserService.getAllUsers(deleted, limit, skip) });
    } catch (error) { return next(error); }
};

const getUserSchema = {
    query: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            tenantId: { type: "string", objectId: true },
            deleted: { type: "string", enum: ["true", "false"] }
        }
    }
};

module.exports = [
    authorization(["user:read:any", "user:read:tenant"]),
    requestValidation(getUserSchema),
    getUser
];