const roles = require("./roles");
const appErrors = require("../utils/appErrors");

const authorization = (routePermissions) => {
    return async (req, res, next) => {
        try {
            const userPermssions = roles[req.authUser.role];

            req.authUser.permissions = [];

            for (let permission of routePermissions) if (userPermssions.includes(permission)) req.authUser.permissions.push(permission);

            if (req.authUser.permissions.length === 0) throw new appErrors.AuthorizationError();

            next();
        } catch (error) { return next(error); }
    };
};

module.exports = authorization;