const { Router } = require("express");

const authentication = require("../../middleware/authentication");
const filterController = require("./filterController/filterController");

const filterRouter = new Router();

filterRouter.use(authentication());

filterRouter.get("/user/filter", filterController.getFilter);
filterRouter.post("/user/filter", filterController.postFilter);
filterRouter.patch("/user/filter/:id", filterController.patchFilterById);
filterRouter.delete("/user/filter/:id", filterController.deleteFilterById);

module.exports = filterRouter;