const assert = require("assert");

const request = require("supertest");
const jsonwebtoken = require("jsonwebtoken");
const config = require("config");

const { server } = require("../../../../server");

it("error if token is not provided", async () => {
    const response = await request(server).get("/tenant");
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Token is not provided");

    assert.strictEqual(value, undefined);
});

it("error if token is not valid", async () => {
    const token = jsonwebtoken.sign("blablabla", config.app.secret);

    const response = await request(server).get("/tenant").set("Authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Supplied token is invalid");

    assert.strictEqual(value, undefined);
});

it("error if token is valid but user with such token not exists", async () => {
    const token = jsonwebtoken.sign({ email: "notRealUser@email.com" }, config.app.secret);

    const response = await request(server).get("/tenant").set("Authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Supplied token is invalid");

    assert.strictEqual(value, undefined);
});