import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { BreadcrumbsService } from '../../services/breadcrumbs.service';
import { BreadcrumbModel } from '../../models/breadcrumb.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class BreadcrumbComponent implements OnInit {
  forwardLinks: Array<string> = new Array();
  breadcrumbs: Array<BreadcrumbModel> = new Array();

  constructor(
    private breadcrumbsService: BreadcrumbsService,
    private router: Router) { }

  goForward(): void {
    if (this.forwardLinks.length) {
      this.router.navigateByUrl(this.forwardLinks[this.forwardLinks.length - 1]);
      this.forwardLinks.pop();
    }
  }

  goBack(): void {
    const lastBreadcrumb = this.breadcrumbs[this.breadcrumbs.length - 2];
    if (lastBreadcrumb) {
      this.router.navigateByUrl(lastBreadcrumb.url);
    }
  }

  clearBreadcrumbs() {
    localStorage.removeItem('routerHistory');
    this.breadcrumbs = [];
    this.forwardLinks = [];
  }

  get allowBreadcrumbs() {
    const token = localStorage.getItem('currentUser');
    return !!token;
  }

  displayBreadcrumbs(route: BreadcrumbModel): void {
    if (!this.allowBreadcrumbs) {
      return this.clearBreadcrumbs();
    }
    if (!route.label) { return; }
    const existedRouteIndex = this.breadcrumbs.findIndex(b => route.url.includes(b.url));
    if (existedRouteIndex >= 0) {
      this.forwardLinks.push(...this.breadcrumbsUrls.slice(existedRouteIndex + 1));
      this.breadcrumbs.splice(existedRouteIndex + 1);
    } else {
      const lastUrl = this.breadcrumbs[this.breadcrumbs.length - 2] && this.breadcrumbs[this.breadcrumbs.length - 2].url;
      const isLastRoute = route.url.includes(lastUrl);
      if (!isLastRoute) {
        this.breadcrumbs = [...this.breadcrumbs, route];
      }
    }
    localStorage.setItem('routerHistory', JSON.stringify(this.breadcrumbs));
  }

  get breadcrumbsUrls(): string[] {
    return this.breadcrumbs.map(b => b.url);
  }

  ngOnInit() {
    const storageBreadcrumbs = localStorage.getItem('routerHistory');
    if (storageBreadcrumbs) {
      this.breadcrumbs = JSON.parse(storageBreadcrumbs);
    }
    this.breadcrumbsService.loadRouting()
      .subscribe((breadcrumb: BreadcrumbModel) => {
        this.displayBreadcrumbs(breadcrumb);
      });
  }
}
