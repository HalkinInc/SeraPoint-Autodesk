const request = require("supertest");
const expect = require("expect");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { users } = require("./seeds");

it("error if user id is invalid", async () => {
    const { body: { value, errors } } = await request(server)
        .delete("/user/12345/avatar")
        .set("Authorization", users[1].jwt);

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'params/id' should be valid 'objectId'");

    expect(value).not.toBeDefined();
});

it("error if user not found", async () => {
    const { body: { value, errors } } = await request(server)
        .delete(`/user/${ObjectId().toString()}/avatar`)
        .set("Authorization", users[1].jwt);

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("User not found");

    expect(value).not.toBeDefined();
});

it("error if user has no avatar", async () => {
    const { body: { value, errors } } = await request(server)
        .delete(`/user/${users[7]._id.toString()}/avatar`)
        .set("Authorization", users[0].jwt);

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("User has no avatar");

    expect(value).not.toBeDefined();
});

it("user:edit:any can delete any user avatar", async () => {
    const { body: { value, errors } } = await request(server)
        .delete(`/user/${users[1]._id.toString()}/avatar`)
        .set("Authorization", users[0].jwt);

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value).toBe(true);
});

it("user:edit:own can delete his avatar", async () => {
    const { body: { value, errors } } = await request(server)
        .delete(`/user/${users[3]._id.toString()}/avatar`)
        .set("Authorization", users[3].jwt);

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value).toBe(true);
});

it("user:edit:own can't delete not his avatar", async () => {
    const { body: { value, errors } } = await request(server)
        .delete(`/user/${users[3]._id.toString()}/avatar`)
        .set("Authorization", users[1].jwt);

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Permission denied");

    expect(value).not.toBeDefined();
});
