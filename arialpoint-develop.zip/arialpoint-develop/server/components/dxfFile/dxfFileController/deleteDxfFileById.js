const DxfFileService = require("../dxfFileService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");

const deleteDxfFileById = async (req, res, next) => {
    try {
        const { params: { id } } = req;

        await DxfFileService.flagDxfFileAsDeleted(id);

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const deleteDxfFileByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true }
        }
    }
};

module.exports = [
    authorization(["dxf-file:delete:any"]),
    requestValidation(deleteDxfFileByIdSchema),
    deleteDxfFileById
];