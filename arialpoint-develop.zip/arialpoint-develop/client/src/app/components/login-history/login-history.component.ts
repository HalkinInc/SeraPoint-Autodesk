import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatSnackBar } from '@angular/material';
import { UsersService } from '../../services/users.service';
import { User } from '../../models/user.model';
import { ResendInviteDialogComponent } from './resend-invite-dialog/resend-invite-dialog.component';

@Component({
  selector: 'app-login-history',
  templateUrl: './login-history.component.html',
  styleUrls: ['./login-history.component.scss']
})
export class LoginHistoryComponent implements OnInit {
  currentUser: User;
  dataSource: MatTableDataSource<User>;
  displayedColumns = ['status', 'firstname', 'lastname', 'tenantId', 'email', 'role'];
  searchUser: string;
  private paginator: MatPaginator;
  private sort: MatSort;
  filteredUsers = false;

  @ViewChild(MatSort) set matSort(ms: MatSort) {
    this.sort = ms;
    this.setDataSourceAttributes();
  }

  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.setDataSourceAttributes();
  }

  constructor(public dialog: MatDialog,
    private usersService: UsersService,
    private snackBar: MatSnackBar) {}

  ngOnInit() {
    this.getCurrentUser();
  }

  setDataSourceAttributes() {
    if (this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
  }

  getCurrentUser() {
    this.usersService.getUser().subscribe((res: IResponseData) => {
      this.currentUser = res.value;
      this.getUsers(res.value);
    });
  }

  getUsers(user: User, search?: string) {
    let id = '';
    if (user.role !== 'root' && user.role !== 'admin') {
      id = user.tenantId;
    }
    this.filteredUsers = !!search;
    return this.usersService.getUsers(id)
      .subscribe((res) => {
          const result = res['value'];
          let filteredTableList: Array<User>;
          result.forEach(element => {
            if (!element.tenant) {
              element.tenant = {
                name: ''
              };
            }
          });

          const pos = this.findCurrentUserPosition(this.currentUser, result);
          result.splice(pos, 1);

          if (search) {
            filteredTableList = this.filteredBySearch(search, result);
          }
          this.dataSource = filteredTableList ?
            new MatTableDataSource(filteredTableList) :
            new MatTableDataSource(result);
      });
  }

  search(search: string) {
    this.getUsers(this.currentUser, search);
  }

  filteredBySearch(search: string, data: Array<User>) {
    search = search.toLowerCase();
    return data.filter((item: User) => {
      return item ? (item.firstname.toLowerCase().indexOf(search) >= 0 || item.lastname.toLowerCase().indexOf(search) >= 0) : false;
    });
  }

  findCurrentUserPosition(user: User, data: Array<User>) {
    return data.findIndex((item: User) => {
      return item._id === user._id;
    });
  }

  onResendInvite(user: User): void {
    const dialogRef = this.dialog.open(ResendInviteDialogComponent, {
      width: '450px',
      data: { firstname: user.firstname, lastname: user.lastname, message: '' }
    });
    dialogRef.afterClosed().subscribe((result: ResendInviteResult) => {
      if (typeof result.answer !== 'undefined' && result.answer) {
        this.usersService.resendInvite(user._id, result.message).subscribe((res: IResendInviteResponse) => {
          this.snackBar.open('Invitation successfully send', '', { duration: 4000 });
        });
      }
    });
  }
}

export class IResponseData {
  constructor(
    public errors: Array<string>,
    public value: User
  ) {}
}
export class ResendInviteResult {
  constructor(
    public answer: boolean,
    public message: string
  ) {}
}
export class IResendInviteResponse {
  constructor(
    public errors: Array<string>,
    public value: boolean
  ) {}
}
