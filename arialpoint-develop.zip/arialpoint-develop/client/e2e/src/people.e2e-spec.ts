import { PeoplePage } from './people.po';
import { sendSeeds } from './seeds';

describe('People', () => {
    let page: PeoplePage;

    beforeEach(async () => {
        page = new PeoplePage();
        await sendSeeds();
    });

    describe('Edit', () => {
        it('root can edit user', () => {
            page.navigateToAsRoot();
            page.clickEdit('kate@legacybeta.com');
            page.enterFirstname('kate@legacybeta.com', 'Kate');
            page.clickSave('kate@legacybeta.com');
            expect(page.getFitstname('kate@legacybeta.com')).toBe('Kate');
        });

        it('admin can edit user', () => {
            page.navigateToAsAdmin();
            page.clickEdit('kate@legacybeta.com');
            page.enterFirstname('kate@legacybeta.com', 'Kate');
            page.clickSave('kate@legacybeta.com');
            expect(page.getFitstname('kate@legacybeta.com')).toBe('Kate');
        });

        it('admin can\'t edit root', () => {
            page.navigateToAsAdmin();
            page.clickEdit('pm@code-care.pro');
            page.enterFirstname('pm@code-care.pro', 'Kate');
            page.clickSave('pm@code-care.pro');
            expect(page.getErrorMessage()).toBe('Permission denied');
        });

        it('moderator can edit user', () => {
            page.navigateToAsModerator();
            page.clickEdit('kate@legacybeta.com');
            page.enterFirstname('kate@legacybeta.com', 'Kate');
            page.clickSave('kate@legacybeta.com');
            expect(page.getFitstname('kate@legacybeta.com')).toBe('Kate');
        });
    });

    describe('Delete', () => {
        it('root can delete user', () => {
            page.navigateToAsRoot();
            page.clickEdit('kate@legacybeta.com');
            page.clickDeleted('kate@legacybeta.com');
            expect(page.doesUserExist('kate@legacybeta.com')).toBeFalsy();
        });

        it('admin can delete user', () => {
            page.navigateToAsAdmin();
            page.clickEdit('kate@legacybeta.com');
            page.clickDeleted('kate@legacybeta.com');
            expect(page.doesUserExist('kate@legacybeta.com')).toBeFalsy();
        });

        it('moderator can delete user', () => {
            page.navigateToAsModerator();
            page.clickEdit('kate@legacybeta.com');
            page.clickDeleted('kate@legacybeta.com');
            expect(page.doesUserExist('kate@legacybeta.com')).toBeFalsy();
        });
    });
});
