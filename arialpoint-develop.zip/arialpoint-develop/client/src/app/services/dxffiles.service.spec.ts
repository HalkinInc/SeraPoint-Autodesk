import { TestBed } from '@angular/core/testing';

import { DXFFilesService } from './dxffiles.service';

describe('DXFFilesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DXFFilesService = TestBed.get(DXFFilesService);
    expect(service).toBeTruthy();
  });
});
