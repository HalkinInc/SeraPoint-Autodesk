const { ObjectId } = require("mongodb");
const jsonwebtoken = require("jsonwebtoken");
const config = require("config");

const tenants = [
    { "_id": ObjectId(), "name": "adminTenant", deleted: false },
    { "_id": ObjectId(), "name": "notAdminTenant", deleted: false },
    { "_id": ObjectId(), "name": "deletedTenant", deleted: true }
];

const dxfFiles = [
    { _id: ObjectId(), name: "adminTenantFile", tenantId: tenants[0]._id.toString(), deleted: false },
    { _id: ObjectId(), name: "notAdminTenantFile", tenantId: tenants[1]._id.toString(), deleted: false },
    { _id: ObjectId(), name: "notAdminTenantFile", tenantId: tenants[1]._id.toString(), deleted: true },
    { _id: ObjectId(), name: "test.dxf", tenantId: tenants[1]._id.toString(), deleted: false }
];

const users = [
    { _id: ObjectId(), email: "root@email.com", password: "password", role: "root", deleted: false, jwt: jsonwebtoken.sign({ email: "root@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "moderator@email.com", password: "password", role: "moderator", tenantId: tenants[0]._id.toString(), deleted: false, jwt: jsonwebtoken.sign({ email: "moderator@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "user@email.com", password: "password", role: "user", tenantId: tenants[0]._id.toString(), deleted: false, jwt: jsonwebtoken.sign({ email: "user@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "deletedUser@email.com", password: "password", role: "user", tenantId: tenants[0]._id.toString(), deleted: true, jwt: jsonwebtoken.sign({ email: "deletedUser@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "userNotAdminTenant@email.com", password: "password", role: "user", tenantId: tenants[1]._id.toString(), deleted: false, jwt: jsonwebtoken.sign({ email: "userNotAdminTenant@email.com", }, config.app.secret) },
];

const anotations = [
    { name: "adminFileAnotation", dxfFileId: dxfFiles[0]._id.toString(), text: "annotationText", creatorId: users[1]._id.toString(), blockIndex: "what is block index?", fileKey: "test fileKey", deleted: false },
    { name: "test.pdf", dxfFileId: dxfFiles[0]._id.toString(), text: "annotationText", creatorId: users[2]._id.toString(), blockIndex: "what is block index?", fileKey: "test fileKey", deleted: false },
    { name: "textAnotation", dxfFileId: dxfFiles[0]._id.toString(), text: "annotationText", creatorId: users[2]._id.toString(), blockIndex: "what is block index?", deleted: false },
    { name: "deletedAnotation", dxfFileId: dxfFiles[0]._id.toString(), text: "annotationText", creatorId: users[2]._id.toString(), blockIndex: "what is block index?", fileKey: "test fileKey", deleted: true },
    { name: "notAdminTenantAnotation", dxfFileId: dxfFiles[1]._id.toString(), text: "annotationText", creatorId: users[4]._id.toString(), blockIndex: "what is block index?", fileKey: "test fileKey", deleted: false }
];

module.exports = {
    tenants,
    dxfFiles,
    users,
    anotations
};