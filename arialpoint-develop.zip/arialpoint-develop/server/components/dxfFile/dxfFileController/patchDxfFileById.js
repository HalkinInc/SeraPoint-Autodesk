const DxfFileService = require("../dxfFileService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");

const patchDxfFileById = async (req, res, next) => {
    try {
        const { params: { id }, body: { fileName, deleted } } = req;

        if (deleted === false) await DxfFileService.unflagDxfFileAsDeleted(id);

        if (fileName !== undefined) await DxfFileService.renameDxfFile(id, fileName);

        res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const patchDxfFileByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true }
        }
    },
    body: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            fileName: { type: "string", minLength: 3, maxLength: 100 },
            deleted: { type: "boolean" }
        }
    }
};

module.exports = [
    authorization(["dxf-file:update:any"]),
    requestValidation(patchDxfFileByIdSchema),
    patchDxfFileById
];