import { HttpClient } from 'protractor-http-client';

const seeds = {
    users: [
        {
            '_id': '5cdd701d5d189d76a1c87887',
            'email': 'pm@code-care.pro',
            'role': 'root',
            'firstname': 'Kateryna',
            'lastname': 'Feoktistova',
            'password': '$2a$10$8AtwmYZaCeVCc.H4RiGgOONlgG25.kGoniDF.wHXtUyp1uLewdO1W',
            'secretQuestionId': 0,
            'secretQuestionAnswer': 'moose',
            'deleted': false,
            'lastActive': 1558016282672,
            'lastLogin': 1558016282383,
            'loginCount': 2
        },
        {
            '_id': '5cdd701d5d189d76a1c87888',
            'email': 'andrii@code-care.pro',
            'role': 'admin',
            'firstname': 'Andrii',
            'lastname': 'Danko',
            'password': '$2a$10$8AtwmYZaCeVCc.H4RiGgOONlgG25.kGoniDF.wHXtUyp1uLewdO1W',
            'secretQuestionId': 0,
            'secretQuestionAnswer': 'cat',
            'deleted': false,
            'lastActive': 1558016235428,
            'lastLogin': 1558016235174,
            'loginCount': 1
        },
        {
            '_id': '5cdd701d5d189d76a1c87889',
            'email': 'alex.semenec@code-care.pro',
            'firstname': 'Alexandr',
            'lastname': 'Semenet',
            'tenantId': '5cdd4415fcc605003b897d7e',
            'role': 'moderator',
            'deleted': false,
            'address': 'Cool Street, 17',
            'city': 'New York',
            'hasAvatar': false,
            'password': '$2a$10$WT6imWpWo5nHadOcYC9nteddJxnQKcwdkA2WkqKV8wYWDnehViBrO',
            'secretQuestionAnswer': 'dog',
            'secretQuestionId': 0,
            'state': 'New York',
            'lastActive': 1558016295402,
            'lastLogin': 1558016295143,
            'loginCount': 2
        },
        {
            '_id': '5cdd701d5d189d76a1c87890',
            'email': 'kate@legacybeta.com',
            'firstname': 'Kateryna',
            'lastname': 'Legacy',
            'tenantId': '5cdd4415fcc605003b897d7e',
            'role': 'user',
            'deleted': false,
            'address': 'Bright Street, 19',
            'city': 'Miami',
            'hasAvatar': false,
            'password': '$2a$10$WT6imWpWo5nHadOcYC9nteddJxnQKcwdkA2WkqKV8wYWDnehViBrO',
            'secretQuestionAnswer': 'hog',
            'secretQuestionId': 0,
            'state': 'Florida',
            'lastActive': 1558016295408,
            'lastLogin': 1558016295178,
            'loginCount': 3
        },
        {
            'email': 'newuser@gmail.com',
            'firstname': 'New',
            'lastname': 'User',
            'role': 'user',
            'tenantId': '5cdaa69907a81b0030f4e5dd',
            'finishRegistrationCode': 'bWdDQiTRFUS2dTi1p7bq37',
            'deleted': false
        }
    ],
    tenants: [
        {
            '_id': '5cdd4415fcc605003b897d7e',
            'name': 'code-care',
            'deleted': false
        }
    ],
    dxfFiles: [
        {
            '_id': '5cdd6df8247493003a1f4144',
            'urn': 'test urn',
            'creatorId': '5cdd6c9c7a0a41ee355bb655',
            'tenantId': '5cdd4415fcc605003b897d7e',
            'fileName': 'Atest.dxf',
            'fileKey': 'e34576a7-6e01-42f7-9d40-02020ef38337.dxf',
            'fileSize': 1779110,
            'createdAt': 1558015479997,
            'deleted': false
        },
        {
            'createdAt': 1558613314911,
            'creatorFirstname': 'Kateryna',
            'creatorId': '5cdd701d5d189d76a1c87887',
            'creatorLastname': 'Feoktistova',
            'deleted': false,
            'fileKey': 'test fileKey',
            'fileName': 'Btest.dxf',
            'fileSize': 4612922,
            'tenantId': '5cdd4415fcc605003b897d7e',
            'tenantName': 'code-care',
            'urn': 'test urn',
            '_id': '5ce68d4233e2f6002918410f'
        },
        {
            'createdAt': 1558613325776,
            'creatorFirstname': 'Kateryna',
            'creatorId': '5cdd701d5d189d76a1c87887',
            'creatorLastname': 'Feoktistova',
            'deleted': false,
            'fileKey': 'test fileKey',
            'fileName': 'EZRoof_halkin_20190213211307.dxf',
            'fileSize': 3186669,
            'tenantId': '5cdd4415fcc605003b897d7e',
            'tenantName': 'code-care',
            'urn': 'test urn',
            '_id': '5ce68d4d33e2f60029184117'
        }
    ],
    anotations: [
        {
            '_id': '5cdd6ec6247493003a1f4170',
            'name': 'Cool annotation',
            'dxfFileId': '5cdd6df8247493003a1f4144',
            'blockIndex': '7498',
            'hasFile': true,
            'text': 'Very cool description',
            'fileName': 'refactoring-improving-existing-2nd.pdf',
            'fileSize': 14043255,
            'screenshot': '6821b0d9-a601-4ac7-9d96-7349f3f037e4',
            'creatorId': '5cdd6c9c7a0a41ee355bb655',
            'createdAt': 1558015686092,
            'deleted': false
        },
        {
            '_id': '5cdeab2c6f0f8c0029d901d1',
            'name': 'User annotation',
            'dxfFileId': '5cdd6df8247493003a1f4144',
            'blockIndex': '9598',
            'hasFile': false,
            'text': 'User description',
            'screenshot': 'b5935a4c-3efd-461b-8dfd-66a4958a2e7c',
            'creatorId': '5cdd701d5d189d76a1c87890',
            'createdAt': 1558096684425,
            'deleted': false,
            'fileName': 'none',
            'fileSize': 0
        }
    ]
};

export const sendSeeds = () => {
    const httpClient: HttpClient = new HttpClient('http://localhost:4200/api');

    return httpClient.post('/aux/seeds', seeds);
};
