import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteDxffilesComponent } from './delete-dxffiles.component';

describe('DeleteDxffilesComponent', () => {
  let component: DeleteDxffilesComponent;
  let fixture: ComponentFixture<DeleteDxffilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteDxffilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteDxffilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
