import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { UsersService, CURRENT_USER } from '../../services/users.service';
import { DomSanitizer } from '@angular/platform-browser';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  headerStyle = {
    'width': '100%',
    'background-color': 'blue'
  };
  currentUser: User;

  constructor(
    private authService: AuthService,
    private usersService: UsersService,
    private sanitizer: DomSanitizer) {
    this.getCurrentUser();
  }

  getCurrentUser() {
    CURRENT_USER.subscribe((res) => {
      this.currentUser = res;
      if (this.currentUser) {
        if (this.currentUser.avatar) {
          this.usersService.getAvatar(this.currentUser._id).subscribe((result) => {
            if (result.value) {
              const datas = new Uint8Array(result.value.Body.data);
              const blob = new Blob([datas], { type: '' });
              const urlCreator = window.URL;
              this.currentUser.avatar = this.sanitizer.bypassSecurityTrustUrl(urlCreator.createObjectURL(blob));
            } else {
              this.currentUser.avatar = 'assets/image/no-photo.png';
            }
          });
        } else {
          this.currentUser.avatar = 'assets/image/no-photo.png';
        }
      }
    });
  }

  logout() {
    CURRENT_USER.next(undefined);
    this.authService.clear();
  }
}
