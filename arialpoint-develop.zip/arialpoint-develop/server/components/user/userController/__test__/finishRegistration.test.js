const request = require("supertest");
const expect = require("expect");

const { server, db } = require("../../../../server");
const { users } = require("./seeds");

it("error if finish registration code is not provided", async () => {
    const body = { additionalFields: { hello: "bye" } };

    const response = await request(server).post("/user/finish-registration").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'body' should have required property 'finishRegistrationCode'");

    expect(value).not.toBeDefined();
});

it("error if additional fields are not provided", async () => {
    const body = { finishRegistrationCode: "hello" };

    const response = await request(server).post("/user/finish-registration").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'body' should have required property 'additionalFields'");

    expect(value).not.toBeDefined();
});

it("error if additional fields are not valid", async () => {
    const body = {
        finishRegistrationCode: users[4].finishRegistrationCode,
        additionalFields: { whatIsThisFild: "don't know" }
    };

    const response = await request(server).post("/user/finish-registration").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);

    expect(value).not.toBeDefined();
});

it("error if finish registration code is not valid", async () => {
    const body = {
        finishRegistrationCode: "notExists",
        additionalFields: {
            address: "address",
            city: "city5",
            state: "state",
            firstname: "firstname",
            lastname: "lastname",
            password: "password",
            phoneNumber: "38097",
            secretQuestionAnswer: "animal",
            secretQuestionId: 1
        }
    };

    const response = await request(server).post("/user/finish-registration").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Finish registration code isn't valid");

    expect(value).not.toBeDefined();
});

it("user is updated if provided data is correct", async () => {
    const body = {
        finishRegistrationCode: users[4].finishRegistrationCode,
        additionalFields: {
            address: "address",
            city: "city5",
            state: "state",
            firstname: "firstname",
            lastname: "lastname",
            password: "password",
            phoneNumber: "38097",
            secretQuestionAnswer: "animal",
            secretQuestionId: 1
        }
    };

    const response = await request(server).post("/user/finish-registration").send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value).toBe(true);

    const userCollection = await (await db).collection("users");
    const foundUser = await userCollection.findOne({ _id: users[4]._id });
    expect(foundUser.city).toBe("city5");
});