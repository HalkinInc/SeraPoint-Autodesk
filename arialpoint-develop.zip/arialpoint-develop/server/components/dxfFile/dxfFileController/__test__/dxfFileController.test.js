const { server, db } = require("../../../../server");
const { tenants, dxfFiles, users } = require("./seeds");

before(async () => await (await db).dropDatabase());

after(() => server.close());

beforeEach(async () => {
    const dbConnection = await db;

    const userCollection = await dbConnection.collection("users");
    await userCollection.deleteMany({});
    await userCollection.insertMany(users);

    const tenantCollection = await dbConnection.collection("tenants");
    await tenantCollection.deleteMany({});
    await tenantCollection.insertMany(tenants);

    const dxfFilesCollection = await dbConnection.collection("dxffiles");
    await dxfFilesCollection.deleteMany({});
    await dxfFilesCollection.insertMany(dxfFiles);
});

describe("AUTHENCTICATION", () => require("./dxfFileAuthentication.test"));

describe("GET /dxf-file", () => require("./getDxfFile.test"));

describe("GET /dxf-file/:id", () => require("./getDxfFileById.test"));

describe("POST /dxf-file", () => require("./postDxfFile.test"));

describe("PATCH /dxf-file", () => require("./patchDxfFileById.test"));

describe("DELETE /dxf-file/:id", () => require("./deleteDxfFileById.test"));
