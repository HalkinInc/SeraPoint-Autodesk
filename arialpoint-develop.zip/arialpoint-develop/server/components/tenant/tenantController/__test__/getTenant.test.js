const assert = require("assert");

const request = require("supertest");

const { server } = require("../../../../server");
const { users } = require("./seeds");

it("tenant:read:tenant can't get all tenants", async () => {
    const token = users[1].jwt;

    const response = await request(server).get("/tenant").set("Authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("tenant:read:any can get all tenants", async () => {
    const token = users[0].jwt;

    const response = await request(server).get("/tenant").set("Authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
});