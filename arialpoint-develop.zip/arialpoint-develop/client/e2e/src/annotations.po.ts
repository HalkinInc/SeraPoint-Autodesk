import { by, element } from 'protractor';
import { LoginPage } from './login.po';

export class AnnotationsPage {
    spinnerEL = element(by.css('div.spinner-block'));
    filesButton = element(by.name('Files-button'));
    annotationButton = element(by.name('Annotation-button'));

    annotationNameInput = element(by.name('annotation-name'));
    annotationDescriptionInput = element(by.name('annotation-description'));
    saveButton = element(by.buttonText('Save'));

    getButton = (annotationName: string, buttonName: string) => element(by.name(annotationName + '-' + buttonName));
    getPreviewButton = (annotationName: string) => this.getButton(annotationName, 'Preview');
    getUpdateButton = (annotationName: string) => this.getButton(annotationName, 'Update');
    getDeleteButton = (annotationName: string) => this.getButton(annotationName, 'Delete');
    getDownloadButton = (annotationName: string) => this.getButton(annotationName, 'Download');

    navigateToAs = (email: string, password: string) => {
        const loginPage = new LoginPage();
        loginPage.navigateTo();
        loginPage.enterCredentials(email, password);
        this.filesButton.click();
        this.annotationButton.click();
    }
    navigateToAsRoot = () => this.navigateToAs('pm@code-care.pro', 'password');
    navigateToAsAdmin = () => this.navigateToAs('andrii@code-care.pro', 'password');
    navigateToAsModerator = () => this.navigateToAs('alex.semenec@code-care.pro', 'password');
    navigateToAsUser = () => this.navigateToAs('kate@legacybeta.com', 'password');

    clickPreview = (name: string) => this.getPreviewButton(name).click();
    isSpinnerVisible = () => this.spinnerEL.isPresent();

    clickUpdate = (name: string) => this.getUpdateButton(name).click();
    enterName = (name: string) => {
        this.annotationNameInput.clear();
        this.annotationNameInput.sendKeys(name);
    }
    enterDescription = (desc: string) => {
        this.annotationDescriptionInput.clear();
        this.annotationDescriptionInput.sendKeys(desc);
    }
    clickSave = () => this.saveButton.click();

    clickDelete = (name: string) => this.getDeleteButton(name).click();
    getAnnotation = (name: string) => element(by.cssContainingText('h4', name));
    isAnnotationPresent = (name: string) => this.getAnnotation(name).isPresent();

    clickDownload = (name: string) => this.getDownloadButton(name).click();
}

