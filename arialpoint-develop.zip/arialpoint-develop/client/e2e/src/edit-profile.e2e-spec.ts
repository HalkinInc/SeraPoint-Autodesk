import { EditProfile } from './edit-profile.po';
import { sendSeeds } from './seeds';
import { browser, protractor } from 'protractor';

describe('Edit profile', () => {
    let page: EditProfile;

    beforeEach(async () => {
        page = new EditProfile();
        await sendSeeds();
    });

    it('should update profile if entered data is correct and update button is clicked', () => {
        page.navigateToAsUser();
        page.enterNewData({
            firstname: 'test-firstname',
            lastname: 'test-lastname',
            email: 'kate@legacybeta.com',
            phone: '777777',
            address: 'test-address',
            city: 'test-city',
            answer: 'test-answer'
        });
        page.clickUpdateButton();
    });

    it('should NOT update profile if entered data is correct and close button is clicked', () => {
        page.navigateToAsUser();
        page.enterNewData({
            firstname: 'test-firstname',
            lastname: 'test-lastname',
            email: 'kate@legacybeta.com',
            phone: '777777',
            address: 'test-address',
            city: 'test-city',
            answer: 'test-answer'
        });
        page.clickCloseButton();
    });
});
