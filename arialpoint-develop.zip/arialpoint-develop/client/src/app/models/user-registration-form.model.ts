import { FormControl, FormGroup, Validators } from '@angular/forms';

export class UserRegistrationFormControl extends FormControl {
  label: string;
  modelProperty: string;

  constructor(label: string, property: string, value: any, validator: any) {
    super(value, validator);
    this.label = label;
    this.modelProperty = property;
  }

  getValidationMessages() {
    const messages: string[] = [];
    if (this.errors) {
      for (const errorName in this.errors) {
        if (errorName === 'required') {
          messages.push(`You must enter a ${this.modelProperty}`);
        } else if (errorName === 'minlength') {
          messages.push(`A ${this.modelProperty} must be at least ${this.errors['minlength'].requiredLength} characters`);
        } else if (errorName === 'maxlength') {
          messages.push(`A ${this.modelProperty} must be no more than ${this.errors['maxlength'].requiredLength} characters`);
        } else if (errorName === 'pattern') {
          messages.push(`The ${this.modelProperty} contains illegal characters`);
        }
      }
    }
    return messages;
  }
}

export class UserRegistrationFormGroup extends FormGroup {
  constructor() {
    super({
      firstname: new UserRegistrationFormControl('Enter your First Name', 'firstname', '',
        Validators.compose([Validators.required, Validators.minLength(3), Validators.pattern('[A-z]+$')])),
      lastname: new UserRegistrationFormControl('Enter your Last Name', 'lastname', '',
        Validators.compose([Validators.required, Validators.minLength(3), Validators.pattern('[A-z]+$')])),
      password: new UserRegistrationFormControl('Enter your password', 'password', '',
        Validators.compose([Validators.required, Validators.minLength(6), Validators.pattern('[!-}]+$')])),
      phoneNumber: new UserRegistrationFormControl('Telephone', 'phone number', '',
        Validators.compose([Validators.required, Validators.minLength(9), Validators.pattern('[0-9]+$')])),
      address: new UserRegistrationFormControl('Address', 'address', '', Validators.required),
      city: new UserRegistrationFormControl('City', 'city', '', Validators.required),
      state: new UserRegistrationFormControl('State', 'state', '', Validators.required),
      secretQuestionId: new UserRegistrationFormControl('Secret Question', 'Secret Question', '', Validators.required),
      secretQuestionAnswer: new UserRegistrationFormControl('Answer', 'Secret Question Answer', '',
        Validators.compose([Validators.required, Validators.minLength(3)]))
    });
  }

  get userRegistrationControls(): UserRegistrationFormControl[] {
    return Object.keys(this.controls)
      .map(k => this.controls[k] as UserRegistrationFormControl);
  }

  getFormValidationMessages(form: any): string[] {
    const messages: string[] = [];
    this.userRegistrationControls.forEach(c => c.getValidationMessages()
        .forEach(m => messages.push(m)));
    return messages;
  }
}
