const appErrors = require("../utils/appErrors");
const logger = require("../utils/logger");

module.exports = () => {
    return (err, req, res, next) => {
        if (err instanceof appErrors.AppError) {
            return res.status(err.statusCode).send({ errors: [err.message] });
        }

        if (process.env.NODE_ENV === "development" || process.env.NODE_ENV === "test") {
            if (err instanceof Error) {
                logger.error(err, "Unknown error");
                return res.status(500).send({ errors: ["Tell backend developer about this error", err.message] });
            }

            logger.error(err, "This error shouldn't exist");
            return res.status(500).send({ errors: ["Tell backend developer about this error", "Internal server error"] });
        }

        logger.error(err, "Unknown error");

        return res.status(500).send({ errors: ["Internal server error"] });
    };
};