const UserService = require("../userService");
const TenantService = require("../../tenant/tenantService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const postUser = async (req, res, next) => {
    try {
        const { authUser, body: { firstname, lastname, email, role, tenantName, message = "" } } = req;

        if (!authUser.permissions.includes("moderator:create:any") && !authUser.permissions.includes("moderator:create:tenant") && role === "moderator") throw new appErrors.AuthorizationError();
        if (!authUser.permissions.includes("admin:create:any") && role === "admin") throw new appErrors.AuthorizationError();

        const newUser = { email, firstname, lastname, role };

        if (["moderator", "user"].includes(role)) {
            if (tenantName === undefined) throw new appErrors.RequestError("'body' should have required property 'tenantName'");

            if (role === "moderator" && !await TenantService.checkIfTenantExists(tenantName)) await TenantService.createTenant(tenantName);

            const foundTenant = await TenantService.getTenantByName(tenantName);
            if (authUser.permissions.includes("user:create:tenant") && !authUser.permissions.includes("moderator:create:tenant") && authUser.tenantId !== foundTenant._id.toString()) throw new appErrors.AuthorizationError();

            newUser.tenantId = foundTenant._id.toString();
        }

        await UserService.startRegistration(newUser, message, authUser);

        return res.status(201).send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const postUserSchema = {
    body: {
        type: "object",
        required: ["email", "role", "firstname", "lastname"],
        additionalProperties: false,
        properties: {
            // required
            email: { type: "string" },
            role: { type: "string", enum: ["admin", "moderator", "user"] },
            tenantName: { type: "string" },
            firstname: { type: "string" },
            lastname: { type: "string" },
            message: { type: "string" }
        }
    }
};

module.exports = [
    authorization(["admin:create:any", "moderator:create:any", "moderator:create:tenant", "user:create:any", "user:create:tenant"]),
    requestValidation(postUserSchema),
    postUser
];