import { browser, by, element } from 'protractor';
const path = require('path');
import { LoginPage } from './login.po';

export class TenantsPage {
    private okButton = element(by.name('confirm-ok'));
    private noButton = element(by.name('confirm-no'));
    private browseInput = element(by.name('browse-dxf-file'));
    private saveButton = element(by.name('save-dxf-file'));

    private getElement = (tenant: string, name: string) => element(by.name(tenant + '-' + name));
    private getDeleteButton = (tenant: string) => this.getElement(tenant, 'delete');
    private getLoopIcon = (tenant: string) => this.getElement(tenant, 'loop-icon');
    private getArrowIcon = (tenant: string) => this.getElement(tenant, 'arrow-icon');
    private getDxfFilesCountCell = (tenant: string) => this.getElement(tenant, 'dxf-files-count');

    private getTooltipByText = (text: string) => element(by.cssContainingText('.mat-tooltip', text));

    private navigateToAs = (email: string, password: string) => {
        const loginPage = new LoginPage();
        loginPage.navigateTo();
        loginPage.enterCredentials(email, password);
        element(by.name('Tenants-button')).click();
    }

    navigateToAsRoot = () => this.navigateToAs('pm@code-care.pro', 'password');
    navigateToAsAdmin = () => this.navigateToAs('andrii@code-care.pro', 'password');

    clickDeleteButton = (tenant: string) => this.getDeleteButton(tenant).click();
    clickOkButton = () => this.okButton.click();
    clickNoButton = () => this.noButton.click();

    doesTenantExist = (tenant: string) => this.getDeleteButton(tenant).isPresent();

    hoverLoopIcon = (tenant: string) => browser.actions().mouseMove(this.getLoopIcon(tenant)).perform();
    doesTooltipVisible = (text: string) => this.getTooltipByText(text).isDisplayed();

    clickLoopIcon = (tenant: string) => this.getLoopIcon(tenant).click();

    isTenantPage = async () => (await browser.getCurrentUrl()).includes('/tenant/');

    hoverArrowIcon = (tenant: string) => browser.actions().mouseMove(this.getArrowIcon(tenant)).perform();

    clickArrowIcon = (tenant: string) => this.getArrowIcon(tenant).click();
    browseFile = () => this.browseInput.sendKeys(path.resolve(__dirname, './tenants.dxf'));
    clickSaveButton = () => this.saveButton.click();
    getDxfFilesCount = (tenant: string) => this.getDxfFilesCountCell(tenant).getText();
}
