const assert = require("assert");
const path = require("path");

const request = require("supertest");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { dxfFiles, users } = require("./seed");

it("error if wrong anotation file extension", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/anotation")
        .set("authorization", users[0].jwt)
        .attach("screenshot", path.resolve(__dirname, "screenshot.jpg"))
        .attach("file", path.resolve(__dirname, "test.dxf"))
        .field("name", "name")
        .field("text", "text");

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'formData/file' should have ['.doc', '.docx', '.pdf', '.csv', '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff'] file extension");

    assert.strictEqual(value, undefined);
});

it("error if screenshot is not provided", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/anotation")
        .set("authorization", users[0].jwt)
        .attach("file", path.resolve(__dirname, "test.png"))
        .field("name", "name")
        .field("dxfFileId", dxfFiles[0]._id.toString())
        .field("text", "text")
        .field("blockIndex", "blockIndex");

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'formData/screenshot' should be a file");

    assert.strictEqual(value, undefined);
});

it("error if dxf file id is invalid", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/anotation")
        .set("authorization", users[0].jwt)
        .attach("screenshot", path.resolve(__dirname, "screenshot.jpg"))
        .attach("file", path.resolve(__dirname, "test.png"))
        .field("name", "name")
        .field("dxfFileId", "123")
        .field("text", "text");

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'formData/dxfFileId' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if dxf file with provided id doesn't exsist", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/anotation")
        .set("authorization", users[0].jwt)
        .attach("screenshot", path.resolve(__dirname, "screenshot.jpg"))
        .attach("file", path.resolve(__dirname, "test.png"))
        .field("name", "name")
        .field("dxfFileId", ObjectId().toString())
        .field("text", "text")
        .field("blockIndex", "blockIndex");

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Dxf file not found");

    assert.strictEqual(value, undefined);
});

it("anotation:create:tenant can't add anotation to dxf file of not his tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/anotation")
        .set("authorization", users[1].jwt)
        .attach("screenshot", path.resolve(__dirname, "screenshot.jpg"))
        .attach("file", path.resolve(__dirname, "test.png"))
        .field("name", "name")
        .field("dxfFileId", dxfFiles[1]._id.toString())
        .field("text", "text")
        .field("blockIndex", "blockIndex");

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("error if dxf file with provided id is deleted", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/anotation")
        .set("authorization", users[0].jwt)
        .attach("screenshot", path.resolve(__dirname, "screenshot.jpg"))
        .attach("file", path.resolve(__dirname, "test.png"))
        .field("dxfFileId", dxfFiles[2]._id.toString())
        .field("name", "name")
        .field("text", "text")
        .field("blockIndex", "blockIndex");

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Dxf file was deleted");

    assert.strictEqual(value, undefined);
});

it("anotation:create:any can add any anotation", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/anotation")
        .set("authorization", users[0].jwt)
        .attach("screenshot", path.resolve(__dirname, "screenshot.jpg"))
        .attach("file", path.resolve(__dirname, "test.png"))
        .field("name", "name")
        .field("dxfFileId", dxfFiles[0]._id.toString())
        .field("text", "text")
        .field("blockIndex", "blockIndex");

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});

it("anotation:create:tenant can add anotation to dxf file of his tenant", async () => {
    const { body: { errors, value } } = await request(server)
        .post("/anotation")
        .set("authorization", users[1].jwt)
        .attach("screenshot", path.resolve(__dirname, "screenshot.jpg"))
        .attach("file", path.resolve(__dirname, "test.png"))
        .field("name", "name")
        .field("dxfFileId", dxfFiles[0]._id.toString())
        .field("text", "text")
        .field("blockIndex", "blockIndex");

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});