const createModel = require("../../db/createModel");

module.exports = createModel("settings");
