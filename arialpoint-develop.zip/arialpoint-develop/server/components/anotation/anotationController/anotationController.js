module.exports = {
    postAnotation: require("./postAnotation"),
    getAnotation: require("./getAnotation"),
    getAnotationById: require("./getAnotationById"),
    getAnotationByIdScreenshot: require("./getAnotationByIdScreenshot"),
    patchAnotationById: require("./patchAnotationById"),
    deleteAnotationById: require("./deleteAnotationById")
};