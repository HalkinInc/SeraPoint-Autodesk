const { ObjectId } = require("mongodb");

const createModel = require("../../db/createModel");

const AnotationModel = createModel("anotations");
const LocalUserModel = createModel("users");
const LocalDxfFilesModel = createModel("dxffiles");
const LocalTenantModel = createModel("tenants");

AnotationModel.enrichAnotation = async (anotation) => {
    if (anotation === null) return anotation;

    const enrichedAnotation = { ...anotation };

    const foundCreator = await LocalUserModel.findOne({ _id: ObjectId(enrichedAnotation.creatorId) });
    if (foundCreator !== null) {
        enrichedAnotation.creatorFirstname = foundCreator.firstname;
        enrichedAnotation.creatorLastname = foundCreator.lastname;
    }

    const foundDxfFile = await LocalDxfFilesModel.findOne({ _id: ObjectId(enrichedAnotation.dxfFileId) });
    if (foundDxfFile !== null) {
        enrichedAnotation.dxfFileName = foundDxfFile.fileName;
        enrichedAnotation.tenantId = foundDxfFile.tenantId;

        const foundTenant = await LocalTenantModel.findOne({ _id: ObjectId(foundDxfFile.tenantId) });
        if (foundTenant !== null) enrichedAnotation.tenantName = foundTenant.name;
    }

    return enrichedAnotation;
};

AnotationModel.findAndEnrichOne = async function (query) {
    const foundOne = await this.findOne(query);
    return await this.enrichAnotation(foundOne);
};

AnotationModel.enrichAnotations = async function (anotations) {
    return await Promise.all(anotations.map((cur) => this.enrichAnotation(cur)));
};

AnotationModel.findAndEnrichMany = async function (query, limit = 0, skip = 0) {
    const foundMany = await this.findMany(query, limit, skip);
    return this.enrichAnotations(foundMany);
};

module.exports = AnotationModel;
