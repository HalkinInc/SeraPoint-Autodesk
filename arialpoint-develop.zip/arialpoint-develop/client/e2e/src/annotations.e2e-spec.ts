import { AnnotationsPage } from './annotations.po';
import { sendSeeds } from './seeds';

describe('Annotations', () => {
    let page: AnnotationsPage;

    beforeEach(async () => {
        page = new AnnotationsPage();
        await sendSeeds();
    });

    describe('Preview', () => {
        it('root can preview annotation', () => {
            page.navigateToAsRoot();
            page.clickPreview('Cool annotation');
            expect(page.isSpinnerVisible()).toBeTruthy();
        });

        it('admin can preview annotation', () => {
            page.navigateToAsAdmin();
            page.clickPreview('Cool annotation');
            expect(page.isSpinnerVisible()).toBeTruthy();
        });

        it('moderator can preview annotation', () => {
            page.navigateToAsModerator();
            page.clickPreview('Cool annotation');
            expect(page.isSpinnerVisible()).toBeTruthy();
        });

        it('user can preview annotation', () => {
            page.navigateToAsUser();
            page.clickPreview('Cool annotation');
            expect(page.isSpinnerVisible()).toBeTruthy();
        });
    });

    // describe('Update', () => {
    //     it('root can update annotation', () => {
    //         page.navigateToAsRoot();
    //         page.clickUpdate('Cool annotation');
    //         page.enterName('new name');
    //         page.enterDescription('new desc');
    //         page.clickSave();
    //     });
    // });

    describe('Delete', () => {
        it('root can delete annotation', () => {
            page.navigateToAsRoot();
            expect(page.isAnnotationPresent('Cool annotation')).toBeTruthy();
            page.clickDelete('Cool annotation');
            expect(page.isAnnotationPresent('Cool annotation')).toBeFalsy();
        });

        it('admin can delete annotation', () => {
            page.navigateToAsAdmin();
            expect(page.isAnnotationPresent('Cool annotation')).toBeTruthy();
            page.clickDelete('Cool annotation');
            expect(page.isAnnotationPresent('Cool annotation')).toBeFalsy();
        });

        it('moderator can delete annotation', () => {
            page.navigateToAsModerator();
            expect(page.isAnnotationPresent('Cool annotation')).toBeTruthy();
            page.clickDelete('Cool annotation');
            expect(page.isAnnotationPresent('Cool annotation')).toBeFalsy();
        });

        it('user can delete his annotation', () => {
            page.navigateToAsUser();
            expect(page.isAnnotationPresent('User annotation')).toBeTruthy();
            page.clickDelete('User annotation');
            expect(page.isAnnotationPresent('User annotation')).toBeFalsy();
        });

        it('user can\'t delete not his annotation', () => {
            page.navigateToAsUser();
            expect(page.isAnnotationPresent('Cool annotation')).toBeTruthy();
            page.clickDelete('Cool annotation');
            expect(page.isAnnotationPresent('Cool annotation')).toBeTruthy();
        });
    });

    describe('Download', () => {
        it('root can download annotation', () => {
            page.navigateToAsRoot();
            page.clickDownload('Cool annotation');
        });

        it('admin can download annotation', () => {
            page.navigateToAsAdmin();
            page.clickDownload('Cool annotation');
        });

        it('moderator can download annotation', () => {
            page.navigateToAsModerator();
            page.clickDownload('Cool annotation');
        });

        it('user can download annotation', () => {
            page.navigateToAsUser();
            page.clickDownload('Cool annotation');
        });
    });
});
