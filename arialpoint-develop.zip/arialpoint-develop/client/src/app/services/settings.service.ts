import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SettingsService {

  constructor(private http: HttpClient) { }

  getSettings() {
    return this.http.get(`/api/aux/settings`)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  updateSettings(propName: string, data: number) {
    const body = new Object();
    body[propName] = data;
    return this.http.patch(`/api/aux/settings`, body)
      .pipe(tap((res: any) => {
        return res;
      }));
  }
}
