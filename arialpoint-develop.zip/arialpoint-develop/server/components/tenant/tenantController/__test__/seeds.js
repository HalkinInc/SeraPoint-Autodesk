const { ObjectId } = require("mongodb");
const jsonwebtoken = require("jsonwebtoken");
const config = require("config");

const tenants = [
    { "_id": ObjectId(), "name": "adminTenant", deleted: false },
    { "_id": ObjectId(), "name": "notAdminTenant", deleted: false },
    { "_id": ObjectId(), "name": "deletedTenant", deleted: true }
];

const users = [
    { _id: ObjectId(), email: "root@email.com", password: "$2a$10$ZNADAf5Er2kyUlMCF9gCGO.MUQhLCIsyBv231AbGfjw6PkAU9zs9m", role: "root", deleted: false, jwt: jsonwebtoken.sign({ email: "root@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "moderator@email.com", password: "password", role: "moderator", tenantId: tenants[0]._id.toString(), deleted: false, jwt: jsonwebtoken.sign({ email: "moderator@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "deleted@email.com", password: "password", role: "user", deleted: true, jwt: jsonwebtoken.sign({ email: "user@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "user@email.com", password: "password", role: "user", tenantName: "userTenant", deleted: false, jwt: jsonwebtoken.sign({ email: "user@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "registrationIsNotFinished@email.com", role: "user", tenantName: "userTenant", finishRegistrationCode: "correctCode", deleted: false, },
    { _id: ObjectId(), email: "adminTenantUser@email.com", password: "password", role: "user", tenantId: tenants[0]._id.toString(), deleted: false, jwt: jsonwebtoken.sign({ email: "adminTenantUser@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "anotherAdmin@email.com", password: "password", role: "moderator", deleted: false, jwt: jsonwebtoken.sign({ email: "anotherAdmin@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "anotherUser@email.com", password: "password", role: "user", tenantName: "AnotherUserTenant", deleted: false, jwt: jsonwebtoken.sign({ email: "anotherUser@email.com", }, config.app.secret) }
];

module.exports = {
    tenants,
    users
};