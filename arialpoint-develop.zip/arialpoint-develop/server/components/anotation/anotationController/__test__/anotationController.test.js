const { server, db } = require("../../../../server");
const { tenants, dxfFiles, users, anotations } = require("./seed");

before(async () => await (await db).dropDatabase());

after(() => server.close());

beforeEach(async () => {
    const dbConnection = await db;

    const userCollection = await dbConnection.collection("users");
    await userCollection.deleteMany({});
    await userCollection.insertMany(users);

    const tenantCollection = await dbConnection.collection("tenants");
    await tenantCollection.deleteMany({});
    await tenantCollection.insertMany(tenants);

    const dxfFilesCollection = await dbConnection.collection("dxffiles");
    await dxfFilesCollection.deleteMany({});
    await dxfFilesCollection.insertMany(dxfFiles);

    const anotationCollection = await dbConnection.collection("anotations");
    await anotationCollection.deleteMany({});
    await anotationCollection.insertMany(anotations);
});

describe("AUTHENTICATION", () => require("./anotationAuthentication.test"));

describe("GET /anotation", () => require("./getAnotation.test"));

describe("GET /anotation/:id", () => require("./getAnotationById.test"));

describe("GET /anotation/:id/screenshot", () => require("./getAnotationByIdScreenshot.test"));

describe("POST /anotation", () => require("./postAnotation.test"));

describe("PATCH /anotation/:id", () => require("./patchAnotationById.test"));

describe("DELETE /anotation/:id", () => require("./deleteAnotationById.test"));