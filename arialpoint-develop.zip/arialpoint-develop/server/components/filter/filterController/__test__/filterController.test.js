const assert = require("assert");

const request = require("supertest");
const { ObjectId } = require("mongodb");
const jsonwebtoken = require("jsonwebtoken");
const config = require("config");

const { server, db } = require("../../../../server");

const users = {
    firstUser: { _id: ObjectId(), email: "user1@email.com", jwt: jsonwebtoken.sign({ email: "user1@email.com" }, config.app.secret) },
    secondUser: { _id: ObjectId(), email: "user2@email.com", jwt: jsonwebtoken.sign({ email: "user2@email.com" }, config.app.secret) }
};

const filters = {
    firstUserFilter: { _id: ObjectId(), title: "filer1", creatorId: users.firstUser._id.toString(), description: "description1", users: ["user1", "user2"], date: "date1" },
    secondUserFilter: { _id: ObjectId(), title: "filer2", creatorId: users.secondUser._id.toString(), description: "description2", users: ["user3", "user4"], date: "date2" }
};

module.exports = { users, filters };

before(async () => await (await db).dropDatabase());

beforeEach(async () => {
    const dataBase = await db;

    await dataBase.collection("users").deleteMany({});
    await dataBase.collection("users").insertMany(Object.values(users));

    await dataBase.collection("filters").deleteMany({});
    await dataBase.collection("filters").insertMany(Object.values(filters));
});

after(() => server.close());

describe("AUTHENTICATION", () => {
    it("error if token is not proived", async () => {
        const { body: { value, errors } } = await request(server)
            .get("/user/filter");

        assert.strictEqual(errors.length, 1);
        assert.strictEqual(errors[0], "Token is not provided");

        assert.strictEqual(value, undefined);
    });

    it("error if token is not valid", async () => {
        const { body: { value, errors } } = await request(server)
            .get("/user/filter")
            .set("Authorization", jsonwebtoken.sign("blablabla", config.app.secret));

        assert.strictEqual(errors.length, 1);
        assert.strictEqual(errors[0], "Supplied token is invalid");

        assert.strictEqual(value, undefined);
    });
});

describe("POST /user/filter", () => require("./postFilter.test"));
describe("GET /user/filter", () => require("./getFilter.test"));
describe("PATCH /user/filter/:id", () => require("./patchFilterById.test"));
describe("DELETE /user/filter/:id", () => require("./deleteFilterById.test"));