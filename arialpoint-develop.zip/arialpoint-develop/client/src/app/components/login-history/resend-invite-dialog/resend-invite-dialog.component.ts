import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ResendInviteDialogData } from '../../../models/resend-invite.model';

@Component({
  selector: 'app-resend-invite-dialog',
  templateUrl: './resend-invite-dialog.component.html',
  styleUrls: ['./resend-invite-dialog.component.scss']
})
export class ResendInviteDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<ResendInviteDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ResendInviteDialogData) {}

  onNoClick(answer: boolean): void {
    this.dialogRef.close({ answer, message: this.data.message });
  }
}
