import { DxfFilesPage } from './dxf-files.po';
import { sendSeeds } from './seeds';
import { browser, ExpectedConditions as EC } from 'protractor';

describe('Dxf files', () => {
    let page: DxfFilesPage;

    beforeEach(async () => {
        page = new DxfFilesPage();
        await sendSeeds();
    });

    describe('Check sorting:', () => {
        describe('Super admin', () => {
            it('files should be sorted from Newest to Oldest by default', () => {
                page.navigateToAsRoot();
                page.filter.click();
                expect(page.checkFilterDefaultOption('mat-selected')).toBe('Sort By: Newest');
            });

            it('should files are sorted from Oldest to Newest', () => {
                page.navigateToAsRoot();
                page.filter.click();
                expect(page.checkFilterByOldest()).toBe('May 16, 2019');
            });

            it('should files are sorted from file names started with "a" to "z"', () => {
                page.navigateToAsRoot();
                page.filter.click();
                expect(page.checkFilterByName()).toBe('Atest.dxf');
            });

            it('should files are sorted from largest to smallest', () => {
                page.navigateToAsRoot();
                page.filter.click();
                expect(page.checkFilterBySize()).toBe('Btest.dxf');
            });
        });

        describe('Admin', () => {
            it('files should be sorted from Newest to Oldest by default', () => {
                page.navigateToAsAdmin();
                page.filter.click();
                expect(page.checkFilterDefaultOption('mat-selected')).toBe('Sort By: Newest');
            });

            it('should files are sorted from Oldest to Newest', () => {
                page.navigateToAsAdmin();
                page.filter.click();
                expect(page.checkFilterByOldest()).toBe('May 16, 2019');
            });

            it('should files are sorted from file names started with "a" to "z"', () => {
                page.navigateToAsAdmin();
                page.filter.click();
                expect(page.checkFilterByName()).toBe('Atest.dxf');
            });

            it('should files are sorted from largest to smallest', () => {
                page.navigateToAsAdmin();
                page.filter.click();
                expect(page.checkFilterBySize()).toBe('Btest.dxf');
            });
        });

        describe('Moderator', () => {
            it('files should be sorted from Newest to Oldest by default', () => {
                page.navigateToAsModerator();
                page.filter.click();
                expect(page.checkFilterDefaultOption('mat-selected')).toBe('Sort By: Newest');
            });

            it('should files are sorted from Oldest to Newest', () => {
                page.navigateToAsModerator();
                page.filter.click();
                expect(page.checkFilterByOldest()).toBe('May 16, 2019');
            });

            it('should files are sorted from file names started with "a" to "z"', () => {
                page.navigateToAsModerator();
                page.filter.click();
                expect(page.checkFilterByName()).toBe('Atest.dxf');
            });

            it('should files are sorted from largest to smallest', () => {
                page.navigateToAsModerator();
                page.filter.click();
                expect(page.checkFilterBySize()).toBe('Btest.dxf');
            });
        });

        describe('Standard User', () => {
            it('files should be sorted from Newest to Oldest by default', () => {
                page.navigateToAsUser();
                page.filter.click();
                expect(page.checkFilterDefaultOption('mat-selected')).toBe('Sort By: Newest');
            });

            it('should files are sorted from Oldest to Newest', () => {
                page.navigateToAsUser();
                page.filter.click();
                expect(page.checkFilterByOldest()).toBe('May 16, 2019');
            });

            it('should files are sorted from file names started with "a" to "z"', () => {
                page.navigateToAsUser();
                page.filter.click();
                expect(page.checkFilterByName()).toBe('Atest.dxf');
            });

            it('should files are sorted from largest to smallest', () => {
                page.navigateToAsUser();
                page.filter.click();
                expect(page.checkFilterBySize()).toBe('Btest.dxf');
            });
        });
    });

    describe('Check Files buttons', () => {
        describe('Preview', () => {
            it('root can preview dxf file', () => {
                page.navigateToAsRoot();
                page.clickPreview();
                expect(page.isSpinnerVisible()).toBeTruthy();
            });

            it('admin can preview dxf file', () => {
                page.navigateToAsAdmin();
                page.clickPreview();
                expect(page.isSpinnerVisible()).toBeTruthy();
            });

            it('moderator can preview dxf file', () => {
                page.navigateToAsModerator();
                page.clickPreview();
                expect(page.isSpinnerVisible()).toBeTruthy();
            });

            it('user can preview dxf file', () => {
                page.navigateToAsUser();
                page.clickPreview();
                expect(page.isSpinnerVisible()).toBeTruthy();
            });
        });

        describe('Update', () => {
            it('root can update dxf file', () => {
                page.navigateToAsRoot();
                page.clickUpdate();
                page.enterFilename('newname.dxf');
                page.clickSave();
                expect(page.isFilePresent('newname.dxf')).toBeTruthy();
            });

            it('admin can update dxf file', () => {
                page.navigateToAsAdmin();
                page.clickUpdate();
                page.enterFilename('newname.dxf');
                page.clickSave();
                expect(page.isFilePresent('newname.dxf')).toBeTruthy();
            });

            it('moderator can update dxf file', () => {
                page.navigateToAsModerator();
                page.clickUpdate();
                page.enterFilename('newname.dxf');
                page.clickSave();
                expect(page.isFilePresent('newname.dxf')).toBeTruthy();
            });

            it('user can update dxf file', () => {
                page.navigateToAsUser();
                page.clickUpdate();
                page.enterFilename('newname.dxf');
                page.clickSave();
                expect(page.isFilePresent('newname.dxf')).toBeTruthy();
            });
        });

        describe('Delete', () => {
            it('root can delete dxf file', () => {
                page.navigateToAsRoot();
                expect(page.isFilePresent('EZRoof_halkin_20190213211307.dxf')).toBeTruthy();
                page.clickDelete();
                expect(page.isFilePresent('EZRoof_halkin_20190213211307.dxf')).toBeFalsy();
            });

            it('moderator can delete dxf file', () => {
                page.navigateToAsAdmin();
                expect(page.isFilePresent('EZRoof_halkin_20190213211307.dxf')).toBeTruthy();
                page.clickDelete();
                expect(page.isFilePresent('EZRoof_halkin_20190213211307.dxf')).toBeFalsy();
            });
        });
    });

    describe('Check Filter by Name', () => {
        describe('Super Admin', () => {
            it('should open filter window after click on Filter button', () => {
                page.navigateToAsAdmin();
                page.filterBtn.click();
                expect(page.filterCardIsVisible()).toBeTruthy();
            });
        });
    });
});
