import { browser, by, element } from 'protractor';

export class LoginPage {
  navigateTo() {
    browser.get('/login');
  }

  enterCredentials = (login: string, password: string) => {
    element(by.name('email')).sendKeys(login);
    element(by.name('password')).sendKeys(password);
    element(by.name('login')).click();
  }

  getEmailErrorValue = () => element(by.id('email-error')).getText();

  getPasswordErrorValue = () => element(by.id('password-error')).getText();

  isPasswordErrorVisible = () => element(by.id('password-error')).isPresent();

  isLoginErrorVisible = () => element(by.id('login-error')).isPresent();

  errorMessageSnackbar = () => element.all(by.css('.mat-simple-snackbar span')).first().getText();
}
