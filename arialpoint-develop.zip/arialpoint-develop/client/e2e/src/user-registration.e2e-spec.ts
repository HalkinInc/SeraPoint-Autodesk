import { browser } from 'protractor';
import { UserRegistrationPage, SecretQuestion } from './user-registration.po';
import { sendSeeds } from './seeds';

describe('User Registration', () => {
  let page: UserRegistrationPage;

  beforeEach(async () => {
    page = new UserRegistrationPage();
    await sendSeeds();
  });

  it('should successfully register with correct fields', () => {
    page.navigateTo();
    page.enterCredentials('Alex', 'Semenets', 'password', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
    expect(browser.getCurrentUrl()).toContain('/login');
  });

  describe('First Name and Last Name fields:', () => {
    it('should alert if fill in numbers in surname and name fields', () => {
      page.navigateTo();
      page.enterCredentials('new1234user', 'new1234user', 'password', '0123456789', 'address', 'city', 'state',
       SecretQuestion.animal, 'cat');
      expect(page.getFirstnameErrorValue()).toBe('The firstname contains illegal characters');
      expect(page.getLastnameErrorValue()).toBe('The lastname contains illegal characters');
    });

    it('should alert if use special symbols for fill fields', () => {
      page.navigateTo();
      page.enterCredentials('!"@#$^%^&*()_+=?/.,}{][', '!"@#$^%^&*()_+=?/.,}{][',
       'password', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(page.getFirstnameErrorValue()).toBe('The firstname contains illegal characters');
      expect(page.getLastnameErrorValue()).toBe('The lastname contains illegal characters');
    });

    it('should alert if use spacing for fill fields', () => {
      page.navigateTo();
      page.enterCredentials('      ', '      ', 'password', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(page.getFirstnameErrorValue()).toBe('The firstname contains illegal characters');
      expect(page.getLastnameErrorValue()).toBe('The lastname contains illegal characters');
    });

    it('should alert if has empty First Name field', () => {
      page.navigateTo();
      page.enterCredentials('', 'lastname', 'password', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(page.getFirstnameErrorValue()).toBe('You must enter a firstname');
    });

    it('should alert if has empty Last Name field', () => {
      page.navigateTo();
      page.enterCredentials('firstname', '', 'password', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(page.getLastnameErrorValue()).toBe('You must enter a lastname');
    });
  });

  describe('Password field:', () => {
    it('should register if has upper and lowercases', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'PaSsWoRd', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should register if maximum length 63 symbols', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', '123456789012345678901234567890123456789012345678901234567890123',
       '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should register if use numbers', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', '1234567890', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should register if use "-"', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', '----------', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should register if use "."', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', '......', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should register if use special symbols', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', '!"@#$^%^&*()_+=?/.,}{][',
       '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should alert message if has empty field', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', '', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(page.getPasswordErrorValue()).toBe('You must enter a password');
    });

    it('should alert message if has any other language except latin letters', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'пароль', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(page.getPasswordErrorValue()).toBe('The password contains illegal characters');
    });

    it('should shows filled in password after click on eye icon', () => {
      page.navigateTo();
      page.clickOnEyeIcon();
      expect(page.getPasswordType()).toBe('text');
    });
  });

  describe('Phone number field:', () => {
    it('should alert message if has letters', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', 'Phone number', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(page.getPhonenumberErrorValue()).toBe('The phone number contains illegal characters');
    });

    it('should register if field has fill number', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should alert message if has empty field', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(page.getPhonenumberErrorValue()).toBe('You must enter a phone number');
    });
  });

  describe('Address field:', () => {
    it('should register if has letters', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should register if field has fill number', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '0123456789', '6121212', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should alert message if has empty field', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '0123456789', '', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(page.getAddressErrorValue()).toBe('You must enter a address');
    });
  });

  describe('State field:', () => {
    it('should register if has letters', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should register if field has fill number', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '0123456789', 'address', 'city', '999999', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should alert message if has empty field', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '0123456789', 'address', 'city', '', SecretQuestion.animal, 'cat');
      expect(page.getStateErrorValue()).toBe('You must enter a state');
    });
  });

  describe('City field:', () => {
    it('should register if has letters', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should register if field has fill number', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '0123456789', 'address', '999999', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });

    it('should alert message if has empty field', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '0123456789', 'address', '', 'state', SecretQuestion.animal, 'cat');
      expect(page.getCityErrorValue()).toBe('You must enter a city');
    });
  });

  describe('Secret question field:', () => {
    it('should display secret questions after click on the field', () => {
      page.navigateTo();
      page.secretSelect.click();
      expect(page.isSecretQuestionOptionVisible);
    });
  });

  describe('Answer field:', () => {
    it('should register if has letters', () => {
      page.navigateTo();
      page.enterCredentials('firstname', 'lastname', 'password', '0123456789', 'address', 'city', 'state', SecretQuestion.animal, 'cat');
      expect(browser.getCurrentUrl()).toContain('/login');
    });
  });
});
