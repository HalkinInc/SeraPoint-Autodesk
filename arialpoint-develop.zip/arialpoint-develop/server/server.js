const express = require("express");

const connectToDatabase = require("./db/connectToDatabase");

const PORT = 3000;

module.exports.db = connectToDatabase();

const deleteFlaggedAsDeletedUsersCronJob = require("./crons/deleteFlaggedAsDeletedUsers");
const deleteFlagAsDeletedDxfFilesCronJob = require("./crons/deleteFlagAsDeletedDxfFiles");
const deleteFlagAsDeletedAnotationsCronJob = require("./crons/deleteFlagAsDeletedAnotations");

deleteFlaggedAsDeletedUsersCronJob.start();
deleteFlagAsDeletedDxfFilesCronJob.start();
deleteFlagAsDeletedAnotationsCronJob.start();

const auxRouter = require("./components/aux/auxRouter");
const userRouter = require("./components/user/userRouter");
const tenantRouter = require("./components/tenant/tenantRouter");
const dxfFileRouter = require("./components/dxfFile/dxfFileRouter");
const anotationRouter = require("./components/anotation/anotationRouter");
const errorHandler = require("./middleware/errorHandler");

const app = express();

app.use(express.json());

app.use(auxRouter);
app.use(userRouter);
app.use(tenantRouter);
app.use(dxfFileRouter);
app.use(anotationRouter);

app.use(errorHandler());

module.exports.server = module.parent === null ? app.listen(PORT) : app.listen(7777);
