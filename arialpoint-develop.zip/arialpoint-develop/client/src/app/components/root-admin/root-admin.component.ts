import { Component, OnInit } from '@angular/core';
import { UsersService } from '../../services/users.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root-admin',
  templateUrl: './root-admin.component.html',
  styleUrls: ['./root-admin.component.scss']
})
export class RootAdminComponent implements OnInit {
  currentUserRole: string;
  activeLinkIndex = 0;
  navLinks = {
    'root': [
      { label: 'Users', link: './users', index: 0 },
      { label: 'Customers', link: './customers', index: 1 },
      { label: 'Login History', link: './login-history', index: 2 },
      { label: 'Files', link: './files', index: 3 }
    ],
    'admin': [
      { label: 'Users', link: './users', index: 0 },
      { label: 'Customers', link: './customers', index: 1 },
      { label: 'Login History', link: './login-history', index: 2 },
      { label: 'Files', link: './files', index: 3 }
    ],
    'moderator': [
      { label: 'Users', link: './users', index: 0 },
      { label: 'Login History', link: './login-history', index: 1 },
      { label: 'Files', link: './files', index: 2 }
    ],
    'user': [
      { label: 'Files', link: './files', index: 0 }
    ]
  };

  constructor(private usersService: UsersService, private router: Router) {}

  ngOnInit() {
    this.getUser();
    this.router.events.subscribe(() => {
      this.activeLinkIndex = this.navLinks[this.currentUserRole].indexOf(
        this.navLinks[this.currentUserRole].find(tab => tab.link === '.' + this.router.url));
    });
  }

  getUser() {
    this.usersService.getUser()
      .subscribe((res) => {
        this.currentUserRole = res.value.role;
        const arr = this.router.url.split('/');
        if (arr.length === 2) {
          const url = this.navLinks[res.value.role][0].link.slice(1);
          this.router.navigateByUrl(`dashboard${url}`);
        }
      });
  }
}
