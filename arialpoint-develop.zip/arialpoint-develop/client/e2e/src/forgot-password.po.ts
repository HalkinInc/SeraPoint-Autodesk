import { browser, by, element } from 'protractor';

export class ForgotPasswordPage {
    navigateTo = () => browser.get('/forgot-password');

    enterEmail = (email: string) => {
        element(by.name('email')).sendKeys(email);
        element(by.name('next1')).click();
    }

    enterAnswer = (answer: string) => {
        element(by.name('answer')).sendKeys(answer);
        element(by.name('next2')).click();
    }

    enterPassword = (password: string) => {
        element(by.id('new-password')).sendKeys(password);
        element(by.name('next3')).click();
    }

    clickOnReturnToLogin = () => element(by.id('return-to-login')).click();

    moveBackFromStepTwoToStepOne = () => element(by.id('back2')).click();
    moveBackFromStepThreeToStepTwo = () => element(by.id('back3')).click();
    moveBackFromStepFourToStepThree = () => element(by.id('back4')).click();

    isStepOne = () => element(by.id('cdk-step-content-0-0')).isPresent();
    isStepTwo = () => element(by.id('cdk-step-content-0-1')).isPresent();
    isStepTree = () => element(by.id('cdk-step-content-0-2')).isPresent();
    isStepFour = () => element(by.id('cdk-step-content-0-3')).isPresent();
    isLoginPage = () => browser.getCurrentUrl().then(res => res.includes('/login'));

    errorMessageSnackbar = () => element.all(by.css('.mat-simple-snackbar span')).first().getText();
}
