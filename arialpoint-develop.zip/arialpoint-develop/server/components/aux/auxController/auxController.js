module.exports = {
    seeds: require("./seeds"),
    getSettings: require("./getSettings"),
    patchSettings: require("./patchSettings")
};