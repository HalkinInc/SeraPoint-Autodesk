// resource:action:scope

const user = [
    "user:read:tenant", "user:update:own",
    "tenant:read:tenant",
    "dxf-file:read:tenant",
    "anotation:read:tenant", "anotation:create:tenant", "anotation:update:own", "anotation:delete:own"
];

const moderator = [
    "settings:read",
    "moderator:create:tenant",
    "user:read:tenant", "user:create:tenant", "user:update:own", "user:delete:tenant",
    "tenant:read:tenant", "tenant:update:tenant",
    "dxf-file:read:tenant",
    "anotation:read:tenant", "anotation:create:tenant", "anotation:update:tenant", "anotation:delete:tenant"
];

const admin = [
    "settings:read",
    "admin:read:any", "admin:create:any", "admin:update:any", "admin:delete:any",
    "moderator:read:any", "moderator:create:any", "moderator:update:any", "moderator:delete:any",
    "user:read:any", "user:create:any", "user:update:any", "user:delete:any",
    "tenant:read:any", "tenant:create:any", "tenant:update:any", "tenant:delete:any",
    "dxf-file:read:any", "dxf-file:create:any", "dxf-file:update:any", "dxf-file:delete:any",
    "anotation:read:any", "anotation:create:any", "anotation:update:any", "anotation:delete:any"
];

const root = [
    "settings:update",
    ...admin
];

module.exports = {
    root,
    admin,
    moderator,
    user
};