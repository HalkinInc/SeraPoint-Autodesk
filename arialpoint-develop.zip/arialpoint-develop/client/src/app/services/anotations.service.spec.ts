import { TestBed } from '@angular/core/testing';

import { AnotationsService } from './anotations.service';

describe('AnotationsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AnotationsService = TestBed.get(AnotationsService);
    expect(service).toBeTruthy();
  });
});
