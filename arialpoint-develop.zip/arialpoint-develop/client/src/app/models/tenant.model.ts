export class Tenant {
  constructor(
    public anotationCount?: number,
    public deleted?: boolean,
    public dxfFileCount?: number,
    public name?: string,
    public userCount?: number,
    public _id?: string,
  ) {}
}
