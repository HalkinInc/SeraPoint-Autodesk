const { server, db } = require("../../../../server");
const { tenants, users } = require("./seeds");

before(async () => await (await db).dropDatabase());

after(() => server.close());

beforeEach(async () => {
    const dbConnection = await db;

    const userCollection = await dbConnection.collection("users");
    await userCollection.deleteMany({});
    await userCollection.insertMany(users);

    const tenantCollection = await dbConnection.collection("tenants");
    await tenantCollection.deleteMany({});
    await tenantCollection.insertMany(tenants);
});

describe("AUTHENTICATION", () => require("./tenantAuthentication.test"));

describe("GET /tenant", () => require("./getTenant.test"));

describe("GET /tenant/:id", () => require("./getTenantById.test"));

describe("PATCH /tenant/:id", () => require("./patchTenantById.test"));

describe("DELETE /tenant/:id", () => require("./deleteTenantById.test"));