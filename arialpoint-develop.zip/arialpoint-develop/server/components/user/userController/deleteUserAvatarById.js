const UserService = require("../userService");
const authorization = require("../../../middleware/authorization");
const requestValidation = require("../../../middleware/requestValidation");
const appErrors = require("../../../utils/appErrors");

const deleteUserAvatarById = async (req, res, next) => {
    try {
        const { authUser, params: { id } } = req;

        const foundUser = await UserService.getUserById(id);

        if (authUser.permissions.includes("user:update:own") && authUser._id.toString() !== foundUser._id.toString()) throw new appErrors.AuthorizationError();

        await UserService.removeUserAvatar(id);

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const deleteUserAvatarByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true }
        }
    }
};

module.exports = [
    authorization(["user:update:any", "user:update:tenant", "user:update:own"]),
    requestValidation(deleteUserAvatarByIdSchema),
    deleteUserAvatarById
];