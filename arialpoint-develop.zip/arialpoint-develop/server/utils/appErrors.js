class AppError extends Error {
    constructor(message, layer, statusCode, isOperational) {
        super(message);
        this.layer = layer;
        this.statusCode = statusCode;
        this.isOperational = isOperational;
    }
}

class AuthenticationError extends AppError {
    constructor(message) {
        super(message, "authentication", 401, true);
    }
}

class AuthorizationError extends AppError {
    constructor() {
        super("Permission denied", "authorization", 403, true);
    }
}

class RequestError extends AppError {
    constructor(message) {
        super(message, "validation", 400, true);
    }
}

class NotFoundError extends AppError {
    constructor(message) {
        super(message, "service", 404, true);
    }
}

class ServerError extends AppError {
    constructor(message) {
        super(message, "service", 500, false);
    }
}

class DataAccessError extends AppError {
    constructor(message) {
        super(message, "data-access", 500, false);
    }
}

module.exports = {
    AppError,
    AuthenticationError,
    AuthorizationError,
    RequestError,
    NotFoundError,
    ServerError,
    DataAccessError
};