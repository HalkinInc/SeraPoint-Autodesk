import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog } from '@angular/material';
import { Tenant } from '../../models/tenant.model';
import { FileUploadDialogComponent } from '../files-page/file-upload-dialog/file-upload-dialog.component';
import { ConfirmActionComponent } from './confirm-action/confirm-action.component';
import { Router } from '@angular/router';
import { TenantsService } from '../../services/tenants.service';
import { DXFFilesService } from '../../services/dxffiles.service';

@Component({
  selector: 'app-tenant-groups',
  templateUrl: './tenant-groups.component.html',
  styleUrls: ['./tenant-groups.component.scss']
})
export class TenantGroupsComponent implements OnInit {
  displayedColumns: string[] = ['delete', 'name', 'usersCount', 'dxfFilesCount', 'anotationFilesCount'];
  dataSource: MatTableDataSource<Tenant>;
  tenantGroups: Array<Tenant> = new Array();
  showSpinner = false;
  private paginator: MatPaginator;
  private sort: MatSort;

  @ViewChild(MatSort) set matSort(ms: MatSort) {
    this.sort = ms;
    this.setDataSourceAttributes();
  }

  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.setDataSourceAttributes();
  }

  constructor(
    private tenantsService: TenantsService,
    private dxfFilesService: DXFFilesService,
    public dialog: MatDialog, private router: Router) {
    this.dataSource = new MatTableDataSource(this.tenantGroups);
  }

  setDataSourceAttributes() {
    if (this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
  }

  ngOnInit() {
    this.getTenants();
  }

  onEditTenantAdmin(tenantGroup: Tenant) {
    console.log('Test', tenantGroup);
  }

  getTenants() {
    this.tenantsService.getTenants()
      .subscribe((res) => {
        this.tenantGroups = res.value;
        this.dataSource = new MatTableDataSource(this.tenantGroups);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.showSpinner = false;
      });
  }

  openUploadDXFFileDialog(id) {
    const uploadDXFFileDialogRef = this.dialog.open(FileUploadDialogComponent, {
      width: '685px'
    });

    uploadDXFFileDialogRef.afterClosed().subscribe(result => {
      if (typeof result !== 'undefined') {
        this.showSpinner = true;
        this.dxfFilesService.uploadDXFFile(id, result).subscribe((res) => {
          if (res.errors.length === 0) {
            this.getTenants();
          } else {
            this.showSpinner = false;
          }
        });
      }
    });
  }

  onDeleteTenant(tenantId) {
    const answer = false;
    const deleteDialogRef = this.dialog.open(ConfirmActionComponent, { data: answer });

    deleteDialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.tenantsService.deleteTenant(tenantId).subscribe((res) => {
          this.getTenants();
        });
      }
    });
  }

  routeToTennant(tenantId) {
    this.router.navigateByUrl(`customer/${tenantId}`);
  }
}
