const { ObjectId } = require("mongodb");

const appErrors = require("../../../utils/appErrors");
const requestValidation = require("../../../middleware/requestValidation");
const { db } = require("../../../server");
const UserModel = require("../../user/userModel");
const TenantModel = require("../../tenant/tenantModel");
const DxfFileModel = require("../../dxfFile/dxfFileModel");
const AnotationModel = require("../../anotation/anotationModel");

const seeds = async (req, res, next) => {
    try {
        let { body: { users, tenants, dxfFiles, anotations } } = req;

        if (process.env.NODE_ENV !== "test") throw new appErrors.RequestError("This route is only available in test environment");

        users = users.map((u) => ({ ...u, _id: ObjectId(u._id) }));
        tenants = tenants.map((t) => ({ ...t, _id: ObjectId(t._id) }));
        dxfFiles = dxfFiles.map((d) => ({ ...d, _id: ObjectId(d._id) }));
        anotations = anotations.map((a) => ({ ...a, _id: ObjectId(a._id) }));

        const dataBase = await db;
        await dataBase.dropDatabase();

        if (users !== undefined) { await UserModel.insertMany(users); }
        if (tenants !== undefined) await TenantModel.insertMany(tenants);
        if (dxfFiles !== undefined) await DxfFileModel.insertMany(dxfFiles);
        if (anotations !== undefined) await AnotationModel.insertMany(anotations);

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const seedsSchema = {
    body: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            users: { type: "array", items: { type: "object" } },
            tenants: { type: "array", items: { type: "object" } },
            dxfFiles: { type: "array", items: { type: "object" } },
            anotations: { type: "array", items: { type: "object" } },
        }
    }
};

module.exports = [
    requestValidation(seedsSchema),
    seeds
];