import { Injectable } from '@angular/core';
import { UsersService } from './users.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private usersService: UsersService) { }

  authenticate(username: string, password: string): Observable<boolean> {
    return this.usersService.authenticate(username, password);
  }

  get authenticated(): boolean {
    return this.usersService.auth_token != null;
  }

  clear() {
    localStorage.removeItem('currentUser');
    this.usersService.auth_token = null;
  }
}
