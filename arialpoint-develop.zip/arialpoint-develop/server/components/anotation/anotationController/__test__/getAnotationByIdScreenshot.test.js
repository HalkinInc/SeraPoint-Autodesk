const assert = require("assert");

const request = require("supertest");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { users, anotations } = require("./seed");

it("error if anotation id is invalid", async () => {
    const anotationId = "123";
    const token = users[0].jwt;

    const response = await request(server).get(`/anotation/${anotationId}/screenshot`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'params/id' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if anotation with provided id doesn't exist", async () => {
    const anotationId = ObjectId().toString();
    const token = users[0].jwt;

    const response = await request(server).get(`/anotation/${anotationId}/screenshot`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Anotation not found");

    assert.strictEqual(value, undefined);
});

it("error if anotation is deleted", async () => {
    const anotationId = anotations[3]._id.toString();
    const token = users[0].jwt;

    const response = await request(server).get(`/anotation/${anotationId}/screenshot`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Anotation was deleted");

    assert.strictEqual(value, undefined);
});

it("anotation:read:tenant can't get anotaion screenshot of not his tenant", async () => {
    const anotationId = anotations[4]._id.toString();
    const token = users[1].jwt;

    const response = await request(server).get(`/anotation/${anotationId}/screenshot`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("anotation:read:tenant can get anotation screenshot of his tenant", async () => {
    const anotationId = anotations[1]._id.toString();
    const token = users[1].jwt;

    const response = await request(server).get(`/anotation/${anotationId}/screenshot`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, "screenshot");
});

it("anotation:read:any can get any anotation screenshot", async () => {
    const anotationId = anotations[1]._id.toString();
    const token = users[0].jwt;

    const response = await request(server).get(`/anotation/${anotationId}/screenshot`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, "screenshot");
});