const { ObjectId } = require("mongodb");

const TenantModel = require("./tenantModel");
const validate = require("../../utils/validate");
const appErrors = require("../../utils/appErrors");

const createSchema = {
    type: "object",
    required: ["name", "deleted"],
    additionalProperties: false,
    properties: {
        // required
        name: { type: "string", minLength: 2, maxLength: 20 },
        deleted: { type: "boolean", default: false }
    }
};

const createTenant = async (name) => {
    const foundTenant = await TenantModel.findAndEnrichOne({ name });
    if (foundTenant !== null) throw new appErrors.AppError("Tenant already exists", "service", 409, true);

    const newTenant = { name };
    const validationError = validate(createSchema, newTenant);
    if (validationError !== null) throw new appErrors.RequestError(validationError);

    await TenantModel.insertOne(newTenant);
};

const getTenantById = async (id) => {
    const foundTenant = await TenantModel.findAndEnrichOne({ _id: ObjectId(id) });
    if (foundTenant === null) throw new appErrors.NotFoundError("Tenant not found");
    if (foundTenant.deleted) throw new appErrors.NotFoundError("Tenant was deleted");

    return foundTenant;
};

const getTenantByName = async (name) => {
    const foundTenant = await TenantModel.findAndEnrichOne({ name });
    if (foundTenant === null) throw new appErrors.NotFoundError("Tenant not found");
    if (foundTenant.deleted) throw new appErrors.NotFoundError("Tenant was deleted");

    return foundTenant;
};

const checkIfTenantExists = async (name) => {
    const foundTenant = await TenantModel.findOne({ name });
    return foundTenant !== null;
};

const getAllTenants = async (deleted = false, limit = 0, skip = 0) => {
    const query = { deleted };
    const result = await TenantModel.findAndEnrichMany(query, limit, skip);
    return result;
};

const renameTenant = async (id, name) => {
    await getTenantById(id);
    await TenantModel.updateOne({ _id: ObjectId(id) }, { $set: { name } });
};

const flagTenantAsDeleted = async (id) => {
    await getTenantById(id);
    await TenantModel.updateOne({ _id: ObjectId(id) }, { $set: { deleted: true } });
};


const getDeletedTenantById = async (id) => {
    const foundTenant = await TenantModel.findAndEnrichOne({ _id: ObjectId(id) });
    if (foundTenant === null) throw new appErrors.NotFoundError("Tenant not found");
    return foundTenant;
};

const hardDeleteTenantById = async (id) => {
    await getDeletedTenantById(id);
    await TenantModel.deleteOne({_id: ObjectId(id)});
};

const unflagTenantAsDeleted = async (id) => {
    await getDeletedTenantById(id);
    await TenantModel.updateOne({ _id: ObjectId(id) }, { $set: { deleted: false }, $unset: { deteledAt: "" } });
};

module.exports = {
    createTenant,
    getTenantById,
    getTenantByName,
    checkIfTenantExists,
    getAllTenants,
    renameTenant,
    flagTenantAsDeleted,
    hardDeleteTenantById,
    getDeletedTenantById,
    unflagTenantAsDeleted
};