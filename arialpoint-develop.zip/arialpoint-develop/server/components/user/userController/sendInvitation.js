const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const sendInvitation = async (req, res, next) => {
    try {
        const { authUser, params: { id: resendUserId }, body: { message = "" } } = req;

        const foundUser = await UserService.getUserById(resendUserId);

        if (authUser.permissions.includes("user:create:tenant") && authUser.tenantId !== foundUser.tenantId) throw new appErrors.AuthorizationError();

        await UserService.sendInvitation(foundUser.finishRegistrationCode, message, authUser);

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const sendInvitationSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            // required
            id: { type: "string", objectId: true },
        }
    },
    body: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            // not required
            message: { type: "string" }
        }
    }
};

module.exports = [
    authorization(["moderator:create:any", "user:create:any", "user:create:tenant"]),
    requestValidation(sendInvitationSchema),
    sendInvitation
];