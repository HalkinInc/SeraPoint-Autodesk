const request = require("supertest");
const expect = require("expect");
const { ObjectId } = require("mongodb");
const jsonwebtoken = require("jsonwebtoken");
const config = require("config");

const { server } = require("../../../../server");
const { users, tenants } = require("./seeds");

it("error if token is not provided", async () => {
    const response = await request(server).get("/user");
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Token is not provided");

    expect(value).not.toBeDefined();
});

it("error if provided token is invalid", async () => {
    const token = jsonwebtoken.sign("blabla", config.app.secret);

    const response = await request(server).get("/user").set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Supplied token is invalid");

    expect(value).not.toBeDefined();
});

it("error if provided token is valid but user with such token not exists", async () => {
    const token = jsonwebtoken.sign({ email: "noSuchUser@email.com" }, config.app.secret);

    const response = await request(server).get("/user").set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Supplied token is invalid");

    expect(value).not.toBeDefined();
});

it("error if tenant id is invalid", async () => {
    const token = users[0].jwt;

    const response = await request(server).get("/user?tenantId=123").set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'query/tenantId' should be valid 'objectId'");

    expect(value).not.toBeDefined();
});

it("error if tenant id is valid but tenant doesn't exist", async () => {
    const token = users[0].jwt;
    const tenantId = ObjectId().toString();
    const url = `/user?tenantId=${tenantId}`;

    const response = await request(server).get(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Tenant not found");

    expect(value).not.toBeDefined();
});

it("user:read:any can get all users", async () => {
    const token = users[0].jwt;

    const response = await request(server).get("/user").set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value.length).toBe(users.length - 1);
});

it("user:read:any can get all users of tenant", async () => {
    const token = users[0].jwt;
    const tenantId = tenants[0]._id.toString();

    const response = await request(server).get(`/user?tenantId=${tenantId}`).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value.length).toBe(5);
});

it("user:read:tenant can get all users of his tenant", async () => {
    const token = users[1].jwt;
    const tenantId = tenants[0]._id.toString();

    const response = await request(server).get(`/user?tenantId=${tenantId}`).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value.length).toBe(5);
    expect(value[0].email).toBe(users[1].email);
});

it("user:read:tenant can't get all users of not his tenant", async () => {
    const token = users[1].jwt;
    const tenantId = tenants[1]._id.toString();

    const response = await request(server).get(`/user?tenantId=${tenantId}`).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);

    expect(value).not.toBeDefined();
});
