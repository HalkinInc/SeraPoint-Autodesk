const assert = require("assert");

const request = require("supertest");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { tenants, users } = require("./seeds");


it("error if provided tenant id is invalid", async () => {
    const token = users[0].jwt;
    const tenantId = "1234567890";

    const response = await request(server).delete(`/tenant/${tenantId}`).set("Authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'params/id' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if tenant with provided id doesn't exist", async () => {
    const token = users[0].jwt;
    const tenantId = ObjectId().toString();

    const response = await request(server).delete(`/tenant/${tenantId}`).set("Authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Tenant not found");

    assert.strictEqual(value, undefined);
});

it("user without permission can't delete tenant", async () => {
    const token = users[3].jwt;
    const tenantId = tenants[0]._id.toString();

    const response = await request(server).delete(`/tenant/${tenantId}`).set("Authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("tenant:delete:any can delete tenant", async () => {
    const token = users[0].jwt;
    const tenantId = tenants[0]._id.toString();

    const response = await request(server).delete(`/tenant/${tenantId}`).set("Authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});