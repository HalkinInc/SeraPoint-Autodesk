export class DXFFile {
  constructor(
    public createdAt?: number,
    public creatorFirstname?: string,
    public creatorId?: string,
    public creatorLastname?: string,
    public deleted?: boolean,
    public fileKey?: string,
    public fileName?: string,
    public fileSize?: number,
    public select?: boolean,
    public tenantId?: string,
    public tenantName?: string,
    public urn?: string,
    public _id?: string
  ) {}
}
