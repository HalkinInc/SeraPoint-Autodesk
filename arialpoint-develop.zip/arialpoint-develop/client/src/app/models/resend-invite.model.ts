export class ResendInviteDialogData {
  constructor(
    public firstname?: string,
    public lastname?: string,
    public message?: string
  ) {}
}
