import { Component, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UsersService } from '../../services/users.service';
import { TenantsService } from '../../services/tenants.service';
import { DXFFilesService } from '../../services/dxffiles.service';
import { AnotationsService } from '../../services/anotations.service';
import { MatDialog } from '@angular/material';
import { InviteDialogComponent } from '../invite/invite-dialog/invite-dialog.component';
import { FileUploadDialogComponent } from '../files-page/file-upload-dialog/file-upload-dialog.component';
import { Router } from '@angular/router';
import { User } from '../../models/user.model';
import { UserTableComponent } from '../user-table/user-table.component';
import { UpdateAnnotationComponent } from '../files-page/annotation-files/update-annotation/update-annotation.component';
import { UpdateDxfDialogComponent } from '../files-page/update-dxf-dialog/update-dxf-dialog.component';

@Component({
  selector: 'app-tenant-page',
  templateUrl: './tenant-page.component.html',
  styleUrls: ['./tenant-page.component.scss']
})
export class TenantPageComponent {
  tenantId: string;
  tenantName: string;
  displayedColumns: Array<string> = ['edit', 'firstname', 'lastname', 'tenantId', 'email', 'role'];
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  message: string;
  user: User;
  sortBy = 'newest';
  dxfFiles: DXFFiles[] = [];
  annotationFiles: Array<any> = new Array();
  filesList: Array<any> = new Array();
  selectedImage: File;

  @ViewChild(UserTableComponent) tableRef: UserTableComponent;

  constructor(
    public dialog: MatDialog,
    private route: ActivatedRoute,
    private tenantsService: TenantsService,
    private usersService: UsersService,
    private dxfFilesService: DXFFilesService,
    private anotationsService: AnotationsService,
    private router: Router) {
      this.tenantId = route.params['value'].id;
      this.getCurrentUser();
      this.getTennant(this.tenantId);
      this.getFiles(this.tenantId);
  }

  getTennant(tennantId: string) {
    this.tenantsService.getTenant(tennantId).subscribe((res) => {
      if (res.value) {
        this.tenantName = res.value.name;
      }
    });
  }

  getCurrentUser() {
    this.usersService.getUser()
      .subscribe(res => {
        this.user = res.value;
        this.getUsers(this.tenantId);
        if (this.user.role === 'moderator') {
          this.displayedColumns = ['edit', 'firstname', 'lastname', 'email'];
        }
      });
  }

  openDialog(): void {
    const datas = {
      email: this.email,
      firstName: this.firstName,
      lastName: this.lastName,
      message: this.message,
      role: this.role,
      tenant: this.tenantName,
      user: this.user,
      tenantAdmin: this.user.role === 'moderator'
    };
    const dialogRef = this.dialog.open(InviteDialogComponent, {
      width: '685px',
      data: datas
    });

    dialogRef.afterClosed().subscribe(result => {
      this.usersService.inviteUser({
        email: result.email,
        firstname: result.firstName,
        lastname: result.lastName,
        message: result.message,
        tenantName: result.tenant,
        role: result.role
      })
        .subscribe(res => {
          this.getUsers(this.tenantId);
        });
    });
  }

  getFiles(id: string) {
    this.dxfFilesService.getDXFFiles(id).subscribe((res) => {
      this.anotationsService.getAnnotationFiles(id).subscribe((result) => {
        this.filesList = res.value.concat(result.value).sort((a, b) => {
          return <number>b.createdAt - <number>a.createdAt;
        });
      });
    });
  }

  openUploadDXFFileDialog(tenantId: string) {
    const uploadDXFFileDialogRef = this.dialog.open(FileUploadDialogComponent, {
      width: '685px'
    });

    uploadDXFFileDialogRef.afterClosed().subscribe(result => {
      if (typeof result !== 'undefined') {
        this.dxfFilesService.uploadDXFFile(tenantId, result).subscribe((res) => {
          this.getFiles(this.tenantId);
        });
      }
    });
  }

  get changeSortFilter() {
    switch (this.sortBy) {
      case 'newest':
        return this.filesList.sort((a, b) => {
          return <number>b.createdAt - <number>a.createdAt;
        });
      case 'oldest':
        return this.filesList.sort((a, b) => {
          return <number>a.createdAt - <number>b.createdAt;
        });
      case 'name':
        return this.filesList.sort((a, b) => {
          const nameA = a.name.toLowerCase();
          const nameB = b.name.toLowerCase();
          if (nameA < nameB) {
            return -1;
          } else if (nameA > nameB) {
            return 1;
          } else {
            return 0;
          }
        });
      case 'size':
        return this.filesList.sort((a, b) => {
          return <number>b.fileSize - <number>a.fileSize;
        });
    }
  }

  onDownload(item) {
    const file = item.fileName;
    let responseType = '';
    const type = /[.]/.exec(file) ? /[^.]+$/.exec(file) : undefined;
    switch (type[0]) {
      case 'doc':
      case 'docx':
        responseType = 'application/msword';
        break;
      case 'pdf':
        responseType = 'application/pdf';
        break;
      case 'csv':
        responseType = 'text/csv';
        break;
      case 'jpg':
      case 'jpeg':
        responseType = 'image/jpeg';
        break;
      case 'png':
        responseType = 'image/png';
        break;
      case 'gif':
        responseType = 'image/gif';
        break;
      case 'bmp':
        responseType = 'image/vnd.wap.wbmp';
        break;
      case 'tiff':
        responseType = 'image/tiff';
        break;
    }
    this.anotationsService.downloadAnotation(item._id).subscribe((res) => {
      if (res.value) {
        const datas = new Uint8Array(res.value.Body.data);
        const blob = new Blob([datas], { type: responseType });
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob, item.fileName);
        } else {
          const urlCreator = window.URL;
          const fileUrl = urlCreator.createObjectURL(blob);
          window.open(fileUrl);
        }
        item.downloadIcon = false;
      }
    });
  }

  checkFileType(item: any) {
    return item.hasOwnProperty('urn') ? 'dxf-file' : 'annotation';
  }

  previewDXF(id, annotationId: string = 'pure-dxf') {
    this.router.navigateByUrl(`/view-page/${id}/${annotationId}`);
  }

  deleteFile(item) {
    const type = this.checkFileType(item);
    switch (type) {
      case 'annotation':
        this.deleteAnnotation(item._id);
        break;
      case 'dxf-file':
        this.deleteDXF(item._id);
        break;
    }
  }

  deleteDXF(id) {
    this.dxfFilesService.deleteDXFFile(id).subscribe((res) => {
      this.getFiles(this.tenantId);
    });
  }

  deleteAnnotation(id) {
    this.anotationsService.deleteAnnotation(id).subscribe(() => {
      this.getFiles(this.tenantId);
    });
  }

  onUpdateAnnotation(annotation) {
    const dialogRef = this.dialog.open(UpdateAnnotationComponent, {
      width: '685px',
      data: annotation
    });

    dialogRef.afterClosed().subscribe((result) => {
      const updatedAnnotation = annotation;
      updatedAnnotation.name = result.name;
      updatedAnnotation.text = result.text;
      this.anotationsService.updateAnnotation(updatedAnnotation, result.file, this.selectedImage).subscribe((res) => {
        this.getFiles(this.tenantId);
      });
    });
  }

  onUpdateDxf(dxf) {
    const updateDialogRef = this.dialog.open(UpdateDxfDialogComponent, {
      width: '500px',
      data: dxf
    });

    updateDialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.dxfFilesService.updateDXFFile(result._id, result.fileName).subscribe((res) => {
          this.getFiles(this.tenantId);
        });
      }
    });
  }

  getUsers(user, search?: string) {
    this.tableRef.getUsers(this.tenantId, search);
  }

  trackByFn(index, item) {
    return item.id;
  }
}
export class DXFFiles {
  constructor(public name: string, public createdAt: number, public id: string) { }
}
