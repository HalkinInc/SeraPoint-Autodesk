import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DXFFilesService {

  constructor(private http: HttpClient) { }

  uploadDXFFile(id, files: FormData) {
    const formData = new FormData();
    formData.append('file', files[0], files[0].filename);
    formData.append('tenantId', id);
    return this.http.post('/api/dxf-file', formData)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  getDXFFiles(tenantId) {
    let url = '/api/dxf-file';
    url += tenantId ? `?tenantId=${tenantId}` : '';
    return this.http.get(url)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  deleteDXFFile(id) {
    return this.http.delete(`/api/dxf-file/${id}`)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  getDXFFileById(id) {
    return this.http.get(`/api/dxf-file/${id}`)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  updateDXFFile(id, fileName) {
    return this.http.patch(`/api/dxf-file/${id}`, { fileName })
      .pipe(tap((res: any) => {
        return res;
      }));
  }

  getDeleteDXFFiles(tenantId) {
    let url = '/api/dxf-file?deleted=true';
    if (tenantId) {
      url = `/api/dxf-file?tenantId=${tenantId}&deleted=true`;
    }
    return this.http.get(url)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  editDXF(id, data) {
    return this.http.patch(`/api/dxf-file/${id}`, data)
      .pipe(tap((res: any) => {
        return res;
      }));
  }
}
