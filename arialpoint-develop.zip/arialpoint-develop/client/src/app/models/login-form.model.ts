import { FormControl, FormGroup, Validators } from '@angular/forms';

export class LoginFormControl extends FormControl {
  label: string;
  modelProperty: string;

  constructor(label: string, property: string, value: any, validator: any) {
    super(value, validator);
    this.label = label;
    this.modelProperty = property;
  }

  getValidationMessages() {
    const messages: string[] = [];
    if (this.errors) {
      for (const errorName in this.errors) {
        if (errorName === 'required') {
          messages.push(`Please enter your ${this.modelProperty}`);
        } else if (errorName === 'minlength') {
          messages.push(`A ${this.modelProperty} must be at least ${this.errors['minlength'].requiredLength} characters`);
        } else if (errorName === 'maxlength') {
          messages.push(`A ${this.modelProperty} must be no more than ${this.errors['maxlength'].requiredLength} characters`);
        } else if (errorName === 'pattern') {
          messages.push(`The ${this.modelProperty} contains illegal characters`);
        }
      }
    }
    return messages;
  }
}

export class LoginFormGroup extends FormGroup {
  constructor() {
    super({
      email: new LoginFormControl('Enter your email', 'email', '',
        Validators.compose([Validators.required, Validators.email, Validators.pattern('[0-Za-z\-._@]*')])),
      password: new LoginFormControl('Enter your password', 'password', '',
        Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(10)])
      )
    });
  }

  get loginControls(): LoginFormControl[] {
    return Object.keys(this.controls)
      .map(k => this.controls[k] as LoginFormControl);
  }

  getFormValidationMessages(form: any): string[] {
    const messages: string[] = [];
    this.loginControls.forEach(c => c.getValidationMessages()
        .forEach(m => messages.push(m)));
    return messages;
  }
}
