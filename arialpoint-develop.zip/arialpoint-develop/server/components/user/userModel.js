const { ObjectId } = require("mongodb");

const createModel = require("../../db/createModel");
const appErrors = require("../../utils/appErrors");

const UserModel = createModel("users");
const LocalTenantModel = createModel("tenants");

const USERS_WITHOUT_TENANT = ["root", "admin"];

UserModel.enrichUser = async (user) => {
    if (user === null) return user;
    const userTenant = await LocalTenantModel.findOne({ _id: ObjectId(user.tenantId) });

    if (userTenant === null) {
        if (!USERS_WITHOUT_TENANT.includes(user.role)) return { ...user, tenantName: "Error: Tenant not found" };

        return { ...user };
    }

    return { ...user, tenantName: userTenant.name };
};

UserModel.enrichUsers = async function (users) {
    const enrichedUsers = await Promise.all(users.map(async (user) => await this.enrichUser(user)));
    return enrichedUsers.filter(user => user !== null);
};

UserModel.findAndEnrichOne = async function (query) {
    const foundOne = await this.findOne(query);
    return await this.enrichUser(foundOne);
};

UserModel.findAndEnrichMany = async function (query, limit = 0, skip = 0, projection) {
    const foundMany = await this.findMany(query, limit, skip, projection);
    return await this.enrichUsers(foundMany);
};

module.exports = UserModel;
