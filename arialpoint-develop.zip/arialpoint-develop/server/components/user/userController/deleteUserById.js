const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const deleteUserById = async (req, res, next) => {
    try {
        const { authUser, params: { id }, query: { method, newModeratorId } } = req;

        const delUser = method === "hard" ? await UserService.getDeletedUserById(id) : await UserService.getUserById(id);

        if (delUser.role === "root") throw new appErrors.AuthorizationError();
        if (authUser.permissions.includes("user:delete:tenant") && authUser.tenantId !== delUser.tenantId) throw new appErrors.AuthorizationError();
        if (!authUser.permissions.includes("moderator:delete:any") && delUser.role === "moderator") throw new appErrors.AuthorizationError();

        if (delUser.role === "moderator") {
            if (newModeratorId === undefined) throw new appErrors.RequestError("New moderator id is not provided");

            await UserService.reasignModeratorRole(id, newModeratorId);
        }

        method === "hard" ? await UserService.deleteUserById(id) : await UserService.flagUserAsDeleted(id);

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const deleteUserByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true }
        }
    },
    query: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            method: { type: "string" },
            newModeratorId: { type: "string", objectId: true }

        }
    }
};

module.exports = [
    authorization(["moderator:delete:any", "user:delete:any", "user:delete:tenant"]),
    requestValidation(deleteUserByIdSchema),
    deleteUserById
];