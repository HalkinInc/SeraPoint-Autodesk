import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from 'src/app/components/login/login.component';
import { RootAdminComponent } from 'src/app/components/root-admin/root-admin.component';
import { UserRegistrationComponent } from 'src/app/components/user-registration/user-registration.component';
import { EditProfileComponent } from 'src/app/components/edit-profile/edit-profile.component';
import { DeleteUserComponent } from 'src/app/components/delete/users/delete-user.component';
import { DeleteDxffilesComponent } from 'src/app/components/delete/dxffiles/delete-dxffiles.component';
import { FilesPageComponent } from 'src/app/components/files-page/files-page.component';
import { ViewPageComponent } from 'src/app/components/view-page/view-page.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { LoginGuard } from './login.guard';
import { TenantPageComponent } from 'src/app/components/tenant-page/tenant-page.component';
import { InviteComponent } from 'src/app/components/invite/invite.component';
import { TenantGroupsComponent } from 'src/app/components/tenant-groups/tenant-groups.component';
import { LoginHistoryComponent } from 'src/app/components/login-history/login-history.component';
import { DxfFilesComponent } from 'src/app/components/files-page/dxf-files/dxf-files.component';
import { AnnotationFilesComponent } from 'src/app/components/files-page/annotation-files/annotation-files.component';
import { AnnotationsComponent } from 'src/app/components/delete/annotations/annotations.component';
import { DeleteTenantComponent } from 'src/app/components/delete/tenants/delete-tenant.component';
const routes: Routes = [
  {
    path: '',
    redirectTo: '/dashboard',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'dashboard',
    component: RootAdminComponent,
    canActivate: [LoginGuard],
    children: [
      {
        path: 'users',
        component: InviteComponent,
        data: {
          breadcrumb: 'Users'
        }
      },
      {
        path: 'customers',
        component: TenantGroupsComponent,
        data: {
          breadcrumb: 'Customers'
        }
      },
      {
        path: 'login-history',
        component: LoginHistoryComponent,
        data: {
          breadcrumb: 'Login History'
        }
      },
      {
        path: 'files',
        component: FilesPageComponent,
        data: {
          breadcrumb: 'Files'
        },
        children: [
          {
            path: '',
            pathMatch: 'full',
            redirectTo: 'properties'
          },
          {
            path: 'properties',
            component: DxfFilesComponent,
            data: {
              breadcrumb: 'Properties'
            }
          },
          {
            path: 'annotation-files',
            component: AnnotationFilesComponent,
            data: {
              breadcrumb: 'Annotation Files'
            }
          }
        ]
      },
    ]
  },
  {
    path: 'user-registration',
    component: UserRegistrationComponent
  },
  {
    path: 'edit-profile',
    component: EditProfileComponent,
    canActivate: [LoginGuard],
    data: {
      breadcrumb: 'Edit Profile'
    }
  },
  {
    path: 'delete',
    canActivate: [LoginGuard],
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'users'
      },
      {
        path: 'users',
        component: DeleteUserComponent,
        data: {
          breadcrumb: 'Deleted Users'
        }
      },
      {
        path: 'dxffiles',
        component: DeleteDxffilesComponent,
        data: {
          breadcrumb: 'Deleted DXFFiles'
        }
      },
      {
        path: 'annotations',
        component: AnnotationsComponent,
        data: {
          breadcrumb: 'Deleted Annotations'
        }
      },
      {
        path: 'customers',
        component: DeleteTenantComponent,
        data: {
          breadcrumb: 'Deleted Customers'
        }
      }
    ]
  },
  {
    path: 'view-page/:id/:annotationId',
    component: ViewPageComponent,
    canActivate: [LoginGuard],
    data: {
      breadcrumb: 'View Page'
    }
  },
  {
    path: 'forgot-password',
    component: ForgotPasswordComponent
  },
  {
    path: 'reset-password',
    component: ResetPasswordComponent
  },
  {
    path: 'customer/:id',
    component: TenantPageComponent,
    canActivate: [LoginGuard],
    data: {
      breadcrumb: 'Customer'
    },
  }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
