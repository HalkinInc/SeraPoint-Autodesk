const CronJob = require("cron").CronJob;

const logger = require("../utils/logger");
const AnotationService = require("../components/anotation/anotationService");
const AnotationModel = require("../components/anotation/anotationModel");
const SettingsModel = require("../components/aux/settingsModel");

const UNIX_DAY_MIL = 86400000;

module.exports = new CronJob("0 3 * * *", async () => {
    try {
        const { deletedAnnotationsDaysLimit: DAYS_AGO } = await SettingsModel.findOne({ name: "main" });
        const limit = Date.now() - UNIX_DAY_MIL * DAYS_AGO;
        const anotationsToDelete = await AnotationModel.findMany({ deletedAt: { $lte: limit } });
        await Promise.all(anotationsToDelete.map(async (anotation) => {
            await Promise.all([
                AnotationService.deleteAnotationScreenshot(anotation.screenshot),
                anotation.fileKey !== undefined ? AnotationService.deleteAnotationFile(anotation.fileKey) : null,
                AnotationModel.deleteOne({ _id: anotation._id })
            ]);
        }));
        logger.info(`Annotations flagged as deleted ${DAYS_AGO} days ago removed from database and S3`);
    } catch (error) { logger.error(error, "Error while deleting annotations flagged as deleted from database, S3"); }
});