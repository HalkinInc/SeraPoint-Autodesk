import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class TenantsService {

  constructor(private http: HttpClient) { }

  getTenant(id: string) {
    return this.http.get(`/api/tenant/${id}`)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  getTenants() {
    return this.http.get('/api/tenant')
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  editTenant(id: number, data: any) {
    return this.http.patch(`/api/tenant/${id}`, data)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  deleteTenant(id: number) {
    return this.http.delete(`/api/tenant/${id}`)
      .pipe(
        tap((res: any) => {
          return res;
        })
      );
  }

  getDeletedTenants() {
    return this.http.get('/api/tenant?deleted=true')
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  deleteTenantForever(id) {
    return this.http.delete(`/api/tenant/${id}?method=hard`)
      .pipe(tap((res: any) => {
        return res;
      }));
  }
}
