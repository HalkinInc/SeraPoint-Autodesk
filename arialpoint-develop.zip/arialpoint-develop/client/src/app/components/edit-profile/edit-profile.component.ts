import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common';
import { UsersService } from '../../services/users.service';
import { User } from '../../models/user.model';
import { DomSanitizer } from '@angular/platform-browser';
import { NgForm } from '@angular/forms';
import secretQuestions from '../../consts/secretQuestions';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss']
})
export class EditProfileComponent implements OnInit {
  user: User;
  editProfileFormGroup: FormGroup;
  options: Array<string> = secretQuestions;
  secretQuestionId: number;
  selectedImage: File;

  constructor(
    private _formBuilder: FormBuilder,
    private location: Location,
    private usersService: UsersService,
    private sanitizer: DomSanitizer,
    private router: Router
  ) { }

  ngOnInit() {
    this.editProfileFormGroup = this._formBuilder.group({
      emailCtrl: ['', Validators.required],
      firstNameCtrl: ['', Validators.required],
      surnameCtrl: ['', Validators.required],
      tenantCtrl: ['', Validators.required],
      secretQuestionIdCtrl: [''],
      answerCtrl: [''],
      roleCtrl: ['', Validators.required],
      addressCtrl: [''],
      phoneCtrl: [''],
      cityCtrl: [''],
    });
    this.getUser();
  }

  back() {
    this.location.back();
  }

  getUser() {
    this.usersService.getUser()
      .subscribe((res) => {
        this.user = res.value;
        this.editProfileFormGroup.controls['emailCtrl'].setValue(this.user.email || '');
        this.editProfileFormGroup.controls['firstNameCtrl'].setValue(this.user.firstname || '');
        this.editProfileFormGroup.controls['surnameCtrl'].setValue(this.user.lastname || '');
        this.editProfileFormGroup.controls['addressCtrl'].setValue(this.user.address || '');
        this.editProfileFormGroup.controls['phoneCtrl'].setValue(this.user.phoneNumber || '');
        this.editProfileFormGroup.controls['roleCtrl'].setValue(this.getRole());
        if (this.user.role !== 'root' && this.user.role !== 'admin') {
          this.editProfileFormGroup.controls['tenantCtrl'].setValue(this.user.tenantName || '');
          this.editProfileFormGroup.controls['secretQuestionIdCtrl'].setValue(this.user.secretQuestionId);
          this.editProfileFormGroup.controls['answerCtrl'].setValue(this.user.secretQuestionAnswer || '');
        }
        this.editProfileFormGroup.controls['roleCtrl'].disable();
        this.editProfileFormGroup.controls['tenantCtrl'].disable();
        this.editProfileFormGroup.controls['cityCtrl'].setValue(this.user.city || '');
        if (this.user.avatar && this.user.avatar !== 'assets/image/no-photo.png') {
          let responseType = '';
          const type = res.value.avatar.match(/(png|jpeg|jpg)/gm, (m, g1) => {
            return `${g1}`;
          });
          switch (type) {
            case 'png':
              responseType = 'image/png';
              break;
            case 'jpeg':
              responseType = 'image/jpeg';
              break;
          }
          this.usersService.getAvatar(this.user._id).subscribe((result) => {
            const datas = new Uint8Array(result.value.Body.data);
            const blob = new Blob([datas], { type: responseType });
            const urlCreator = window.URL;
            this.user.avatar = (res.value.avatar) ? this.sanitizer.bypassSecurityTrustUrl(urlCreator.createObjectURL(blob)) :
              'assets/image/no-photo.png';
          });
        } else {
          this.user.avatar = 'assets/image/no-photo.png';
        }
      });
  }

  getRole() {
    switch (this.user.role) {
      case 'root':
        return 'Root Admin';
      case 'admin':
        return 'Halkin Employee Admin';
      case 'moderator':
        return 'Managerial User';
      case 'user':
        return 'Executive Viewer';
    }
  }

  uploadPhoto(event) {
    const target = event.target || event.srcElement;
    this.selectedImage = target.files[0];
    const urlCreator = window.URL;
    this.user.avatar = this.sanitizer.bypassSecurityTrustUrl(urlCreator.createObjectURL(this.selectedImage));
  }

  updateUser(form: NgForm) {
    const formData = form.controls;
    let data: any;
    if (this.user.role !== 'root' && this.user.role !== 'admin') {
      data = {
        address: formData.addressCtrl.value,
        city: formData.cityCtrl.value,
        email: formData.emailCtrl.value,
        firstname: formData.firstNameCtrl.value,
        lastname: formData.surnameCtrl.value,
        phoneNumber: formData.phoneCtrl.value,
        secretQuestionAnswer: formData.answerCtrl.value,
        secretQuestionId: formData.secretQuestionIdCtrl.value
      };
    } else if (this.user.role === 'root' || this.user.role === 'admin') {
      data = {
        address: formData.addressCtrl.value,
        city: formData.cityCtrl.value,
        email: formData.emailCtrl.value,
        firstname: formData.firstNameCtrl.value,
        lastname: formData.surnameCtrl.value,
        phoneNumber: formData.phoneCtrl.value
      };
    }
    this.usersService.editUser(this.user._id, data)
      .subscribe((res) => {
        if (res.value) {
          if (this.selectedImage) {
            this.updateUserAvatar();
          }
          if (this.user.role !== 'user') {
            this.router.navigateByUrl('/dashboard/users');
          } else {
            this.router.navigateByUrl('/dashboard/files/properties');
          }
        }
      });
  }

  changeSecretQuestion(value: string) {
    this.editProfileFormGroup.controls.secretQuestionId.setValue(
      this.options.findIndex((item: string) => {
        return item === value;
      })
    );
  }

  updateUserAvatar() {
    this.usersService.updateUserAvatar(this.user._id, this.selectedImage)
      .subscribe(() => {
        this.getUser();
      });
  }

  onDeleteAvatar() {
    this.usersService.deleteUserAvatar(this.user._id)
      .subscribe((res) => {
        if (res.value) {
          this.user.avatar = 'assets/image/no-photo.png';
        }
      });
  }
}
