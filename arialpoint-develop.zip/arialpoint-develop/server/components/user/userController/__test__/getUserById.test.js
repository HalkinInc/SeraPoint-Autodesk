const request = require("supertest");
const expect = require("expect");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { users } = require("./seeds");

it("error if provided user id is not valid", async () => {
    const token = users[0].jwt;
    const userId = "1234567890";
    const url = `/user/${userId}`;

    const response = await request(server).get(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'params/id' should be valid 'objectId'");

    expect(value).not.toBeDefined();
});

it("error if provided user id is valid but user doesn't exist", async () => {
    const token = users[0].jwt;
    const userId = ObjectId().toString();
    const url = `/user/${userId}`;

    const response = await request(server).get(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("User not found");

    expect(value).not.toBeDefined();
});

it("error if user was deleted", async () => {
    const token = users[0].jwt;
    const userId = users[2]._id.toString();
    const url = `/user/${userId}`;

    const response = await request(server).get(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("User was deleted");

    expect(value).not.toBeDefined();
});

it("user:read:any can get any user", async () => {
    const token = users[0].jwt;
    const userId = users[1]._id.toString();
    const url = `/user/${userId}`;
    const response = await request(server).get(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value.length).toBe(1);
    expect(value[0].email).toBe(users[1].email);
});

it("user:read:tenant can get user of his tenant", async () => {
    const token = users[1].jwt;
    const userId = users[5]._id.toString();
    const url = `/user/${userId}`;
    const response = await request(server).get(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
    expect(value.length).toBe(1);
    expect(value[0].email).toBe(users[5].email);
});

it("user:read:tenant can't get user of not his tenant", async () => {
    const token = users[1].jwt;
    const userId = users[7]._id.toString();
    const url = `/user/${userId}`;
    const response = await request(server).get(url).set("Authorization", token);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Permission denied");

    expect(value).not.toBeDefined();
});
