const axios = require("axios");
const config = require("config");

const authorization = require("../../../middleware/authorization");

const autodesk = async (req, res, next) => {
    try {
        const { query: { action } } = req;

        const { data: { access_token: token } } = await axios.post(
            "https://developer.api.autodesk.com/authentication/v1/authenticate",
            `client_id=${config.forge.clientId}&client_secret=${config.forge.clientSecret}&grant_type=client_credentials&scope=${["data:read", "data:write", "data:create", "data:search", "bucket:create", "bucket:read", "bucket:update", "bucket:delete"].join(" ")}`,
            { headers: { "Content-Type": "application/x-www-form-urlencoded" } });

        const actions = {
            getBuckets: async () => {
                const { data } = await axios.get(
                    "https://developer.api.autodesk.com/oss/v2/buckets",
                    { headers: { "Authorization": `Bearer ${token}` } });

                return res.send(data);
            },
            getBucket: async () => {
                const { data } = await axios.get(
                    `https://developer.api.autodesk.com/oss/v2/buckets/${config.forge.bucketKey}/details`,
                    { headers: { "Authorization": `Bearer ${token}` } });

                return res.send(data);
            },
            createBucket: async () => {
                const { data } = await axios.post(
                    "https://developer.api.autodesk.com/oss/v2/buckets",
                    { bucketKey: config.forge.bucketKey, policyKey: "persistent" },
                    { headers: { "Authorization": `Bearer ${token}` } });

                return res.send(data);
            },
            deleteBucket: async () => {
                const { data } = await axios.delete(
                    `https://developer.api.autodesk.com/oss/v2/buckets/${config.forge.bucketKey}`,
                    { headers: { "Authorization": `Bearer ${token}` } });

                return res.send(data);
            },
            getObjects: async () => {
                const { data } = await axios.get(
                    `https://developer.api.autodesk.com/oss/v2/buckets/${config.forge.bucketKey}/objects?limit=100`,
                    { headers: { "Authorization": `Bearer ${token}` } });

                return res.send(data);
            }
        };

        if (actions.hasOwnProperty(action)) return await actions[action]();
        else return next("action is not correct");
    } catch (error) { return next(error.response.data.reason); }
};

module.exports = [
    authorization(["dxf-file:create:any"]),
    autodesk
];