import { Component, OnInit } from '@angular/core';
import { UsersService } from '../../../services/users.service';
import { AnotationsService } from '../../../services/anotations.service';
import { SettingsService } from '../../../services/settings.service';
import { Annotation } from '../../../models/annotation.model';
import { Location } from '@angular/common';

@Component({
  selector: 'app-annotations',
  templateUrl: './annotations.component.html',
  styleUrls: ['./annotations.component.scss']
})
export class AnnotationsComponent implements OnInit {
  annotations: Array<Annotation> = new Array();
  searchAnnotation: string;
  tenantId: string;
  daysToDelete = 30;
  currentUserRole: string;

  constructor(
    private location: Location,
    private usersService: UsersService,
    private anotationsService: AnotationsService,
    private settingsService: SettingsService) { }

  ngOnInit() {
    this.getUser();
  }

  getUser() {
    this.usersService.getUser().subscribe((res) => {
      if (res.value.tenantId) {
        this.tenantId = res.value.tenantId;
      }
      this.currentUserRole = res.value.role;
      this.getSettings();
      this.getDeleteAnnotations(this.tenantId);
    });
  }

  getSettings() {
    this.settingsService.getSettings().subscribe((result) => {
      if (result.value) {
        this.daysToDelete = result.value.deletedAnnotationsDaysLimit;
      }
    });
  }

  getDeleteAnnotations(tenantId: string, search?: string) {
    this.anotationsService.getDeleteAnnotations(tenantId).subscribe((res) => {
      if (res.errors.length === 0) {
        let result = res.value;
        result.map(element => {
          element['select'] = false;
        });
        if (search) {
          search = search.toLowerCase();
          result = result.filter((item) => {
            return item ? (item.fileName.toLowerCase().indexOf(search) >= 0) : false;
          });
        }
        this.annotations = result;
      }
    });
  }

  back() {
    this.location.back();
  }

  search(search: string) {
    this.getDeleteAnnotations(this.tenantId, search);
  }

  onRestoreSelect() {
    const selectedAnnotation = this.annotations.filter((file) => {
      return file.select;
    });
    if (selectedAnnotation.length > 0) {
      selectedAnnotation.filter((element) => {
        this.anotationsService.editAnnotation(element._id, { deleted: false }).subscribe((res) => {
          if (res.value) {
            this.getDeleteAnnotations(this.tenantId);
          }
        });
      });
    }
  }

  changeDaysToDelete(days: number) {
    this.settingsService.updateSettings('deletedAnnotationsDaysLimit', days).subscribe((res) => {
      this.getSettings();
    });
  }

  trackByFn(index, item) {
    return item.id;
  }
}
