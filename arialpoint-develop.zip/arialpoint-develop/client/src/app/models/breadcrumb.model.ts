export class BreadcrumbModel {
  constructor(
    public label?: string,
    public url?: string
  ) { }
}
