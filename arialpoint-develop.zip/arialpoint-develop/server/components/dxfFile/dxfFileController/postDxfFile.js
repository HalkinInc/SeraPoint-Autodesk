const DxfFileService = require("../dxfFileService");
const TenantService = require("../../tenant/tenantService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const fileUpload = require("../../../middleware/fileUpload");

const postDxfFile = async (req, res, next) => {
    try {
        const { authUser, formData: { tenantId }, files: { file } } = req;

        await TenantService.getTenantById(tenantId);

        const { urn, fileKey } = await DxfFileService.uploadDxfFile(file);

        await DxfFileService.createDxfFile({
            urn,
            creatorId: authUser._id.toString(),
            tenantId,
            fileName: file.name,
            fileKey,
            fileSize: file.size,
        });

        return res.status(201).send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const postDxfFileSchema = {
    formData: {
        type: "object",
        required: ["tenantId",],
        additionalProperties: false,
        properties: {
            tenantId: { type: "string", objectId: true },
        }
    }
};

module.exports = [
    authorization(["dxf-file:create:any"]),
    fileUpload({ file: { required: true, extensions: [".dxf"] } }),
    requestValidation(postDxfFileSchema),
    postDxfFile
];