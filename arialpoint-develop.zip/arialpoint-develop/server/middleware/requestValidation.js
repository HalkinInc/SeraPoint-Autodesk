const validate = require("../utils/validate");
const appErrors = require("../utils/appErrors");

module.exports = (reqSchemaConfig = {}) => {
    const reqSchema = {
        type: "object",
        required: ["params", "query", "body"],
        additionalProperties: false,
        properties: {
            params: {
                type: "object",
                required: [],
                additionalProperties: false,
                properties: {}

            },
            query: {
                type: "object",
                required: [],
                additionalProperties: false,
                properties: {}
            },
            body: {
                type: "object",
                required: [],
                additionalProperties: false,
                properties: {}
            },
            formData: {
                type: "object",
                required: [],
                additionalProperties: false,
                properties: {}
            }
        }
    };

    return (req, res, next) => {
        try {
            const reqObject = {
                params: { ...req.params },
                query: { ...req.query },
                body: { ...req.body },
                formData: { ...req.formData }
            };

            for (const key of Object.keys(reqSchema.properties)) if (reqSchemaConfig[key] !== undefined) reqSchema.properties[key] = reqSchemaConfig[key];

            const validationError = validate(reqSchema, reqObject);
            if (validationError !== null) throw new appErrors.RequestError(validationError);

            next();
        } catch (error) { return next(error); }
    };
}; 