const { Router } = require("express");

const auxController = require("./auxController/auxController");

const auxRouter = new Router();

auxRouter.post("/aux/seeds", auxController.seeds);
auxRouter.get("/aux/settings", auxController.getSettings);
auxRouter.patch("/aux/settings", auxController.patchSettings);

module.exports = auxRouter;

