export class BreadCrumb {
  constructor(
    public label?: string,
    public url?: string
  ) {}
}
