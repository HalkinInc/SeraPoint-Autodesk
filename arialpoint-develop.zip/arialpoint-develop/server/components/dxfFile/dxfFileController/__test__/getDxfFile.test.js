const assert = require("assert");

const request = require("supertest");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { tenants, dxfFiles, users } = require("./seeds");

it("error if provided tenant id is not valid", async () => {
    const token = users[0].jwt;
    const tenantId = "1234567890";
    const response = await request(server).get(`/dxf-file?tenantId=${tenantId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'query/tenantId' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if tenant doesn't exist", async () => {
    const token = users[0].jwt;
    const tenantId = ObjectId().toString();
    const response = await request(server).get(`/dxf-file?tenantId=${tenantId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Tenant not found");

    assert.strictEqual(value, undefined);
});

it("error if tenant is deleted", async () => {
    const token = users[0].jwt;
    const tenantId = tenants[2]._id.toString();
    const response = await request(server).get(`/dxf-file?tenantId=${tenantId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Tenant was deleted");

    assert.strictEqual(value, undefined);
});

it("dxf-files:read:any can get files of tenant if tenant id is provided ", async () => {
    const token = users[0].jwt;
    const tenantId = tenants[0]._id.toString();
    const response = await request(server).get(`/dxf-file?tenantId=${tenantId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value.length, 1);
    assert.strictEqual(value[0].name, dxfFiles[0].name);
});

it("dxf-files:read:any can get all dxf files if tenant is not provided", async () => {
    const token = users[0].jwt;
    const response = await request(server).get("/dxf-file").set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value.length, 3);
});

it("dxf-file:read:tenant can get all files of his tenant", async () => {
    const token = users[1].jwt;
    const tenantId = tenants[0]._id.toString();
    const response = await request(server).get(`/dxf-file?tenantId=${tenantId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.notStrictEqual(value, undefined);
    assert.strictEqual(value.length, 1);
});

it("dxf-file:read:tenant can't get all files of not his tenant", async () => {
    const token = users[1].jwt;
    const tenantId = tenants[1]._id.toString();
    const response = await request(server).get(`/dxf-file?tenantId=${tenantId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("should return deleted files", async () => {
    const { body: { errors, value } } = await request(server)
        .get("/dxf-file?deleted=true")
        .set("Authorization", users[0].jwt);

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value.length, 1);
});