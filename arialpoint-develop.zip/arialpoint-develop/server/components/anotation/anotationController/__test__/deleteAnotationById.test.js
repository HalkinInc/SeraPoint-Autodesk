const assert = require("assert");

const request = require("supertest");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { users, anotations } = require("./seed");

it("error if anotation id is invalid", async () => {
    const anotationId = "1234567890";
    const token = users[0].jwt;

    const response = await request(server).delete(`/anotation/${anotationId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'params/id' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if anotation not found", async () => {
    const anotationId = ObjectId().toString();
    const token = users[0].jwt;

    const response = await request(server).delete(`/anotation/${anotationId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Anotation not found");

    assert.strictEqual(value, undefined);
});

it("error if anotation is already deleted", async () => {
    const anotationId = anotations[3]._id.toString();
    const token = users[0].jwt;

    const response = await request(server).delete(`/anotation/${anotationId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Anotation was deleted");

    assert.strictEqual(value, undefined);
});

it("anotation:delete:any can delete any anotation", async () => {
    const anotationId = anotations[4]._id.toString();
    const token = users[0].jwt;

    const response = await request(server).delete(`/anotation/${anotationId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});

it("anotation:delete:tenant can delete anotation of his tenant", async () => {
    const anotationId = anotations[0]._id.toString();
    const token = users[1].jwt;

    const response = await request(server).delete(`/anotation/${anotationId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});

it("anotation:delete:tenant can't delete anotation of not his tenant", async () => {
    const anotationId = anotations[4]._id.toString();
    const token = users[1].jwt;

    const response = await request(server).delete(`/anotation/${anotationId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("anotation:delete:own can delete his anotation", async () => {
    const anotationId = anotations[1]._id.toString();
    const token = users[2].jwt;

    const response = await request(server).delete(`/anotation/${anotationId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});


it("anotation:delete:own can't delete not his anotation", async () => {
    const anotationId = anotations[4]._id.toString();
    const token = users[2].jwt;

    const response = await request(server).delete(`/anotation/${anotationId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});