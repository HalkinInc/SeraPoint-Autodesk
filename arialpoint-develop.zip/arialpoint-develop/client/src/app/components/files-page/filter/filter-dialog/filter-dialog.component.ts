import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FilterData } from '../../../../models/filter.model';

@Component({
  selector: 'app-filter-dialog',
  templateUrl: './filter-dialog.component.html',
  styleUrls: ['./filter-dialog.component.scss']
})
export class FilterDialogComponent {
  filter: FilterDialog = new FilterDialog();
  showEditWindow = false;

  constructor(public dialogRef: MatDialogRef<FilterDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: FilterData) {
    if (data.title) {
      this.filter.title = data.title;
      this.filter.description = data.description;
      this.showEditWindow = true;
    }
  }

  onNoClick() {
    this.dialogRef.close({ title: undefined, description: undefined });
    this.showEditWindow = false;
  }

  onSaveFilter() {
    this.dialogRef.close(this.filter);
    this.showEditWindow = false;
  }

  onEditFilter() {
    const result = { ...this.data };
    result.title = this.filter.title;
    result.description = this.filter.description;
    this.dialogRef.close(result);
    this.showEditWindow = false;
  }
}
export class FilterDialog {
  constructor(
    public title?: string,
    public description?: string
  ) {}
}
