import { Extension } from 'ng2-adsk-forge-viewer';
import { PINED_BLOCK } from './view-page.component';
import { untilDestroyed } from 'ngx-take-until-destroy';
import { OnDestroy } from '@angular/core';

declare const THREE: any;

export class MarkupExt extends Extension implements OnDestroy {
    public static extensionName = 'markup3d';
    size = 30.0;
    scene: any;
    pointCloud: any;
    camera: any;
    vertexShader = `
        uniform float size;
        void main() {
            vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );
            gl_PointSize = size;
            gl_Position = projectionMatrix * mvPosition;
        }
    `;
    fragmentShader = `
        uniform sampler2D tex;
        void main() {
            gl_FragColor = vec4( texture2D(tex, vec2((gl_PointCoord.x), 1.0-gl_PointCoord.y)).xyz, 1.0);
            if (gl_FragColor.w < 0.5) discard;
        }
    `;
    geometry = new THREE.Geometry();

    constructor (protected viewer: Autodesk.Viewing.Viewer3D,
        protected extOptions: Autodesk.Viewing.ExtensionOptions) {
        super(viewer, extOptions);
        this.scene = viewer['impl'].sceneAfter;
    }

    public load() {
        this.viewer.addEventListener(Autodesk.Viewing.FINAL_FRAME_RENDERED_CHANGED_EVENT, (e: Autodesk.Viewing.ViewerEvent) => {
            if (this.viewer['model']) {
                PINED_BLOCK.pipe(untilDestroyed(this)).subscribe((res: Array<string>) => {
                    this.geometry.dispose();
                    this.geometry = new THREE.Geometry();
                    this.setMarkupData(res);
                });
            }
        });
    }

    setMarkupData(data) {
        const model = this.viewer['model'];
        const instanceTree = model.getData().instanceTree;
        const fragList = model.getFragmentList();
        data.map(item => {
            const dbId = item;
            const bounds = new THREE.Box3();
            const box = new THREE.Box3();
            if (instanceTree) {
                instanceTree.enumNodeFragments( +dbId, ( fragId ) => {
                    const frag = fragList.geoms.geoms[fragId + 1];
                    frag.computeFaceNormals();
                    fragList.getWorldBounds( fragId, box );
                    bounds.union( box );
                }, true );
                const worldPoint = bounds.center();
                const point = (new THREE.Vector3(worldPoint.x, worldPoint.y, worldPoint.z));
                this.geometry.vertices.push(point);
            }
        });
        this.initMesh_PointCloud();
    }

    initMesh_PointCloud() {
        let material: any;
        const texture = THREE.ImageUtils.loadTexture('/assets/image/pin2.png');
        material = new THREE.ShaderMaterial({
            vertexColors: THREE.VertexColors,
            fragmentShader: this.fragmentShader,
            vertexShader: this.vertexShader,
            transparent: true,
            opacity: 0.7,
            depthWrite: true,
            depthTest: true,
            uniforms: {
                size: { type: 'f', value: this.size },
                tex: { type: 't', value: texture }
            }
        });
        this.scene.remove(this.pointCloud);
        this.pointCloud = new THREE.PointCloud(this.geometry, material);
        // this.pointCloud.position.sub( { x: 20, y: 20, z: -20 } );
        this.scene.add(this.pointCloud);
    }

    unload() {
        return true;
    }

    ngOnDestroy() {}
}
