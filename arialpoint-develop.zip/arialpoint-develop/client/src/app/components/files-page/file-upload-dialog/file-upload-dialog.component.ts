import { MatDialogRef } from '@angular/material';
import { Component } from '@angular/core';

@Component({
  selector: 'app-file-upload-dialog',
  templateUrl: './file-upload-dialog.component.html',
  styleUrls: ['./file-upload-dialog.component.scss']
})
export class FileUploadDialogComponent {
  files: FileList;

  constructor(public dialogRef: MatDialogRef<FileUploadDialogComponent>) { }

  addFile(event) {
    const target = event.target || event.srcElement;
    this.files = target.files;
  }

  onNoClick(): void {
    this.dialogRef.close(this.files);
  }
}
