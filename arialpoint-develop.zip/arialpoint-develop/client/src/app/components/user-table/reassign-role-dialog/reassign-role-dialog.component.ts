import { Component, OnInit, Inject, ElementRef, ViewChild } from '@angular/core';
import { MatAutocompleteSelectedEvent, MatChipInputEvent, MatAutocomplete,
  MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { User } from '../../../models/user.model';
import { FormBuilder, FormGroup, Validators, NgForm, FormControl } from '@angular/forms';
import { UsersService } from '../../../services/users.service';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-reassign-role-dialog',
  templateUrl: './reassign-role-dialog.component.html',
  styleUrls: ['./reassign-role-dialog.component.scss']
})
export class ReassignRoleDialogComponent implements OnInit {
  currentUser: User = new User();
  users: Array<User> = new Array();
  reassignRoleForm: FormGroup;
  formSubmitted = false;
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  userCtrl = new FormControl();
  filteredUsers: Observable<User[]>;
  allUsers: Array<User> = new Array();
  @ViewChild('userInput') userInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  constructor(public dialogRef: MatDialogRef<ReassignRoleDialogComponent>,
     private usersService: UsersService,
     @Inject(MAT_DIALOG_DATA) public data: any,
     private _formBuilder: FormBuilder) {
      this.currentUser = {...data.user};
      this.allUsers = data.allUsers;

      this.filteredUsers = this.userCtrl.valueChanges.pipe(
        startWith(null),
        map((item: User | null) => item ? this._filter(item) : this.allUsers.slice()));
  }

  ngOnInit() {
    this.reassignRoleForm = this._formBuilder.group({
      firstNameCtrl: ['', Validators.required],
      surnameCtrl: ['', Validators.required],
      tenantCtrl: [''],
      emailCtrl: ['', Validators.required],
      roleCtrl: ['', Validators.required]
    });
    this.reassignRoleForm.controls['firstNameCtrl'].setValue(this.currentUser.firstname || '');
    this.reassignRoleForm.controls['surnameCtrl'].setValue(this.currentUser.lastname || '');
    this.reassignRoleForm.controls['tenantCtrl'].setValue(this.currentUser.tenantName || '');
    this.reassignRoleForm.controls['emailCtrl'].setValue(this.currentUser.email || '');
    this.reassignRoleForm.controls['roleCtrl'].setValue(this.currentUser.role || '');
  }

  submitForm(form: NgForm) {
    this.formSubmitted = true;
    if (form.valid) {
      this.formSubmitted = false;
      const dialogResult = {
        firstName: this.reassignRoleForm.controls['firstNameCtrl'].value,
        lastName: this.reassignRoleForm.controls['surnameCtrl'].value,
        email: this.reassignRoleForm.controls['emailCtrl'].value,
        tenant: this.reassignRoleForm.controls['tenantCtrl'].value,
        role: this.reassignRoleForm.controls['roleCtrl'].value,
        newUserRole: this.users
      };
      this.dialogRef.close(dialogResult);
    }
  }

  getFormValidationMessages(state: any, thingName?: string) {
    const messages: string[] = [];
    if (state.errors) {
      Object.keys(state.errors).forEach(errorName => {
        switch (errorName) {
          case 'required':
            messages.push(`You must enter a ${thingName}`);
            break;
          case 'minlength':
            messages.push(`A ${thingName} must be aleast ${state.errors['minlength'].requiredLength} characters`);
            break;
          case 'pattern':
            messages.push(`The ${thingName} contains illegal characters`);
            break;
        }
      });
    }
    return messages;
  }

  add(event: MatChipInputEvent): void {
    if (!this.matAutocomplete.isOpen) {
      const input = event.input;
      if (input) {
        input.value = '';
      }
      this.userCtrl.setValue(null);
    }
  }

  remove(item: User): void {
    const index = this.users.indexOf(item);

    if (index >= 0) {
      this.users.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.users.push(event.option.value);
    this.userInput.nativeElement.value = '';
    this.userCtrl.setValue(null);
    this.userInput.nativeElement.blur();
  }

  private _filter(value: User): Array<User> {
    const filterValue = (`${value.firstname} ${value.lastname}`).toLowerCase();
    return this.allUsers.filter(user => (`${user.firstname} ${user.lastname}`).toLowerCase().indexOf(filterValue) === 0);
  }

  onNoClick() {
    this.dialogRef.close();
  }
}
