import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResendInviteDialogComponent } from './resend-invite-dialog.component';

describe('ResendInviteDialogComponent', () => {
  let component: ResendInviteDialogComponent;
  let fixture: ComponentFixture<ResendInviteDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResendInviteDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResendInviteDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
