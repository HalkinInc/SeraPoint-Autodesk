import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FilterService } from '../../../services/filter.service';
import { User } from '../../../models/user.model';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { ElementRef, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent, MatChipInputEvent, MatAutocomplete, MatDialog } from '@angular/material';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { FilterDialogComponent } from './filter-dialog/filter-dialog.component';
import { FilterData } from '../../../models/filter.model';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {
  currentUser: User;
  users: Array<User> = new Array();
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  separatorKeysCodes: Array<number> = [ENTER, COMMA];
  userCtrl = new FormControl();
  filteredUsers: Observable<any>;
  dateSort = 'anytime';
  filtersData: Array<FilterData> = new Array();

  @Input() allUsers: Array<User>;
  @ViewChild('userInput') userInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  @Output() changedFilter = new EventEmitter<Filter>();

  constructor(public dialog: MatDialog, public filterService: FilterService) {
    this.filteredUsers = this.userCtrl.valueChanges.pipe(
      startWith(null),
      map((user: User | null) => user ? this._filter(user) : this.allUsers.slice()));
  }

  ngOnInit() {
    this.getFilters();
  }

  add(event: MatChipInputEvent): void {
    if (!this.matAutocomplete.isOpen) {
      const input = event.input;
      if (input) {
        input.value = '';
      }
      this.userCtrl.setValue(null);
    }
  }

  remove(user: User): void {
    const index = this.users.indexOf(user);
    if (index >= 0) {
      this.users.splice(index, 1);
    }
    const arr = this.users.map((item) => {
      return `${item.firstname.toLowerCase()} ${item.lastname.toLowerCase()}`;
    });
    this.changedFilter.emit({ users: arr, date: this.dateSort });
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.users.push(event.option.value);
    this.userInput.nativeElement.value = '';
    this.userCtrl.setValue(null);
    this.userInput.nativeElement.blur();
    this.change(this.users);
  }

  private _filter(value: User): User[] {
    const filterValue = (`${value.firstname} ${value.lastname}`).toLowerCase();
    return this.allUsers.filter(user => (`${user.firstname} ${user.lastname}`).toLowerCase().indexOf(filterValue) === 0);
  }

  get changeDXFList() {
    const arr = this.users.map((item) => {
      return `${item.firstname.toLowerCase()} ${item.lastname.toLowerCase()}`;
    });
    this.changedFilter.emit({ users: arr, date: this.dateSort });
    return;
  }

  change(user: Array<User>) {
    const arr = user.map((item) => {
      return `${item.firstname.toLowerCase()} ${item.lastname.toLowerCase()}`;
    });
    this.changedFilter.emit({ users: arr, date: this.dateSort });
  }

  openDialog() {
    const dialogRef = this.dialog.open(FilterDialogComponent, {
      width: '500px',
      data: {},
      disableClose: false
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result.title && result.description) {
        const arr = this.users.map((item) => {
          return `${item.firstname.toLowerCase()} ${item.lastname.toLowerCase()}`;
        });
        const data = {
          title: result.title,
          description: result.description,
          users: arr,
          date: this.dateSort
        };
        this.filterService.createFilter(data)
          .subscribe((res) => {
            if (res.value) {
              this.users = new Array();
              this.dateSort = 'anytime';
              this.getFilters();
            }
          });
      }
    });
  }

  getFilters() {
    this.filterService.getFilters()
      .subscribe((res) => {
        if (res.value) {
          this.filtersData = res.value;
        }
      });
  }

  onDeleteFilter(id) {
    this.filterService.deleteFilter(id)
      .subscribe((res) => {
        if (res.value) {
          this.getFilters();
        }
      });
  }

  onEditFilter(filter: FilterData) {
    const editFilterDialog = this.dialog.open(FilterDialogComponent, {
      width: '500px',
      data: filter
    });

    editFilterDialog.afterClosed().subscribe((result) => {
      this.filterService.editFilter(result)
        .subscribe((res) => {
          if (res.value) {
            this.getFilters();
          }
        });
    });
  }

  useFilter(filter: FilterData) {
    this.changedFilter.emit({ users: filter.users, date: filter.date });
  }
}

export class Filter {
  constructor(
    public users?: Array<string>,
    public date?: string
  ) {}
}
