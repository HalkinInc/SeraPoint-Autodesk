import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, } from '@angular/material';
import { UsersService } from '../../services/users.service';
import { User } from 'src/app/models/user.model';
import { roles } from '../../pipes/role.pipe';
import { MatDialog } from '@angular/material';
import { ReassignRoleDialogComponent } from './reassign-role-dialog/reassign-role-dialog.component';

@Component({
  selector: 'app-user-table',
  templateUrl: './user-table.component.html',
  styleUrls: ['./user-table.component.scss']
})
export class UserTableComponent implements OnInit {
  dataSource: MatTableDataSource<User>;
  roles = Object.keys(roles);
  resultsLength = 0;
  @Input() displayedColumns: Array<string>;
  @Input() tenantId: string;
  private paginator: MatPaginator;
  private sort: MatSort;
  searchUser: string;
  filteredUsers = false;
  currentUser: User;

  @ViewChild(MatSort) set matSort(ms: MatSort) {
    this.sort = ms;
    this.setDataSourceAttributes();
  }

  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.setDataSourceAttributes();
  }

  constructor(public dialog: MatDialog,
    private usersService: UsersService) { }

  setDataSourceAttributes() {
    if (this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }
  }

  getUsers(id, user?: string) {
    this.usersService.getUsers(id).subscribe((res) => {
      let result = res['value'].map(el => ({ ...el, 'editable': false }));
      this.filteredUsers = !!user;
      if (user) {
        user = user.toLowerCase();
        result = result.filter((item) => {
          return item ? (item.firstname.toLowerCase().indexOf(user) >= 0 || item.lastname.toLowerCase().indexOf(user) >= 0) : false;
        });
      }
      this.dataSource = new MatTableDataSource(result);
    });
  }

  onEditable(row) {
    if (row.role === 'user' || row.role === 'admin') {
      row.editable = !row.editable;
    } else {
      let allUsers: Array<User> = new Array();
      let id = '';
      if (row.role !== 'root') {
        id = row.tenantId;
      }
      this.usersService.getUsers(id).subscribe((res) => {
        if (row.role === 'root') {
          allUsers = res['value'].filter((el) => {
            if (el.role === 'admin') {
              return el;
            }
          });
          this.openDialog(row, allUsers);
        } else {
          allUsers = res['value'].filter((el) => {
            if (row._id !== el._id && el.role !== 'admin' && this.currentUser._id !== el._id) {
              return el;
            }
          });
          const count = allUsers.filter((item) => {
            return item.role === 'moderator';
          });
          if (count.length >= 1) {
            row.editable = !row.editable;
          } else {
            this.openDialog(row, allUsers);
          }
        }
      });
    }
  }

  openDialog(row, allUsers) {
    const dialogRef = this.dialog.open(ReassignRoleDialogComponent, {
      width: '685px',
      data: { user: row, allUsers }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (row.role === 'root' && result.newUserRole.length > 0) {
        const url = `/api/user/${row._id}?newRootId=${result.newUserRole[0]._id}`;
        delete result.newUserRole;
        this.usersService.changeRole(url)
          .subscribe((res1) => {
            this.getUsers(this.tenantId);
          });
      } else if (result.newUserRole.length > 0) {
        const url = `/api/user/${row._id}?newModeratorId=${result.newUserRole[0]._id}`;
        delete result.newUserRole;
        this.usersService.changeRole(url)
          .subscribe((res1) => {
            this.getUsers(this.tenantId);
          });
      }
    });
  }

  onEditUser(row) {
    row.editable = !row.editable;
    const updatedData = {
      address: row.address,
      city: row.city,
      email: row.email,
      firstname: row.firstname,
      lastname: row.lastname,
      phoneNumber: row.phoneNumber,
      secretQuestionAnswer: row.secretQuestionAnswer,
      secretQuestionId: row.secretQuestionId,
      state: row.state,
      role: row.role
    };
    this.usersService.editUser(row._id, updatedData)
      .subscribe((res) => {
        this.getUsers(res.value);
      });
  }

  onDeleteUser(id) {
    this.usersService.deleteUser(id)
      .subscribe((res) => {
        this.getUsers(this.tenantId);
      });
  }

  ngOnInit() {
    this.getUser();
  }

  getUser() {
    this.usersService.getUser()
      .subscribe(res => {
        this.currentUser = res.value;
      });
  }
}
