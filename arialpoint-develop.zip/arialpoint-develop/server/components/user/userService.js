const path = require("path");

const { hashSync, compareSync } = require("bcrypt-nodejs");
const shortUUID = require("short-uuid");
const sgMail = require("@sendgrid/mail");
const config = require("config");
const { ObjectId, Long } = require("mongodb");
const jsonwebtoken = require("jsonwebtoken");
const uuidv4 = require("uuid");
const AWS = require("aws-sdk");

const UserModel = require("./userModel");
const TenantService = require("../tenant/tenantService");
const validate = require("../../utils/validate");
const appErrors = require("../../utils/appErrors");

const s3 = new AWS.S3({
    params: { Bucket: "serapoint-avatars" },
    credentials: { accessKeyId: config.aws.accessKey, secretAccessKey: config.aws.secretAccessKey }
});

const startRegistrationSchema = {
    type: "object",
    required: ["email", "role", "firstname", "lastname", "finishRegistrationCode", "deleted"],
    additionalProperties: false,
    properties: {
        // required
        email: { type: "string" },
        role: { type: "string", enum: ["root", "admin", "moderator", "user"], default: "user" },
        tenantId: { type: "string" },
        firstname: { type: "string" },
        lastname: { type: "string" },
        finishRegistrationCode: { type: "string" },
        deleted: { type: "boolean", default: false }
    }
};

const startRegistration = async (user, message, sender) => {
    user.finishRegistrationCode = shortUUID.generate();
    const validationError = validate(startRegistrationSchema, user);
    if (validationError !== null) throw new appErrors.RequestError(validationError);

    const foundUser = await UserModel.findOne({ email: user.email });
    if(foundUser !== null) throw new appErrors.RequestError("User already exists");

    await UserModel.insertOne(user);

    await sendInvitation(user.finishRegistrationCode, message, sender);
};

const sendInvitation = async (finishRegistrationCode, message, sender) => {
    const foundUser = await UserModel.findAndEnrichOne({ finishRegistrationCode });
    if (foundUser === null) throw new appErrors.RequestError("Finish registration code isn't valid");

    if (process.env.NODE_ENV !== "test") await sgMail.send({
        to: foundUser.email,
        from: `${sender.firstname} ${sender.lastname} <${sender.email}>`,
        subject: "[SeraPoint]: Finish registration process",
        text: message + (message && "\n" + "\n" + "\n") + `link to finish registration, do not share it with anyone - ${config.app.URL}/user-registration?code=${finishRegistrationCode}`
    });
};

const finishRegistrationSchema = {
    type: "object",
    required: ["address", "city", "state", "firstname", "lastname", "hasAvatar", "phoneNumber", "password", "secretQuestionAnswer", "secretQuestionId"],
    additionalProperties: false,
    properties: {
        // required
        // geo
        address: { type: "string" },
        city: { type: "string" },
        state: { type: "string" },

        // basic
        firstname: { type: "string" },
        lastname: { type: "string" },
        phoneNumber: { type: "string" },
        hasAvatar: { type: "boolean", default: false },

        // secret
        password: { type: "string", minLength: 6 },
        secretQuestionAnswer: { type: "string" },
        secretQuestionId: { type: "integer", minimum: 0, maximum: 2 },

        // not required
        // misc
        avatar: { type: "string" },
        lastLogin: { type: "integer" },
        lastActive: { type: "integer" },
        loginCount: { type: "integer", default: 0 }
    }
};

sgMail.setApiKey(config.email.API_KEY);

const finishRegistration = async (finishRegistrationCode, additionalFields) => {
    const validationError = validate(finishRegistrationSchema, additionalFields);
    if (validationError !== null) throw new appErrors.RequestError(validationError);

    const foundUser = await UserModel.findAndEnrichOne({ finishRegistrationCode });
    if (foundUser === null) throw new appErrors.RequestError("Finish registration code isn't valid");

    await UserModel.updateOne({ finishRegistrationCode },
        {
            $set: {
                ...additionalFields,
                password: hashSync(additionalFields.password),
                hasAvatar: false,
                deleted: false
            }
            , $unset: { finishRegistrationCode: 1 }
        });
};

const getTenantUsers = async (tenantId, deleted = false, limit, skip) => {
    const query = { tenantId, deleted };

    await TenantService.getTenantById(tenantId);

    const result = UserModel.findAndEnrichMany(query, limit, skip, { password: 0 });
    return result;
};

const getAllUsers = async (deleted = false, limit, skip) => {
    const query = { deleted };

    const result = await UserModel.findAndEnrichMany(query, limit, skip, { password: 0 });
    return result;
};

const getUserById = async (id) => {
    const foundUser = await UserModel.findAndEnrichOne({ _id: ObjectId(id) });
    if (foundUser === null) throw new appErrors.NotFoundError("User not found");
    if (foundUser.deleted) throw new appErrors.NotFoundError("User was deleted");
    return foundUser;
};

const getDeletedUserById = async (id) => {
    const foundUser = await UserModel.findAndEnrichOne({ _id: ObjectId(id) });
    if (foundUser === null) throw new appErrors.NotFoundError("User not found");
    return foundUser;
};

const getUserByEmail = async (email) => {
    const foundUser = await UserModel.findAndEnrichOne({ email });
    if (foundUser === null) throw new appErrors.NotFoundError("User not found");
    if (foundUser.deleted) throw new appErrors.NotFoundError("User was deleted");
    return foundUser;
};

const getUserByJwt = async (jwt) => {
    try { jsonwebtoken.verify(jwt, config.app.secret); }
    catch (error) { throw new appErrors.AuthenticationError("Supplied token is invalid"); }

    const { email } = jsonwebtoken.verify(jwt, config.app.secret);

    const foundUser = await UserModel.findAndEnrichOne({ email });
    if (foundUser === null) throw new appErrors.AuthenticationError("Supplied token is invalid");

    delete foundUser.password;

    return foundUser;
};

const updateUserbyId = async (id, fields) => {
    await UserModel.updateOne({ _id: ObjectId(id) }, { $set: fields });
};

const flagAsDeletedAllTenantUsers = async (tenantId) => {
    await UserModel.updateMany({ tenantId }, { $set: { deleted: true, deletedAt: Long.fromNumber(Date.now()) } });
};

const hardDeletedAllTenantUsers = async (tenantId) => {
    await UserModel.deleteMany({ tenantId });
};

const removeUserAvatar = async (id) => {
    const foundUser = await getUserById(id);
    if (foundUser.avatar === undefined) throw new appErrors.NotFoundError("User has no avatar");

    if (process.env.NODE_ENV !== "test") await s3.deleteObject({ Key: foundUser.avatar }).promise();

    await UserModel.updateOne({ _id: ObjectId(id) }, { $unset: { avatar: "" } });
};

const addUserAvatar = async (id, file) => {
    const foundUser = getUserById(id);

    const genFilename = uuidv4() + path.extname(file.name);

    if (process.env.NODE_ENV !== "test") Promise.all([
        await s3.upload({ Key: genFilename, Body: file.read() }).promise(),
        foundUser.avatar !== undefined ? await s3.deleteObject({ Key: foundUser.avatar }).promise() : null
    ]);

    await updateUserbyId(id, { avatar: genFilename });
};

const getUserAvatar = async (id) => {
    const foundUser = await getUserById(id);
    if (foundUser.avatar === undefined) throw new appErrors.NotFoundError("User has no avatar");

    if (process.env.NODE_ENV === "test") return "avatar.png";

    return await s3.getObject({ Key: foundUser.avatar }).promise();
};

const flagUserAsDeleted = async (id) => {
    await UserModel.updateOne({ _id: ObjectId(id) }, { $set: { deleted: true, deletedAt: Long.fromNumber(Date.now()) } });
};

const unflagUserAsDeleted = async (id) => {
    await UserModel.updateOne({ _id: ObjectId(id) }, { $set: { deleted: false }, $unset: { deletedAt: "" } });
};

const checkIsAnswerCorrect = async (email, answer) => {
    const foundUser = await getUserByEmail(email);
    if (foundUser.secretQuestionAnswer !== answer) throw new appErrors.RequestError("Answer is not correct");
};

const setNewPassword = async (email, answer, password) => {
    await checkIsAnswerCorrect(email, answer);

    await UserModel.updateOne({ email }, { $set: { password: hashSync(password) } });
};

const deleteUserById = async (id) => {
    await UserModel.deleteOne({ _id: ObjectId(id) });
};

const loginUser = async (email, password) => {
    const foundUser = await getUserByEmail(email);
    if (foundUser.finishRegistrationCode) throw new appErrors.AuthenticationError("You need to finish your registration process");

    if (!compareSync(password, foundUser.password)) throw new appErrors.AuthenticationError("Password is invalid");

    const now = Long.fromNumber(Date.now());
    await UserModel.updateOne({ email }, { $set: { lastLogin: now, lastActive: now }, $inc: { loginCount: 1 } });

    const payload = { email: foundUser.email };
    return jsonwebtoken.sign(payload, config.app.secret);
};

const authenticateUser = async (jwt) => {
    if (jwt === undefined) throw new appErrors.AuthenticationError("Token is not provided");

    const foundUser = await getUserByJwt(jwt);

    await UserModel.updateOne({ _id: foundUser._id }, { $set: { lastActive: Long.fromNumber(Date.now()) } });

    return foundUser;
};

const reasignRootRole = async (curRootId, newRootId) => {
    const curRoot = await getUserById(curRootId);
    if (curRoot.role !== "root") throw new appErrors.RequestError("User with currentRootId is not root");
    const newRoot = await getUserById(newRootId);
    if (newRoot.role !== "admin") throw new appErrors.RequestError("User with newRootId is not admin");
    await Promise.all([
        updateUserbyId(newRootId, { role: "root" }),
        updateUserbyId(curRootId, { role: "admin" })
    ]);
};

const reasignModeratorRole = async (currentModeratorId, newModeratorId) => {
    const curModerator = await getUserById(currentModeratorId);
    if (curModerator.role !== "moderator") throw new appErrors.RequestError("User with currentModeratorId is not moderator");
    const newModerator = await getUserById(newModeratorId);
    if (curModerator.tenantId !== newModerator.tenantId) throw new appErrors.RequestError("User with newModeratorId is of another tenant");
    if (newModerator.role !== "user") throw new appErrors.RequestError("User with newModeratorId is not user");
    await Promise.all([
        updateUserbyId(newModeratorId, { role: "moderator" }),
        updateUserbyId(currentModeratorId, { role: "user" })
    ]);
};

module.exports = {
    startRegistration,
    sendInvitation,
    finishRegistration,
    getTenantUsers,
    getAllUsers,
    getUserById,
    getDeletedUserById,
    getUserByEmail,
    getUserByJwt,
    updateUserbyId,
    flagAsDeletedAllTenantUsers,
    hardDeletedAllTenantUsers,
    removeUserAvatar,
    addUserAvatar,
    getUserAvatar,
    flagUserAsDeleted,
    unflagUserAsDeleted,
    checkIsAnswerCorrect,
    setNewPassword,
    deleteUserById,
    loginUser,
    authenticateUser,
    reasignRootRole,
    reasignModeratorRole
};