import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
/** Material Modules */
import {
  MatInputModule,
  MatSidenavModule,
  MatMenuModule,
  MatIconModule,
  MatSelectModule,
  MatRadioModule,
  MatGridListModule,
  MatButtonModule,
  MatTabsModule,
  MatBadgeModule,
  MatTableModule,
  MatPaginatorModule,
  MatSortModule,
  MatDialogModule,
  MatStepperModule,
  MatSlideToggleModule,
  MatFormFieldModule,
  MatTreeModule,
  MatProgressBarModule,
  MatListModule,
  MatAutocompleteModule,
  MatCheckboxModule,
  MatCardModule,
  MatChipsModule,
  MatExpansionModule,
  MatProgressSpinnerModule,
  MatSnackBarModule,
  MatTooltipModule
} from '@angular/material';
/** Components */
import { LoginComponent } from './components/login/login.component';
import { RootAdminComponent } from './components/root-admin/root-admin.component';
import { HeaderComponent } from './components/header/header.component';
import { InviteComponent } from './components/invite/invite.component';
import { TenantGroupsComponent } from './components/tenant-groups/tenant-groups.component';
import { InviteDialogComponent } from './components/invite/invite-dialog/invite-dialog.component';
import { LoginHistoryComponent } from './components/login-history/login-history.component';
import { UserRegistrationComponent } from './components/user-registration/user-registration.component';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';
import { DeleteUserComponent } from './components/delete/users/delete-user.component';
import { FilesPageComponent } from './components/files-page/files-page.component';
import { ViewPageComponent } from './components/view-page/view-page.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { AuthService } from './services/auth.service';
import { LoginGuard } from './login.guard';
import { FileUploadDialogComponent } from './components/files-page/file-upload-dialog/file-upload-dialog.component';
import { ConfirmActionComponent } from './components/tenant-groups/confirm-action/confirm-action.component';
import { ViewerModule } from 'ng2-adsk-forge-viewer';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { TenantPageComponent } from './components/tenant-page/tenant-page.component';
import { ResendInviteDialogComponent } from './components/login-history/resend-invite-dialog/resend-invite-dialog.component';
import { UsersService } from './services/users.service';
import { TenantsService } from './services/tenants.service';
import { DXFFilesService } from './services/dxffiles.service';
import { AnotationsService } from './services/anotations.service';
import { AutodeskService } from './services/autodesk.service';
import { AuthInterceptor } from './services/api.interceptor';
import { DxfFilesComponent } from './components/files-page/dxf-files/dxf-files.component';
import { AnnotationFilesComponent } from './components/files-page/annotation-files/annotation-files.component';
import { SizePipe } from './pipes/size.pipe';
import { UpdateAnnotationComponent } from './components/files-page/annotation-files/update-annotation/update-annotation.component';
import { UpdateDxfDialogComponent } from './components/files-page/update-dxf-dialog/update-dxf-dialog.component';
import { UserTableComponent } from './components/user-table/user-table.component';
import { FilterComponent } from './components/files-page/filter/filter.component';
import { FilterDialogComponent } from './components/files-page/filter/filter-dialog/filter-dialog.component';
import { RolePipe } from './pipes/role.pipe';
import { FilterService } from './services/filter.service';
import { BreadcrumbsService } from './services/breadcrumbs.service';
import { ReassignRoleDialogComponent } from './components/user-table/reassign-role-dialog/reassign-role-dialog.component';
import { DateDifferencePipe } from './pipes/date-difference.pipe';
import { DeleteDxffilesComponent } from './components/delete/dxffiles/delete-dxffiles.component';
import { AnnotationsComponent } from './components/delete/annotations/annotations.component';
import { DeleteTenantComponent } from './components/delete/tenants/delete-tenant.component';

@NgModule({
    declarations: [
        AppComponent,
        LoginComponent,
        RootAdminComponent,
        HeaderComponent,
        InviteComponent,
        TenantGroupsComponent,
        InviteDialogComponent,
        LoginHistoryComponent,
        UserRegistrationComponent,
        EditProfileComponent,
        DeleteUserComponent,
        FilesPageComponent,
        ViewPageComponent,
        ForgotPasswordComponent,
        ResetPasswordComponent,
        FileUploadDialogComponent,
        ConfirmActionComponent,
        BreadcrumbComponent,
        TenantPageComponent,
        ResendInviteDialogComponent,
        DxfFilesComponent,
        AnnotationFilesComponent,
        SizePipe,
        UpdateAnnotationComponent,
        UpdateDxfDialogComponent,
        UserTableComponent,
        FilterComponent,
        FilterDialogComponent,
        RolePipe,
        ReassignRoleDialogComponent,
        DateDifferencePipe,
        DeleteDxffilesComponent,
        AnnotationsComponent,
        DeleteTenantComponent
    ],
    imports: [
        BrowserModule,
        HttpClientModule,
        FormsModule,
        ReactiveFormsModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        MatButtonModule,
        MatInputModule,
        MatSidenavModule,
        MatMenuModule,
        MatIconModule,
        MatSelectModule,
        MatRadioModule,
        MatGridListModule,
        MatTabsModule,
        MatBadgeModule,
        MatTableModule,
        MatPaginatorModule,
        MatSortModule,
        MatDialogModule,
        MatStepperModule,
        MatSlideToggleModule,
        MatFormFieldModule,
        MatTreeModule,
        MatProgressBarModule,
        MatListModule,
        MatAutocompleteModule,
        MatCheckboxModule,
        MatCardModule,
        MatChipsModule,
        MatExpansionModule,
        MatProgressSpinnerModule,
        MatSnackBarModule,
        MatTooltipModule,
        NoopAnimationsModule,
        ViewerModule
    ],
    exports: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    entryComponents: [
        InviteDialogComponent,
        FileUploadDialogComponent,
        ConfirmActionComponent,
        ResendInviteDialogComponent,
        UpdateAnnotationComponent,
        UpdateDxfDialogComponent,
        FilterDialogComponent,
        ReassignRoleDialogComponent
    ],
    bootstrap: [AppComponent],
    providers: [
        AuthService,
        UsersService,
        TenantsService,
        DXFFilesService,
        AnotationsService,
        AutodeskService,
        FilterService,
        LoginGuard,
        BreadcrumbsService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthInterceptor,
            multi: true
        },
    ]
})
export class AppModule { }
