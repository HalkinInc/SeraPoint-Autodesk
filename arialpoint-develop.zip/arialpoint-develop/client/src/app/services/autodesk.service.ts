import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AutodeskService {

  constructor(private http: HttpClient) { }

  authenticateAutodesk() {
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded'
    };
    return this.http.get('/api/authenticate-autodesk', { headers })
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }
}
