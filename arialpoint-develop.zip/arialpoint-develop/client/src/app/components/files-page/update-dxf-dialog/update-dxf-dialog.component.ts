import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-update-dxf-dialog',
  templateUrl: './update-dxf-dialog.component.html',
  styleUrls: ['./update-dxf-dialog.component.scss']
})
export class UpdateDxfDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<UpdateDxfDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSendDataToParent() {
    this.dialogRef.close(this.data);
  }
}
