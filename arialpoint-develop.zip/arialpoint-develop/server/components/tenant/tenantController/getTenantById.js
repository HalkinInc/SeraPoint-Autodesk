const TenantService = require("../tenantService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const getTenantById = async (req, res, next) => {
    try {
        const { authUser, params: { id } } = req;

        const foundTenant = await TenantService.getTenantById(id);

        if (authUser.permissions.includes("tenant:read:tenant") && authUser.tenantId !== foundTenant._id.toString()) throw new appErrors.AuthorizationError();

        return res.send({ errors: [], value: foundTenant });
    } catch (error) { return next(error); }
};

const getTenantByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true },
        }
    }
};

module.exports = [
    authorization(["tenant:read:any", "tenant:read:tenant"]),
    requestValidation(getTenantByIdSchema),
    getTenantById
];