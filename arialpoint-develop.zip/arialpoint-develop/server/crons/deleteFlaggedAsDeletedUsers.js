const CronJob = require("cron").CronJob;

const logger = require("../utils/logger");
const UserModel = require("../components/user/userModel");
const SettingsModel = require("../components/aux/settingsModel");

const UNIX_DAY_MIL = 86400000;

module.exports = new CronJob("0 3 * * *", async () => {
    try {
        const { deletedUsersDaysLimit: DAYS_AGO } = await SettingsModel.findOne({ name: "main" });
        const limit = Date.now() - UNIX_DAY_MIL * DAYS_AGO;
        await UserModel.deleteMany({ deletedAt: { $lte: limit } });
        logger.info(`Users flagged as deleted ${DAYS_AGO} days ago removed from database`);
    } catch (error) { logger.error(error, "Error while deleting users flagged as deleted from database"); }
});