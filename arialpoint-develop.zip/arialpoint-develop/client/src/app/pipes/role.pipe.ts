import { Pipe, PipeTransform } from '@angular/core';

export const roles = {
  admin: 'Halkin Employee Admin',
  root: 'Root Admin',
  moderator: 'Managerial User',
  user: 'Executive Viewer',
};

@Pipe({
  name: 'role'
})
export class RolePipe implements PipeTransform {

  transform(role: string): string {
    return roles[role] || '';
  }

}
