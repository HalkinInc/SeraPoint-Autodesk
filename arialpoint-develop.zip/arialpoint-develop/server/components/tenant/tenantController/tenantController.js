module.exports = {
    getTenant: require("./getTenant"),
    getTenantById: require("./getTenantById"),
    patchTenantById: require("./patchTenantById"),
    deleteTenantById: require("./deleteTenantById")
};