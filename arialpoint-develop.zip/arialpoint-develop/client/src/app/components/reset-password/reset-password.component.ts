import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ResetPasswordFormGroup } from '../../models/reset-password-form.model';

export class ResetPassword {
    constructor(
        public password?: string,
        public confirmPassword?: string
    ) {}
}

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent {
    hide = true;
    constructForm: ResetPasswordFormGroup = new ResetPasswordFormGroup();
    user: ResetPassword;
    formSubmitted = false;

    constructor(private router: Router) {}

    onSubmit(form: NgForm) {
        this.formSubmitted = true;
        if (form.valid) {
            if (this.user.password === this.user.confirmPassword) {
                this.router.navigateByUrl('/dashboard');
            }
            this.user = new ResetPassword();
            form.reset();
            this.formSubmitted = false;
        }
    }
}

