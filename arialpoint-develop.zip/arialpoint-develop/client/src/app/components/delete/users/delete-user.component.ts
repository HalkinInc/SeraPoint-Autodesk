import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { UsersService } from '../../../services/users.service';
import { SettingsService } from '../../../services/settings.service';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html',
  styleUrls: ['./delete-user.component.scss']
})
export class DeleteUserComponent implements OnInit {
  deleteUsers: Array<User> = new Array();
  searchUser: string;
  tenantId: string;
  daysToDelete = 30;
  currentUserRole: string;

  constructor(
    private location: Location,
    private usersService: UsersService,
    private settingsService: SettingsService) { }

  ngOnInit() {
    this.getUser();
  }

  getUser() {
    this.usersService.getUser().subscribe((res) => {
      if (res.value.tenantId) {
        this.tenantId = res.value.tenantId;
      }
      this.currentUserRole = res.value.role;
      this.getSettings();
      this.getUsers(this.tenantId);
    });
  }

  getSettings() {
    this.settingsService.getSettings().subscribe((result) => {
      if (result.value) {
        this.daysToDelete = result.value.deletedUsersDaysLimit;
      }
    });
  }

  back() {
    this.location.back();
  }

  getUsers(search?: string) {
    this.usersService.getDeletedUsers()
      .subscribe((res: IResponseData) => {
        let result = res.value;
        result.map(element => {
          element['select'] = false;
        });
        if (search) {
          search = search.toLowerCase();
          result = result.filter((item) => {
            return item ? (item.firstname.toLowerCase().indexOf(search) >= 0 || item.lastname.toLowerCase().indexOf(search) >= 0) : false;
          });
        }
        this.deleteUsers = result;
      });
  }

  onRestoreSelect() {
    const selectedUsers = this.deleteUsers.filter((user) => {
      return user.select;
    });
    if (selectedUsers.length > 0) {
      selectedUsers.filter((element) => {
        this.usersService.editUser(element._id, { deleted: false }).subscribe((res) => {
          if (res.value) {
            this.getUsers();
          }
        });
      });
    }
  }

  onDeleteUser() {
    const selectedUsers = this.deleteUsers.filter((user) => {
      return user.select;
    });
    if (selectedUsers.length > 0) {
      selectedUsers.filter((selectUser) => {
        this.usersService.deleteUserForever(selectUser._id)
          .subscribe((res) => {
            this.getUsers();
          });
      });
    }
  }

  search(search: string) {
    this.getUsers(search);
  }

  changeDaysToDelete(days: number) {
    this.settingsService.updateSettings('deletedUsersDaysLimit', days).subscribe((res) => {
      this.getSettings();
    });
  }

  trackByFn(index, item) {
    return item.id;
  }
}

export class IResponseData {
  constructor(
    public errors: Array<string>,
    public value: Array<User>
  ) {}
}
