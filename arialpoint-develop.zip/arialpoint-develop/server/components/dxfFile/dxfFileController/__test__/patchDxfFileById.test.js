const assert = require("assert");

const request = require("supertest");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { dxfFiles, users } = require("./seeds");

it("error if provided dxf file id is invalid", async () => {
    const { body: { errors, value } } = await request(server)
        .patch("/dxf-file/12345")
        .set("authorization", users[0].jwt)
        .send({ fileName: "newName" });

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'params/id' should be valid 'objectId'");

    assert.strictEqual(value, undefined);
});

it("error if dxf file with provided id not exists", async () => {
    const { body: { errors, value } } = await request(server)
        .patch(`/dxf-file/${ObjectId().toString()}`)
        .set("authorization", users[0].jwt)
        .send({ fileName: "newName" });

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Dxf file not found");

    assert.strictEqual(value, undefined);
});

it("user without permission can't update dxf file", async () => {
    const { body: { errors, value } } = await request(server)
        .patch(`/dxf-file/${dxfFiles[0]._id.toString()}`)
        .set("authorization", users[1].jwt)
        .send({ fileName: "newName" });

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("dxf-file:update:any can update dxf file", async () => {
    const { body: { errors, value } } = await request(server)
        .patch(`/dxf-file/${dxfFiles[0]._id.toString()}`)
        .set("authorization", users[0].jwt)
        .send({ fileName: "newName" });

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});

it("should unflag deleted dxf file as deleted", async () => {
    const { body: { errors, value } } = await request(server)
        .patch(`/dxf-file/${dxfFiles[2]._id.toString()}`)
        .set("Authorization", users[0].jwt)
        .send({ deleted: false });

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});