import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AnotationsService {

  constructor(private http: HttpClient) { }

  getAnnotation(dxfFileId) {
    return this.http.get(`/api/anotation?dxfFileId=${dxfFileId}`)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  createAnnotation(text, dxfFileId, name, file, blockIndex, screenshot) {
    const formData = new FormData();
    formData.append('name', `${name}`);
    formData.append('dxfFileId', `${dxfFileId}`);
    formData.append('text', `${text}`);
    formData.append('blockIndex', blockIndex);
    if (typeof file !== 'undefined') {
      formData.append('file', file[0], file[0].filename);
    }
    formData.append('screenshot', screenshot);
    return this.http.post('/api/anotation', formData)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  getAnnotationFiles(tenantId) {
    let url = '/api/anotation';
    if (tenantId) {
      url += `?tenantId=${tenantId}`;
    }
    return this.http.get(url)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  deleteAnnotation(id) {
    return this.http.delete(`/api/anotation/${id}`)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  downloadAnotation(id) {
    return this.http.get(`/api/anotation/${id}`)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  getScreenshot(id) {
    return this.http.get(`/api/anotation/${id}/screenshot`)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  updateAnnotation(anotation, file: FormData, screenshot) {
    const formData = new FormData();
    formData.append('name', `${anotation.name}`);
    formData.append('text', `${anotation.text}`);
    if (typeof file !== 'undefined') {
      formData.append('file', file[0], file[0].filename);
    }
    if (typeof screenshot !== 'undefined') {
      formData.append('screenshot', screenshot, screenshot.name);
    }
    return this.http.patch(`/api/anotation/${anotation._id}`, formData)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  getDeleteAnnotations(tenantId) {
    let url = '/api/anotation?deleted=true';
    if (tenantId) {
      url = `/api/anotation?tenantId=${tenantId}&deleted=true`;
    }
    return this.http.get(url)
      .pipe(
        tap((res: any) => {
          return res;
        }));
  }

  editAnnotation(id, data) {
    const formData = new FormData();
    formData.append('deleted', `${data.deleted}`);
    return this.http.patch(`/api/anotation/${id}`, formData)
      .pipe(tap((res: any) => {
        return res;
      }));
  }
}
