const request = require("supertest");
const expect = require("expect");
const { ObjectId } = require("mongodb");

const { server } = require("../../../../server");
const { users } = require("./seeds");

it("error if provided user id is not valid", async () => {
    const { body: { value, errors } } = await request(server)
        .get("/user/1234567890/avatar")
        .set("Authorization", users[0].jwt);

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'params/id' should be valid 'objectId'");

    expect(value).not.toBeDefined();
});

it("error if user doesn't exist", async () => {
    const { body: { value, errors } } = await request(server)
        .get(`/user/${ObjectId().toString()}/avatar`)
        .set("Authorization", users[0].jwt);

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("User not found");

    expect(value).not.toBeDefined();
});

it("error if user was deleted", async () => {
    const { body: { value, errors } } = await request(server)
        .get(`/user/${users[2]._id.toString()}/avatar`)
        .set("Authorization", users[0].jwt);

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("User was deleted");

    expect(value).not.toBeDefined();
});

it("error if user has no avatar", async () => {
    const { body: { value, errors } } = await request(server)
        .get(`/user/${users[7]._id.toString()}/avatar`)
        .set("Authorization", users[0].jwt);

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("User has no avatar");

    expect(value).not.toBeDefined();
});

it("user:read:any can get any user avatar", async () => {
    const { body: { value, errors } } = await request(server)
        .get(`/user/${users[1]._id.toString()}/avatar`)
        .set("Authorization", users[0].jwt);

    expect(errors.length).toBe(0);

    expect(value).toBe("avatar.png");
});

it("user:read:tenant can get any user avatar", async () => {
    const { body: { value, errors } } = await request(server)
        .get(`/user/${users[0]._id.toString()}/avatar`)
        .set("Authorization", users[1].jwt);

    expect(errors.length).toBe(0);

    expect(value).toBe("avatar.png");
});