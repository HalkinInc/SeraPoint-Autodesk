import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private snackBar: MatSnackBar, private router: Router) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const idToken = localStorage.getItem('currentUser');
    if (idToken !== 'undefined' && idToken !== null) {
      const cloned = req.clone({
        headers: req.headers.set('Authorization', JSON.parse(idToken))
      });
      return next.handle(cloned).pipe(
        tap(() => this.dismiss()),
        catchError(this.handleError())
      );
    } else {
      return next.handle(req).pipe(
        tap(() => this.dismiss()),
        catchError(this.handleError())
      );
    }
  }

  private handleError() {
    return (error: HttpErrorResponse): Observable<any> => {
      if (error.error.errors[0] === 'Supplied token is invalid') {
        this.router.navigateByUrl('/login');
        localStorage.removeItem('currentUser');
        this.snackBar.open('Your JWT token old, please re-login', 'CLOSE');
        return;
      } else {
        this.snackBar.open(error.error.errors[0], 'CLOSE');
        return of(error);
      }
    };
  }

  private dismiss() {
    this.snackBar.dismiss();
  }
}
