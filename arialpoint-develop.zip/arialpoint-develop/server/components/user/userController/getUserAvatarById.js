const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");

const getUserAvatarById = async (req, res, next) => {
    try {
        const { params: { id } } = req;

        const avatar = await UserService.getUserAvatar(id);

        return res.send({ errors: [], value: avatar });

    } catch (error) { return next(error); }
};

const getUserByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true },
        }
    }
};

module.exports = [
    authorization(["user:read:any", "user:read:tenant", "user:read:own"]),
    requestValidation(getUserByIdSchema),
    getUserAvatarById
];