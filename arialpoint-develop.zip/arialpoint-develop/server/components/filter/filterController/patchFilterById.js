const FilterService = require("../filterService");
const requestValidation = require("../../../middleware/requestValidation");
const appErrors = require("../../../utils/appErrors");

const patchFilterById = async (req, res, next) => {
    try {
        const { authUser, params: { id }, body } = req;

        const foundFilter = await FilterService.getFilterById(id);
        if (foundFilter.creatorId !== authUser._id.toString()) throw new appErrors.AuthorizationError();

        await FilterService.updateFilter(id, body);

        res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const patchFilterByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string" },
        }
    },
    body: {
        type: "object",
        required: [],
        minProperties: 1,
        additionalProperties: false,
        properties: {
            title: { type: "string" },
            description: { type: "string" },
            users: { type: "array", items: { type: "string" } },
            date: { type: "string" }
        }
    }
};

module.exports = [
    requestValidation(patchFilterByIdSchema),
    patchFilterById
];