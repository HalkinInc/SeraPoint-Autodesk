const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");

const getSecretQuestion = async (req, res, next) => {
    try {
        const { query: { email } } = req;

        const foundUser = await UserService.getUserByEmail(email);

        return res.send({ errors: [], value: foundUser.secretQuestionId });
    } catch (error) { return next(error); }
};

const getSecretQuestionSchema = {
    query: {
        type: "object",
        required: ["email",],
        additionalProperties: false,
        properties: {
            email: { type: "string" },
        }
    }
};

module.exports = [
    requestValidation(getSecretQuestionSchema),
    getSecretQuestion
];