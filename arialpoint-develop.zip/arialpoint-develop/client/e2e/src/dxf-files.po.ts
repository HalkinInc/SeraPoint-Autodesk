import { browser, by, element, ExpectedConditions as EC } from 'protractor';
import { LoginPage } from './login.po';

export enum Filter { newest = 'Sort By: Newest', oldest = 'Sort By: Oldest', name = 'Sort By: Name', size = 'Sort By: Size' }

export class DxfFilesPage {
    spinnerEL = element(by.css('div.spinner-block'));
    filenameInput = element(by.name('filename'));
    filter = element(by.name('filter'));
    filterBtn = element(by.className('filter-btn'));
    filterOption = (filterKey: Filter) => element(by.name(filterKey));

    navigateToAs = (email: string, password: string) => {
        const loginPage = new LoginPage();
        loginPage.navigateTo();
        loginPage.enterCredentials(email, password);
        element(by.name('Files-button')).click();
        element(by.name('DXF Files-button')).click();
    }

    navigateToAsRoot = () => this.navigateToAs('pm@code-care.pro', 'password');
    navigateToAsAdmin = () => this.navigateToAs('andrii@code-care.pro', 'password');
    navigateToAsModerator = () => this.navigateToAs('alex.semenec@code-care.pro', 'password');
    navigateToAsUser = () => this.navigateToAs('kate@legacybeta.com', 'password');

    clickPreview = () => element(by.className('preview-btn')).click();
    isSpinnerVisible = () => this.spinnerEL.isPresent();
    waitForViewer = () => browser.wait(EC.stalenessOf(this.spinnerEL));

    clickUpdate = () => element(by.className('update-btn')).click();
    enterFilename = (filename: string) => {
        this.filenameInput.clear();
        this.filenameInput.sendKeys(filename);
    }
    clickSave = () => element(by.buttonText('Save')).click();
    isFilePresent = (filename: string) => element(by.cssContainingText('h4', filename)).isPresent();

    clickDelete = () => element(by.className('delete-btn')).click();

    checkFilterDefaultOption = (cls) => element(by.css(`.${cls}`)).getText();

    checkFilterByOldest = () => {
        element(by.name('oldest')).click();
        return element.all(by.id('dxf-list')).all(by.className('dxf-date')).first().getText();
    }

    checkFilterByName = () => {
        element(by.name('name')).click();
        return element.all(by.id('dxf-list')).all(by.css('h4.mat-line')).first().getText();
    }

    checkFilterBySize = () => {
        element(by.name('size')).click();
        return element.all(by.id('dxf-list')).all(by.css('h4.mat-line')).first().getText();
    }

    filterCardIsVisible = () =>  element(by.className('example-card')).isPresent();
}
