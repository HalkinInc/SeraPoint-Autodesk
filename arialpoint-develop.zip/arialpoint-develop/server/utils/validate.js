const Ajv = require("ajv");
const { ObjectId } = require("mongodb");

const ajv = new Ajv({ useDefaults: true, jsonPointers: true });

const validateObjectId = (schema, data) => {
    validateObjectId.errors = [];
    if (schema) {
        if (!ObjectId.isValid(data)) {
            validateObjectId.errors.push({ message: "should be valid 'objectId'", keyword: "objectId", params: {} });
            return false;
        }
        return true;
    }
    return true;
};

ajv.addKeyword("objectId", {
    validate: validateObjectId,
    errors: true
});

module.exports = (jsonSchema, object) => {
    ajv.validate(jsonSchema, object);

    if (ajv.errors !== null) {
        const error = ajv.errors[0];

        const formatError = (error) => {
            const { dataPath, message, params, keyword } = error;

            const beginning = dataPath !== "" ? `'${dataPath.slice(1)}' ` : "";

            const errorMessages = {
                "additionalProperties": `${beginning}should NOT have additional property '${params.additionalProperty}'`,
                "enum": `${beginning}should be equal to one of the allowed values '${params.allowedValues}'`,
                "default": `${beginning}${message}`
            };

            return errorMessages.hasOwnProperty(keyword) ?
                errorMessages[keyword] :
                errorMessages["default"];
        };

        return formatError(error);
    }

    return null;
};