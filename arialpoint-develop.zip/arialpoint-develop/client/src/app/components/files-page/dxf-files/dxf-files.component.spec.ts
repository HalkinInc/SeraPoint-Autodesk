import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DxfFilesComponent } from './dxf-files.component';

describe('DxfFilesComponent', () => {
  let component: DxfFilesComponent;
  let fixture: ComponentFixture<DxfFilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DxfFilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DxfFilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
