import { TestBed } from '@angular/core/testing';

import { AutodeskService } from './autodesk.service';

describe('AutodeskService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AutodeskService = TestBed.get(AutodeskService);
    expect(service).toBeTruthy();
  });
});
