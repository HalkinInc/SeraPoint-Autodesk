const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");

const getUserByJwt = async (req, res, next) => {
    try {
        const { body: { jwt } } = req;

        const foundUser = await UserService.getUserByJwt(jwt);

        return res.send({ errors: [], value: foundUser });
    } catch (error) { return next(error); }
};

const getUserByJwtSchema = {
    body: {
        type: "object",
        required: ["jwt"],
        additionalProperties: false,
        properties: {
            jwt: { type: "string" },
        }
    }
};

module.exports = [
    requestValidation(getUserByJwtSchema),
    getUserByJwt
];