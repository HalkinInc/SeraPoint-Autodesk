import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UsersService } from '../../../services/users.service';
import { DXFFilesService } from '../../../services/dxffiles.service';
import { User } from '../../../models/user.model';
import { DXFFile } from '../../../models/dxf.model';
import { MatDialog } from '@angular/material';
import { FileUploadDialogComponent } from '../file-upload-dialog/file-upload-dialog.component';
import { UpdateDxfDialogComponent } from '../update-dxf-dialog/update-dxf-dialog.component';

@Component({
  selector: 'app-dxf-files',
  templateUrl: './dxf-files.component.html',
  styleUrls: ['./dxf-files.component.scss']
})
export class DxfFilesComponent {
  currentUser: User = new User();
  dxfFiles: Array<DXFFile> = new Array();
  filteredDxfFiles: Array<DXFFile> = new Array();
  dxfSort = 'newest';
  dialogRef = true;
  activeFilters = false;
  allUsers: Array<User> = new Array();

  constructor(
    public dialog: MatDialog,
    private router: Router,
    private usersService: UsersService,
    private dxfFilesService: DXFFilesService) {
      this.getUser();
    }

  getUser() {
    this.usersService.getUser().subscribe((res) => {
      this.currentUser = res.value;
      this.getUsers();
      this.getDXFFiles();
    });
  }

  getDXFFiles() {
    this.dxfFilesService.getDXFFiles(this.currentUser.tenantId).subscribe((res) => {
      if (res && res.value) {
        this.dxfFiles = res.value.sort((a, b) => {
          return <number>b.createdAt - <number>a.createdAt;
        });
        this.filteredDxfFiles = this.dxfFiles;
      }
    });
  }

  get changeDxfList() {
    switch (this.dxfSort) {
      case 'newest':
        return this.filteredDxfFiles = this.dxfFiles.sort((a, b) => {
          return <number>b.createdAt - <number>a.createdAt;
        });
      case 'oldest':
        return this.filteredDxfFiles = this.dxfFiles.sort((a, b) => {
          return <number>a.createdAt - <number>b.createdAt;
        });
      case 'name':
        return this.filteredDxfFiles = this.dxfFiles.sort((a, b) => {
          const nameA = a.fileName.toLowerCase();
          const nameB = b.fileName.toLowerCase();
          if (nameA < nameB) {
            return -1;
          } else if (nameA > nameB) {
            return 1;
          } else {
            return 0;
          }
        });
      case 'size':
        return this.filteredDxfFiles = this.dxfFiles.sort((a, b) => {
          return <number>b.fileSize - <number>a.fileSize;
        });
    }
  }

  previewDXF(id: string, annotationId: string = 'pure-dxf') {
    this.router.navigateByUrl(`/view-page/${id}/${annotationId}`);
  }

  deleteDXF(id) {
    this.dxfFilesService.deleteDXFFile(id).subscribe((res) => {
      this.getDXFFiles();
    });
  }

  openFileUploadDialog() {
    const dialogRef = this.dialog.open(FileUploadDialogComponent, {
      width: '500px',
      disableClose: false
    });

    dialogRef.afterClosed().subscribe((result: FormData) => {
      if (typeof result !== 'undefined') {
        this.dxfFilesService.uploadDXFFile(this.currentUser, result).subscribe((res) => {
          console.log(res);
        });
        this.dialogRef = null;
      }
    });
  }

  onUpdateDxf(dxf) {
    const updateDialogRef = this.dialog.open(UpdateDxfDialogComponent, {
      width: '500px',
      data: dxf
    });

    updateDialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.dxfFilesService.updateDXFFile(result._id, result.fileName).subscribe((res) => {
          if (res.value) {
            this.getDXFFiles();
          }
        });
        this.dialogRef = null;
      }
    });
  }

  getUsers() {
    let id = '';
    if (this.currentUser.role !== 'root' && this.currentUser.role !== 'admin') {
      id = this.currentUser.tenantId;
    }
    return this.usersService.getUsers(id)
      .subscribe((res) => {
        const result = res['value'];
        result.forEach(element => {
          if (!element.tenant) {
            element.tenant = {
              name: ''
            };
          }
          element['editable'] = false;
        });
        this.allUsers = result;
      });
  }

  onChanged(event) {
    let filteredList;
    if (event.users.length > 0) {
      event.users.filter((user) => {
        filteredList = this.dxfFiles.filter((item) => {
          if (`${(item.creatorFirstname).toLowerCase()} ${(item.creatorLastname).toLowerCase()}` === user) {
            return item;
          }
        });
      });
      if (filteredList[0] === undefined) {
        filteredList = [];
      }
    } else {
      filteredList = this.dxfFiles;
    }
    const now = new Date();
    const dd = now.getDate();
    const mm = now.getMonth();
    const yyyy = now.getFullYear();
    const today = new Date(yyyy, mm, dd, 0, 0, 0);
    const todayUTC = today.getTime();
    const yesterday = new Date(yyyy, mm, dd - 1, 0, 0, 0);
    const thisMonth = new Date(yyyy, mm, 1, 0, 0, 0);
    const lastMonth = new Date(yyyy, mm - 1, 1, 0, 0, 0);
    const last3Month = new Date(yyyy, mm - 3, 1, 0, 0, 0);
    switch (event.date) {
      case 'anytime':
        this.filteredDxfFiles = filteredList;
        break;
      case 'yesterday':
        this.filteredDxfFiles = filteredList.filter((item) => {
          if (item.createdAt < todayUTC && item.createdAt > yesterday.getTime()) {
            return item;
          }
          return;
        });
        break;
      case 'today':
        this.filteredDxfFiles = filteredList.filter((item) => {
          if (item.createdAt > todayUTC) {
            return item;
          }
          return;
        });
        break;
      case 'thisWeek':
        this.filteredDxfFiles = filteredList.filter((item) => {
          if (item.createdAt > today.setDate(today.getDate() - (today.getDay() + 6) % 7)) {
            return item;
          }
          return;
        });
        break;
      case 'lastWeek':
        this.filteredDxfFiles = filteredList.filter((item) => {
          if (item.createdAt > today.setDate(today.getDate() - (today.getDay() + 6) % 14)) {
            return item;
          }
          return;
        });
        break;
      case 'thisMonth':
        this.filteredDxfFiles = filteredList.filter((item) => {
          if (item.createdAt > thisMonth.getTime()) {
            return item;
          }
          return;
        });
        break;
      case 'lastMonth':
        this.filteredDxfFiles = filteredList.filter((item) => {
          if (item.createdAt > lastMonth.getTime()) {
            return item;
          }
          return;
        });
        break;
      case 'last3Month':
        this.filteredDxfFiles = filteredList.filter((item) => {
          if (item.createdAt > last3Month.getTime()) {
            return item;
          }
          return;
        });
        break;
    }
  }

  trackByFn(index, item) {
    return item.id;
  }
}
