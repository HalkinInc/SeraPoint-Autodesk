const assert = require("assert");

const request = require("supertest");

const { server, db } = require("../../../../server");
const { users, tenants } = require("./seeds");

it("user without permission can't create another user", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[3].jwt)
        .send({ email: "newUser@email.com", message: "message" });

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("non admin:create:any can't create admin", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[1].jwt)
        .send({ firstname: "newUserFirtname", lastname: "newUserLastname", email: "newUser@rmail.com", role: "admin", message: "message" });

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("non moderator:create:any can't create moderator", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[1].jwt)
        .send({ firstname: "newUserFirtname", lastname: "newUserLastname", email: "newUser@rmail.com", role: "moderator", tenantName: "newUserTenant", message: "message" });

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("moderator:create:any can create another moderator for tenant", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[0].jwt)
        .send({ firstname: "newModeratorFirtname", lastname: "newModeratorLastname", email: "newModerator@rmail.com", role: "moderator", tenantName: tenants[0].name, message: "message" });

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});

it("can't create user if tenant with provided name does't exist", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[0].jwt)
        .send({ firstname: "newUserFirtname", lastname: "newUserLastname", email: "newUser@rmail.com", role: "user", tenantName: "strangeNameForTenant", message: "message" });

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Tenant not found");

    assert.strictEqual(value, undefined);
});

it("user:create:tenant can't create user for not his tenant", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[1].jwt)
        .send({ firstname: "newUserFirtname", lastname: "newUserLastname", email: "newUser@rmail.com", role: "user", tenantName: tenants[1].name, message: "message" });

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Permission denied");

    assert.strictEqual(value, undefined);
});

it("can't create moderator if tenant name is not provided", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[0].jwt)
        .send({ firstname: "newModerator", lastname: "newModerator", email: "newModerator@rmail.com", role: "moderator", message: "message" });

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'body' should have required property 'tenantName'");

    assert.strictEqual(value, undefined);
});

it("can't create user if tenant name is not provided", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[0].jwt)
        .send({ firstname: "newUser", lastname: "newUser", email: "newUser@email.com", role: "user", message: "message" });

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'body' should have required property 'tenantName'");

    assert.strictEqual(value, undefined);
});

it("admin:create:any can create admin without tenant", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[0].jwt)
        .send({ firstname: "newAdmin", lastname: "newAdmin", email: "newAdmin@rmail.com", role: "admin", message: "message" });

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});

it("moderator:create:any can create moderator with tenant", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[0].jwt)
        .send({ firstname: "newModerator", lastname: "newModerator", email: "newModerator@rmail.com", role: "moderator", tenantName: "newModeratorTenant", message: "message" });

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);

    const tenantCollection = await (await db).collection("tenants");
    const foundTenant = await tenantCollection.findOne({ name: "newModeratorTenant" });

    assert.notStrictEqual(foundTenant, null);
});

it("user:create:any can create user", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[0].jwt)
        .send({ firstname: "newUser", lastname: "newUser", email: "newUser@email.com", role: "user", tenantName: tenants[0].name, message: "message" });

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});

it("user:create:tenant can create user of his tenant", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user")
        .set("Authorization", users[1].jwt)
        .send({ firstname: "newUser", lastname: "newUser", email: "newUser@email.com", role: "user", tenantName: tenants[0].name, message: "message" });

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);
});