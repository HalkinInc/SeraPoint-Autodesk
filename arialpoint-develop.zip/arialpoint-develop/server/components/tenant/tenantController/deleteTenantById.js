const AnotationService = require("../../anotation/anotationService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const TenantService = require("../tenantService");
const UserService = require("../../user/userService");
const DxfFileService = require("../../dxfFile/dxfFileService");

const deleteTenantById = async (req, res, next) => {
    try {
        const { params: { id }, query: { method } } = req;

        if(method === "hard"){
            await TenantService.getDeletedTenantById(id);

            await TenantService.hardDeleteTenantById(id);
            await UserService.hardDeletedAllTenantUsers(id);
        } else {
            await TenantService.getTenantById(id);
    
            await UserService.flagAsDeletedAllTenantUsers(id);
            const founDxfFiles = await DxfFileService.getTenantDxfFiles(id);
            await DxfFileService.flagTenantDxfFilesAsDeleted(id);
            await Promise.all(founDxfFiles.map((dxfFile) => AnotationService.flagDxfFileAnotationsAsDeleted(dxfFile._id)));
    
            await TenantService.flagTenantAsDeleted(id);
        };

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const deleteTenantByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true },
        }
    },
    query: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            method: { type: "string" }
        }
    }
};

module.exports = [
    authorization(["tenant:delete:any"]),
    requestValidation(deleteTenantByIdSchema),
    deleteTenantById
];