const { Router } = require("express");

const authentication = require("../../middleware/authentication");
const anotationController = require("./anotationController/anotationController");

const anotationRouter = new Router();

anotationRouter.use(authentication());

anotationRouter.post("/anotation", anotationController.postAnotation);
anotationRouter.get("/anotation", anotationController.getAnotation);
anotationRouter.get("/anotation/:id", anotationController.getAnotationById);
anotationRouter.get("/anotation/:id/screenshot", anotationController.getAnotationByIdScreenshot);
anotationRouter.patch("/anotation/:id", anotationController.patchAnotationById);
anotationRouter.delete("/anotation/:id", anotationController.deleteAnotationById);

module.exports = anotationRouter;
