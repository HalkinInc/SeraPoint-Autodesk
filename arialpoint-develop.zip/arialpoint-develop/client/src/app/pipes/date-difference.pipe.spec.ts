import { DateDifferencePipe } from './date-difference.pipe';

describe('DateDifferencePipe', () => {
  it('create an instance', () => {
    const pipe = new DateDifferencePipe();
    expect(pipe).toBeTruthy();
  });
});
