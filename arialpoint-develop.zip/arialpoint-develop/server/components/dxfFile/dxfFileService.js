const path = require("path");

const DxfFileModel = require("./dxfFileModel");
const { Long, ObjectId } = require("mongodb");
const AWS = require("aws-sdk");
const config = require("config");
const Base64 = require("js-base64").Base64;
const axios = require("axios");
const uuidv4 = require("uuid");
const validate = require("../../utils/validate");
const appErrors = require("../../utils/appErrors");

const s3 = new AWS.S3({
    params: { Bucket: "serapoint-dxf" },
    credentials: { accessKeyId: config.aws.accessKey, secretAccessKey: config.aws.secretAccessKey }
});

const authenticateToAutodesk = async () => {
    const { data: { access_token } } = await axios.post(
        "https://developer.api.autodesk.com/authentication/v1/authenticate",
        `client_id=${config.forge.clientId}&client_secret=${config.forge.clientSecret}&grant_type=client_credentials&scope=${["data:read", "data:write", "data:create", "data:search", "bucket:create", "bucket:read", "bucket:update", "bucket:delete"].join(" ")}`,
        { headers: { "Content-Type": "application/x-www-form-urlencoded" } });

    return access_token;
};

const uploadDxfFile = async (file) => {
    if (process.env.NODE_ENV === "test") return { urn: "test urn", fileKey: "test fileKey" };

    const fileKey = uuidv4() + path.extname(file.name);

    const token = await authenticateToAutodesk();

    const uploadFileToAutodeskAndS3 = async () => {
            const [{ data: { objectId } }] = await Promise.all([
                axios.put(
                    `https://developer.api.autodesk.com/oss/v2/buckets/${config.forge.bucketKey}/objects/${fileKey}`
                    , file.read(),
                    { headers: { "Authorization": `Bearer ${token}` }, maxContentLength: 50000000 }),
                s3.upload({ Key: fileKey, Body: file.read() }).promise()
            ]);
    
            return objectId;
    };

    const objectId = await uploadFileToAutodeskAndS3();
    const base64Urn = Base64.encode(objectId);

    const createFileConvertionJob = async () => {
        return await axios.post(
            "https://developer.api.autodesk.com/modelderivative/v2/designdata/job",
            JSON.stringify({ input: { urn: base64Urn }, output: { formats: [{ type: "SVF", views: ["3d"] }] } }),
            { headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json", "x-ads-force": "true" } });
    };

    await createFileConvertionJob();

    const sleep = (ms) => {
        return new Promise((resolve) => setTimeout(resolve, ms));
    };

    const waitForJobEnd = async () => {
        const manifestResponse = await axios.get(
            `https://developer.api.autodesk.com/modelderivative/v2/designdata/${base64Urn}/manifest`,
            { headers: { "Authorization": `Bearer ${token}` } });

        if (manifestResponse.data.status === "failed") return [manifestResponse.data.status];

        if (manifestResponse.data.status === "success") {
            const role3d = manifestResponse.data.derivatives[0].children.find((child) => child.role === "3d");

            if (role3d === undefined) return [manifestResponse.data.status, undefined];

            const { urn } = role3d.children.find((child) => child.role === "graphics");

            return [manifestResponse.data.status, urn];
        }

        await sleep(1000);

        return await waitForJobEnd();
    };

    const [jobStatus, urn] = await waitForJobEnd();

    const deleteFileFormAutodesk = async () => {
        return await axios.delete(
            `https://developer.api.autodesk.com/oss/v2/buckets/${config.forge.bucketKey}/objects/${fileKey}`,
            { headers: { "Authorization": `Bearer ${token}` } });
    };

    if (jobStatus === "failed") {
        await deleteFileFormAutodesk();
        throw new appErrors.ServerError("Failed to convert file");
    }

    if (urn === undefined) throw new appErrors.RequestError("File doesn't have 3d graphics");

    return { urn, fileKey };
};

const deleteFileFromS3AndAutodesk = async (fileKey) => {
    const token = await authenticateToAutodesk();

    await Promise.all([
        s3.deleteObject({ Key: fileKey }).promise(),
        axios.delete(
            `https://developer.api.autodesk.com/oss/v2/buckets/${config.forge.bucketKey}/objects/${fileKey}`,
            { headers: { "Authorization": `Bearer ${token}` } })
    ]);
};

const createDxfFileSchema = {
    type: "object",
    required: ["urn", "creatorId", "tenantId", "fileName", "fileSize", "createdAt", "deleted"],
    additionalProperties: false,
    properties: {
        // required
        urn: { type: "string" },
        creatorId: { type: "string" },
        tenantId: { type: "string" },
        fileName: { type: "string", minLength: 3, maxLength: 100 },
        fileKey: { type: "string", minLength: 3, maxLength: 100 },
        fileSize: { type: "integer" },
        createdAt: { type: "integer" },
        deleted: { type: "boolean", default: false },
    }
};
const createDxfFile = async (dxfFile) => {
    dxfFile.createdAt = Date.now();

    const validationError = validate(createDxfFileSchema, dxfFile);
    if (validationError !== null) throw new appErrors.RequestError(validationError);

    dxfFile.createdAt = Long.fromNumber(dxfFile.createdAt);

    await DxfFileModel.insertOne(dxfFile);
};

const getDxfFileById = async (id) => {
    const foundDxfFile = await DxfFileModel.findAndEnrichOne({ _id: ObjectId(id) });
    if (foundDxfFile === null) throw new appErrors.NotFoundError("Dxf file not found");
    if (foundDxfFile.deleted) throw new appErrors.NotFoundError("Dxf file was deleted");

    return foundDxfFile;
};

const getDeletedDxfFileById = async (id) => {
    const foundDxfFile = await DxfFileModel.findAndEnrichOne({ _id: ObjectId(id) });
    if (foundDxfFile === null) throw new appErrors.NotFoundError("Dxf file not found");
    if (!foundDxfFile.deleted) throw new appErrors.RequestError("Dxf file is not deleted");

    return foundDxfFile;
};

const getAllDxfFiles = async (deleted = false) => {
    return await DxfFileModel.findAndEnrichMany({ deleted });
};

const getTenantDxfFiles = async (tenantId, deleted = false) => {
    return await DxfFileModel.findAndEnrichMany({ tenantId, deleted });
};

const flagDxfFileAsDeleted = async (id) => {
    await getDxfFileById(id);
    await DxfFileModel.updateOne({ _id: ObjectId(id) }, { $set: { deleted: true, deletedAt: Long.fromNumber(Date.now()) } });
};

const unflagDxfFileAsDeleted = async (id) => {
    await getDeletedDxfFileById(id);
    await DxfFileModel.updateOne({ _id: ObjectId(id) }, { $set: { deleted: false }, $unset: { deletedAt: "" } });
};

const flagTenantDxfFilesAsDeleted = async (tenantId) => {
    await DxfFileModel.updateMany({ tenantId }, { $set: { deleted: true } });
};

const renameDxfFile = async (id, fileName) => {
    await getDxfFileById(id);
    await DxfFileModel.updateOne({ _id: ObjectId(id) }, { $set: { fileName } });
};

module.exports = {
    createDxfFile,
    uploadDxfFile,
    deleteFileFromS3AndAutodesk,
    getDxfFileById,
    getAllDxfFiles,
    getTenantDxfFiles,
    flagDxfFileAsDeleted,
    flagTenantDxfFilesAsDeleted,
    unflagDxfFileAsDeleted,
    renameDxfFile,
    ...DxfFileModel
};