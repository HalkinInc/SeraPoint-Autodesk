const assert = require("assert");

const request = require("supertest");

const { server } = require("../../../../server");
const { users } = require("./seeds");

it("error if email is not provided", async () => {
    const { body: { errors, value } } = await request(server)
        .get("/user/secret-question");

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'query' should have required property 'email'");

    assert.strictEqual(value, undefined);
});

it("error if user not found", async () => {
    const { body: { errors, value } } = await request(server)
        .get("/user/secret-question?email=wrong");

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "User not found");

    assert.strictEqual(value, undefined);
});

it("return secret question id if user found", async () => {
    const { body: { errors, value } } = await request(server)
        .get(`/user/secret-question?email=${users[1].email}`);

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, 0);
});