import { by, element } from 'protractor';
import { LoginPage } from './login.po';

export enum Roles { admin = 'admin', moderator = 'moderator', user = 'user' }

export class InviteDialog {
    fnameInput = element(by.name('firstname'));
    lnameInput = element(by.name('lastname'));
    emailInput = element(by.name('email'));
    tenantInput = element(by.name('tenant'));
    rolesSelect = element(by.name('roles'));
    nextButton = element(by.name('next'));
    backButton = element(by.name('back'));
    closeButton = element(by.name('close'));
    messageTextarea = element(by.name('message'));
    sendInviteButton = element(by.name('send-invite-button'));
    openInviteDialog = () => element(by.id('open-invite-dialog')).click();
    roleOption = (role: Roles) => element(by.name(role));

    navigateToAsRoot = () => {
        const loginPage = new LoginPage();
        loginPage.navigateTo();
        loginPage.enterCredentials('pm@code-care.pro', 'password');
        this.openInviteDialog();
    }

    navigateToAsAdmin = () => {
        const loginPage = new LoginPage();
        loginPage.navigateTo();
        loginPage.enterCredentials('andrii@code-care.pro', 'password');
        this.openInviteDialog();
    }

    navigateToAsModerator = () => {
        const loginPage = new LoginPage();
        loginPage.navigateTo();
        loginPage.enterCredentials('alex.semenec@code-care.pro', 'password');
        this.openInviteDialog();
    }

    addDetails = (fname: string, lname: string, email: string, tenant: string | null, role: Roles) => {
        this.fnameInput.sendKeys(fname);
        this.lnameInput.sendKeys(lname);
        this.emailInput.sendKeys(email);
        if (tenant !== null) {
            this.tenantInput.clear();
            this.tenantInput.sendKeys(tenant);
        }
        this.rolesSelect.click();
        this.roleOption(role).click();
    }

    navigateToSendInviteStep = () => this.nextButton.click();
    navigateToAddInvitesStep = () => this.backButton.click();
    closeInviteModal = () => () => this.closeButton.click();

    isSendInviteStep = () => this.messageTextarea.isPresent();
    isAddDetailsStep = () => this.fnameInput.isPresent();

    getTenantInputValue = () => this.tenantInput.getAttribute('value');

    enterMessage = (message: string) => this.messageTextarea.sendKeys(message);

    sendInvite = () => this.sendInviteButton.click();

    isUserExists = async (fname: string, lname: string) => {
        const fnameSpan = element(by.cssContainingText('span', fname));
        const lnameSpan = element(by.cssContainingText('span', lname));
        return await fnameSpan.isPresent() && await lnameSpan.isPresent();
    }

    editTenantField = (tenant: string) => {
        if (tenant !== null) {
            this.tenantInput.clear();
            this.tenantInput.sendKeys(tenant);
        }
    }

    editEmailField = (email: string) => {
        this.emailInput.sendKeys(email);
    }

    isTenantEdit = async (tenant: string) => {
        const tenantSpan = element(by.cssContainingText('span', tenant));
        return await tenantSpan.isPresent();
    }

    getFirstnameErrorValue = () => element(by.id('firstname-error')).getText();
    getLastnameErrorValue = () => element(by.id('lastname-error')).getText();
    getEmailErrorValue = () => element(by.id('email-error')).getText();
    getTenantErrorValue = () => element(by.id('tenant-error')).getText();
    isRoleOptionVisible = () => element.all(by.css('.mat-option')).isPresent();
    inviteDialog = () => element(by.id('mat-dialog-1')).isPresent();
}
