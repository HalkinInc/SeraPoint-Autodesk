const createModel = require("../../db/createModel");

const FilterModel = createModel("filters");

module.exports = FilterModel;