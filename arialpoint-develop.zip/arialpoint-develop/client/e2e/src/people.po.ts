import { by, element } from 'protractor';
import { LoginPage } from './login.po';

export class PeoplePage {
    private snackbarElement = element.all(by.css('.mat-simple-snackbar span')).first();

    private getElement = (email: string, buttonName: string) => element(by.name(email + '-' + buttonName));
    private getEditButton = (email: string) => this.getElement(email, 'Edit');
    private getDeleteButton = (email: string) => this.getElement(email, 'Delete');
    private getSaveButton = (email: string) => this.getElement(email, 'Save');

    private getFirstnameInput = (email: string) => this.getElement(email, 'FirstnameInput');
    private getFirstnameSpan = (email: string) => this.getElement(email, 'Firstname');


    private navigateToAs = (email: string, password: string) => {
        const loginPage = new LoginPage();
        loginPage.navigateTo();
        loginPage.enterCredentials(email, password);
        element(by.name('People-button')).click();
    }

    navigateToAsRoot = () => this.navigateToAs('pm@code-care.pro', 'password');
    navigateToAsAdmin = () => this.navigateToAs('andrii@code-care.pro', 'password');
    navigateToAsModerator = () => this.navigateToAs('alex.semenec@code-care.pro', 'password');
    navigateToAsUser = () => this.navigateToAs('kate@legacybeta.com', 'password');

    clickEdit = (email: string) => this.getEditButton(email).click();
    enterFirstname = (email: string, fname: string) => {
        const fnameInput = this.getFirstnameInput(email);
        fnameInput.clear();
        fnameInput.sendKeys(fname);
    }
    clickSave = (email: string) => this.getSaveButton(email).click();
    getFitstname = (email: string) => this.getFirstnameSpan(email).getText();

    clickDeleted = (email: string) => this.getDeleteButton(email).click();
    doesUserExist = (email: string) => this.getEditButton(email).isPresent();

    getErrorMessage = () => this.snackbarElement.getText();
}
