import { FormControl, FormGroup, Validators } from '@angular/forms';

export class EditProfileFormControl extends FormControl {
  label: string;
  modelProperty: string;

  constructor(label: string, property: string, value: any, validator: any) {
    super(value, validator);
    this.label = label;
    this.modelProperty = property;
  }

  getValidationMessages(): Array<string> {
    const messages: string[] = [];
    if (this.errors) {
      for (const errorName in this.errors) {
        if (errorName === 'required') {
          messages.push(`You must enter a ${this.label}`);
        } else if (errorName === 'minlength') {
          messages.push(`A ${this.label} must be at least ${this.errors['minlength'].requiredLength} characters`);
        } else if (errorName === 'maxlength') {
          messages.push(`A ${this.label} must be no more than ${this.errors['maxlength'].requiredLength} characters`);
        } else if (errorName === 'pattern') {
          messages.push(`The ${this.label} contains illegal characters`);
        }
      }
    }
    return messages;
  }
}

export class EditProfileFormGroup extends FormGroup {
  constructor() {
    super({
      firstname: new EditProfileFormControl('Name', 'firstname', '', Validators.required),
      lastname: new EditProfileFormControl('Surname', 'lastname', '', Validators.required),
      email: new EditProfileFormControl('Email', 'email', '',
        Validators.compose([Validators.required, Validators.email])),
      address: new EditProfileFormControl('Address', 'address', '', Validators.required),
      phoneNumber: new EditProfileFormControl('Phone', 'phoneNumber', '', Validators.required),
      role: new EditProfileFormControl('Role', 'role', '', Validators.required),
      tenantName: new EditProfileFormControl('Tenant name', 'tenantName', '', ''),
      secretQuestionId: new EditProfileFormControl('Secret Question', 'secretQuestionId', '', ''),
      secretQuestionAnswer: new EditProfileFormControl('Answer', 'secretQuestionAnswer', '',
        Validators.compose([Validators.required, Validators.minLength(3)])),
      city: new EditProfileFormControl('City', 'city', '', ''),
    });
  }

  get editProfileControls(): EditProfileFormControl[] {
    return Object.keys(this.controls)
      .map(k => this.controls[k] as EditProfileFormControl);
  }

  getFormValidationMessages(form: any): string[] {
    const messages: string[] = [];
    this.editProfileControls.forEach(c => c.getValidationMessages()
        .forEach(m => messages.push(m)));
    return messages;
  }
}
