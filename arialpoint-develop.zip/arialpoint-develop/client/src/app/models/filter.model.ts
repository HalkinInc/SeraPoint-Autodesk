export class FilterData {
  constructor(
    public title?: string,
    public description?: string,
    public users?: Array<string>,
    public date?: string,
    public _id?: string
  ) {}
}
