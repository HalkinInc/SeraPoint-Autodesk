import { by, element, ElementFinder } from 'protractor';
import { LoginPage } from './login.po';

interface FormData {
    firstname: string;
    lastname: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    answer: string;
}

export class EditProfile {
    userMenuButton = element(by.name('user-menu'));
    editProfileButton = element(by.buttonText('Edit Profile'));
    updateButton = element(by.cssContainingText('span', 'Update'));
    closeButton = element(by.cssContainingText('span', 'Close'));

    firstnameInput = element(by.name('firstname-input'));
    lastnameInput = element(by.name('lastname-input'));
    emailInput = element(by.name('email-input'));
    phoneInput = element(by.name('phone-input'));
    addressInput = element(by.name('address-input'));
    cityInput = element(by.name('city-input'));
    answerInput = element(by.name('answer-input'));


    clearInputAndSendKeys = (input: ElementFinder, keys: string) => {
        input.clear();
        input.sendKeys(keys);
    }

    navigateToAsUser = () => {
        const loginPage = new LoginPage();
        loginPage.navigateTo();
        loginPage.enterCredentials('kate@legacybeta.com', 'password');
        this.userMenuButton.click();
        this.editProfileButton.click();
    }

    enterNewData = (data: FormData) => {
        this.clearInputAndSendKeys(this.firstnameInput, data.firstname);
        this.clearInputAndSendKeys(this.lastnameInput, data.lastname);
        this.clearInputAndSendKeys(this.emailInput, data.email);
        this.clearInputAndSendKeys(this.phoneInput, data.phone);
        this.clearInputAndSendKeys(this.addressInput, data.address);
        this.clearInputAndSendKeys(this.cityInput, data.city);
        this.clearInputAndSendKeys(this.answerInput, data.answer);
    }

    clickUpdateButton = () => this.updateButton.click();

    clickCloseButton = () => this.closeButton.click();
}
