const FilterService = require("../filterService");
const requestValidation = require("../../../middleware/requestValidation");
const appErrors = require("../../../utils/appErrors");

const deleteFilterById = async (req, res, next) => {
    try {
        const { authUser, params: { id } } = req;

        const foundFilter = await FilterService.getFilterById(id);
        if (foundFilter.creatorId !== authUser._id.toString()) throw new appErrors.AuthorizationError();

        await FilterService.deleteFilter(id);

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const deleteFilterByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true },
        }
    }
};

module.exports = [
    requestValidation(deleteFilterByIdSchema),
    deleteFilterById
];