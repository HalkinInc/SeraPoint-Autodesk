const authentication = require("../../../middleware/authentication");
const authorization = require("../../../middleware/authorization");
const requestValidation = require("../../../middleware/requestValidation");
const SettingsModel = require("../settingsModel");

const getSettings = async (req, res, next) => {
    try {
        return res.send({ errors: [], value: await SettingsModel.findOne({ name: "main" }) });
    } catch (error) { return next(error); }
};

module.exports = [
    authentication(),
    authorization(["settings:read"]),
    requestValidation(),
    getSettings
];