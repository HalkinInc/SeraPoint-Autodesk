const UserService = require("../userService");
const requestValidation = require("../../../middleware/requestValidation");

const sendSecretAnswer = async (req, res, next) => {
    try {
        const { body: { email, answer, password } } = req;

        password === undefined ? await UserService.checkIsAnswerCorrect(email, answer) : await UserService.setNewPassword(email, answer, password);

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const sendSecretAnswerSchema = {
    body: {
        type: "object",
        required: ["email", "answer"],
        additionalProperties: false,
        properties: {
            email: { type: "string" },
            answer: { type: "string" },
            password: { type: "string", minLength: 6 }
        }
    }
};

module.exports = [
    requestValidation(sendSecretAnswerSchema),
    sendSecretAnswer
];