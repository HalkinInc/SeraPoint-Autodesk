import { Extension } from 'ng2-adsk-forge-viewer';
import { Subject } from 'rxjs';
import { SELECTED_ANNOTATION_BLOCK, USER_ROLE } from './view-page.component';
import { untilDestroyed } from 'ngx-take-until-destroy';
import { OnDestroy } from '@angular/core';

declare const THREE: any;
export const SHOW_ANNOTATION_PANEL = new Subject();
export const SELECT_BLOCK = new Subject();
export const SCREENSHOT = new Subject();
export const SPINNER = new Subject();
export const PERCENTS = new Subject();

export class TestExtension extends Extension implements OnDestroy {
  public static extensionName = 'TestExtension';
  private subToolbar: Autodesk.Viewing.UI.ToolBar;
  private onToolbarCreatedBinded: any;
  model: any;
  dbIds: Array<string>;
  userRole: string;

  constructor(protected viewer: Autodesk.Viewing.Viewer3D, protected extOptions: Autodesk.Viewing.ExtensionOptions) {
    super(viewer, extOptions);
    this.removeNativeSpinner();
    SPINNER.next(true);
    this.model = extOptions;
    USER_ROLE.subscribe((res: string) => {
      this.userRole = res;
    });
  }

  public removeNativeSpinner() {
    const spinners = document.getElementsByClassName('spinner');
    if (spinners.length === 0) {
      return;
    }
    const spinner = spinners[0];
    spinner.classList.remove('spinner');
  }

  public load() {
    SELECTED_ANNOTATION_BLOCK.pipe(untilDestroyed(this)).subscribe((res) => {
      this.viewer.clearThemingColors('');
      this.viewer.setThemingColor(+res, new THREE.Vector4(0, 1, 1, 1));
    });

    this.selectionChanged();
    this.modelLayersLoaded();
    this.progressUpdate();
    if (this.viewer.toolbar) {
      this.createUI();
    } else {
      this.onToolbarCreatedBinded = this.onToolbarCreated.bind(this);
      this.viewer.addEventListener(Autodesk.Viewing.TOOLBAR_CREATED_EVENT, this.onToolbarCreatedBinded);
    }
    this.removeBtnsFromToolbar();
    return true;
  }

  public selectionChanged() {
    this.viewer.addEventListener(Autodesk.Viewing.SELECTION_CHANGED_EVENT, (e: Autodesk.Viewing.ViewerEvent) => {
      this.viewer.clearThemingColors('');
      this.viewer.getScreenShot(
        this.viewer.container.clientWidth,
        this.viewer.container.clientHeight,
        function() {
          const blobURL = arguments[0];
          SCREENSHOT.next(blobURL);
        }
      );

      SHOW_ANNOTATION_PANEL.next(true);

      const dbIdArray = (e as any).dbIdArray;
      if (dbIdArray.length) {
        const dbId = dbIdArray[0];
        const selectBlock = {
          id: dbId
        };
        SELECT_BLOCK.next(selectBlock);
        this.viewer.setThemingColor(dbId, new THREE.Vector4(0, 1, 1, 1));
      } else if (dbIdArray.length === 0) {
        SHOW_ANNOTATION_PANEL.next(false);
        SELECT_BLOCK.next(false);
      }
    });
  }

  public modelLayersLoaded() {
    this.viewer.addEventListener(Autodesk.Viewing.MODEL_LAYERS_LOADED_EVENT, (e: Autodesk.Viewing.ViewerEvent) => {
      SPINNER.next(false);
    });
  }

  public progressUpdate() {
    this.viewer.addEventListener(Autodesk.Viewing.PROGRESS_UPDATE_EVENT, (e) => {
      PERCENTS.next(e.percent);
    });
  }

  public onToolbarCreated() {
    this.viewer.removeEventListener(Autodesk.Viewing.TOOLBAR_CREATED_EVENT, this.onToolbarCreatedBinded);
    this.onToolbarCreatedBinded = null;
    this.createUI();
  }

  public unload() {
    this.viewer.toolbar.removeControl(this.subToolbar);
    return true;
  }

  private createUI() {
    const button1 = new Autodesk.Viewing.UI.Button('show-annotation-button');
    button1.onClick = (e) => this.createAnnotation();
    button1.addClass('show-annotation-button');
    button1.setToolTip('Show Annotations');
    button1.setIcon('material-icons');
    this.subToolbar = new Autodesk.Viewing.UI.ControlGroup('my-custom-view-toolbar');
    this.subToolbar.addControl(button1);
    this.viewer.toolbar.addControl(this.subToolbar);
  }

  createAnnotation() {
    SHOW_ANNOTATION_PANEL.next(true);
  }

  removeBtnsFromToolbar() {
    if (this.userRole === 'user') {
      this.viewer.toolbar.removeControl('modelTools');
    }
    // this.viewer.addEventListener(Autodesk.Viewing.EXTENSION_LOADED_EVENT, (e) => {
    //   const settingsTools = this.viewer.toolbar.getControl('settingsTools');
    //   settingsTools.removeControl('toolbar-modelStructureTool');
    //   settingsTools.removeControl('toolbar-propertiesTool');
    //   settingsTools.removeControl('toolbar-settingsTool');
    // });
  }

  ngOnDestroy() {}

}
