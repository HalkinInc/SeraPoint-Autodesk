const { ObjectId } = require("mongodb");
const jsonwebtoken = require("jsonwebtoken");
const config = require("config");

const tenants = [
    { "_id": ObjectId(), "name": "adminTenant", deleted: false },
    { "_id": ObjectId(), "name": "notAdminTenant", deleted: false },
    { "_id": ObjectId(), "name": "deletedTenant", deleted: true }
];

const dxfFiles = [
    { name: "adminTenantFile", tenantId: tenants[0]._id.toString(), deleted: false },
    { name: "notAdminTenantFile", tenantId: tenants[1]._id.toString(), deleted: false },
    { name: "notAdminTenantFile", tenantId: tenants[1]._id.toString(), deleted: true },
    { name: "test.dxf", tenantId: tenants[1]._id.toString(), deleted: false }
];

const users = [
    { _id: ObjectId(), email: "root@email.com", password: "password", role: "root", deleted: false, jwt: jsonwebtoken.sign({ email: "root@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "moderator@email.com", password: "password", role: "moderator", tenantId: tenants[0]._id.toString(), deleted: false, jwt: jsonwebtoken.sign({ email: "moderator@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "user@email.com", password: "password", role: "user", tenantId: tenants[0]._id.toString(), deleted: false, jwt: jsonwebtoken.sign({ email: "user@email.com", }, config.app.secret) }
];

module.exports = {
    tenants,
    dxfFiles,
    users
};