const { server, db } = require("../../../../server");
const { users, tenants } = require("./seeds");

before(async () => await (await db).dropDatabase());

after(() => server.close());

beforeEach(async () => {
    const dbConnection = await db;

    const userCollection = await dbConnection.collection("users");
    await userCollection.deleteMany({});
    await userCollection.insertMany(users);

    const tenantCollection = await dbConnection.collection("tenants");
    await tenantCollection.deleteMany({});
    await tenantCollection.insertMany(tenants);
});

describe("GET /user", () => require("./getUser.test"));

describe("PUT /user/:id/avatar", () => require("./putUserAvatarById.test"));

describe("GET /user/:id/avatar", () => require("./getUserAvatarById.test"));

describe("DELETE /user/:id/avatar", () => require("./deleteUserAvatarById.test"));

describe("GET /user/:id", () => require("./getUserById.test"));

describe("PATCH /user/:id", () => require("./patchUserById.test"));

describe("DELETE /user/:id", () => require("./deleteUserById.test"));

describe("POST /user", () => require("./postUser.test"));

describe("POST /user/:id/invitation", () => require("./sendInvitation.test"));

describe("POST /user/finish-registration", () => require("./finishRegistration.test"));

describe("POST /user/login", () => require("./userLogin.test"));

describe("POST /user/byJwt", () => require("./getUserByJwt.test"));

describe("GET /user/secret-question", () => require("./getSecretQuestion.test"));

describe("POST /user/sercret-answer", () => require("./postSecretAnswer.test"));

