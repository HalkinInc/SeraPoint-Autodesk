const request = require("supertest");
const expect = require("expect");
const jsonwebtoken = require("jsonwebtoken");
const config = require("config");

const { server } = require("../../../../server");
const { users } = require("./seeds");

it("error if token is not provided", async () => {
    const token = users[0].jwt;
    const body = {};

    const response = await request(server).post("/user/byJwt").set("Authorization", token).send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("'body' should have required property 'jwt'");

    expect(value).not.toBeDefined();
});

it("error if token is provided but invalid", async () => {
    const token = users[0].jwt;
    const body = { jwt: jsonwebtoken.sign("blabla", config.app.secret) };

    const response = await request(server).post("/user/byJwt").set("Authorization", token).send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Supplied token is invalid");

    expect(value).not.toBeDefined();
});

it("error if provided token is valid but user with such token not exists", async () => {
    const token = users[0].jwt;
    const body = { jwt: jsonwebtoken.sign({ email: "hello" }, config.app.secret) };

    const response = await request(server).post("/user/byJwt").set("Authorization", token).send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(1);
    expect(errors[0]).toBe("Supplied token is invalid");

    expect(value).not.toBeDefined();
});

it("return user if everything is ok", async () => {
    const token = users[0].jwt;
    const body = { jwt: users[0].jwt };

    const response = await request(server).post("/user/byJwt").set("Authorization", token).send(body);
    const { value, errors } = response.body;

    expect(errors.length).toBe(0);

    expect(value).toBeDefined();
});