import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UsersService } from '../../services/users.service';
import { DXFFilesService } from '../../services/dxffiles.service';
import { AnotationsService } from '../../services/anotations.service';
import { AutodeskService } from '../../services/autodesk.service';
import {
  ViewerOptions,
  ViewingApplicationInitializedEvent,
  DocumentChangedEvent,
  SelectionChangedEventArgs,
  Extension
} from 'ng2-adsk-forge-viewer';
import { Subject, ReplaySubject } from 'rxjs';
import { TestExtension, SHOW_ANNOTATION_PANEL, SELECT_BLOCK, SCREENSHOT, SPINNER, PERCENTS } from './test-extension';
import { DomSanitizer } from '@angular/platform-browser';
import { untilDestroyed } from 'ngx-take-until-destroy';
import { Annotation } from '../../models/annotation.model';
import { MarkupExt } from './markup-extension';
import { User } from '../../models/user.model';
export const USER_ROLE = new ReplaySubject();
export const SELECTED_ANNOTATION_BLOCK = new ReplaySubject();
export const PINED_BLOCK = new ReplaySubject();

@Component({
  selector: 'app-view-page',
  templateUrl: './view-page.component.html',
  styleUrls: ['./view-page.component.scss']
})
export class ViewPageComponent implements OnInit, OnDestroy {
  showAnnotation = false;
  dxfId: number;
  anotations: Array<Annotation> = new Array();
  filteredAnotations: Array<Annotation> = new Array();
  annotationName = '';
  annotationDescription = '';
  files: any;
  blockIndex = '';
  viewerOptions3d: ViewerOptions;
  urn: string;
  showAnnotationPanel: any;
  canEdit: boolean;
  annotationScreenshot: any;
  annotationUrl: any;
  selectedImage: any;
  showSpinner = true;
  percents: string;
  formSubmitted = false;
  currentUser: User = new User();

  constructor(private route: ActivatedRoute,
    private usersService: UsersService,
    private dxfFilesService: DXFFilesService,
    private anotationsService: AnotationsService,
    private autodeskService: AutodeskService,
    private sanitizer: DomSanitizer) {
      this.usersService.getUser()
        .subscribe(res => {
          this.currentUser = res['value'];
          if (res.value.role === 'root' || res.value.role === 'admin') {
            this.canEdit = true;
          }
          USER_ROLE.next(res.value.role);
        });
      this.dxfId = route.params['value'].id;
      if (route.params['value'].annotationId.length > 0 && route.params['value'].annotationId !== 'pure-dxf') {
        this.blockIndex = route.params['value'].annotationId;
        this.showAnnotationPanel = true;
      }
      this.getDXFFileById(this.dxfId);

      SCREENSHOT
        .pipe(untilDestroyed(this))
        .subscribe((res: any) => {
          this.annotationUrl = res;
          this.annotationScreenshot = this.sanitizer.bypassSecurityTrustUrl(res);
      });

      SHOW_ANNOTATION_PANEL
        .pipe(untilDestroyed(this))
        .subscribe((res) => {
          this.showAnnotationPanel = res;
          this.filteredAnotations = this.anotations;
      });

      SELECT_BLOCK
        .pipe(untilDestroyed(this))
        .subscribe((res) => {
          this.blockIndex = res['id'];
          this.showAnnotation = !!res;
          this.filteredAnotations = this.anotations.filter((anotation) => {
            return anotation.blockIndex === this.blockIndex;
          });
      });

      SPINNER
        .pipe(untilDestroyed(this))
        .subscribe((res: boolean) => {
          this.showSpinner = res;
      });

      PERCENTS
        .pipe(untilDestroyed(this))
        .subscribe((res: number) => {
          this.percents = `${res.toFixed(0)}%`;
      });
  }

  ngOnInit() {
    this.getAnnotation(this.dxfId);
    this.viewerOptions3d = {
      initializerOptions: {
        env: 'AutodeskProduction',
        getAccessToken: (onGetAccessToken: (token: string, expire: number) => void) => {
          this.autodeskService.authenticateAutodesk()
            .subscribe((result) => {
              const { access_token, expires_in } = result;
              onGetAccessToken(access_token, expires_in);
            });
        },
      },
      viewerConfig: {
        extensions: [TestExtension.extensionName, MarkupExt.extensionName],
        theme: 'bim-theme',
      },
      onViewerScriptsLoaded: this.scriptsLoaded,
      onViewingApplicationInitialized: (args: ViewingApplicationInitializedEvent) => {
        args.viewerComponent.DocumentId = this.urn;
      }
    };
  }

  public scriptsLoaded() {
    Extension.registerExtension(TestExtension.extensionName, TestExtension);
    Extension.registerExtension(MarkupExt.extensionName, MarkupExt);
  }

  public documentChanged(event: DocumentChangedEvent) {
    const viewerApp = event.viewingApplication;
    if (!viewerApp.bubble) {
      return;
    }
    const viewables = viewerApp.bubble.search({ type: 'geometry', role: '2d' });

    if (viewables && viewables.length > 0) {
      event.viewerComponent.selectItem(viewables[0].data);
    }
  }

  public selectionChanged(event: SelectionChangedEventArgs) {
    console.log('selectionChanged', event);
  }

  getAnnotation(id) {
    this.anotationsService.getAnnotation(id)
      .subscribe((res) => {
        if (res.value) {
          const pinArray = res.value.map((item) => {
            return item.blockIndex;
          });
          PINED_BLOCK.next(pinArray);
          this.getAnnotationScreenshot(res.value);
        }
      });
  }

  getDXFFileById(id) {
    this.dxfFilesService.getDXFFileById(id).subscribe((res) => {
      this.urn = res.value.urn.replace(/(urn:)(.*.file:)(.*)(\/output.*)/gm,
        (m, g1, g2, g3, g4) => {
          return `${g1}${g3}`;
        });
    });
  }

  ngOnDestroy() {
  }

  onCreateAnnotation() {
    this.formSubmitted = true;
    const files = this.files;

    fetch(this.annotationUrl)
      .then(res => res.blob())
      .then((blob) => {
        const screenshot = new Blob([blob], { type: 'image/png'});
        this.anotationsService.createAnnotation(
          this.annotationDescription, this.dxfId, this.annotationName, files, this.blockIndex, screenshot)
          .subscribe((res) => {
            if (res) {
              this.formSubmitted = false;
              this.files = undefined;
              this.annotationName = '';
              this.annotationDescription = '';
              this.anotations = [];
              this.getAnnotation(this.dxfId);
              this.showAnnotation = false;
            }
          });
      });
  }

  addFile(event) {
    const target = event.target || event.srcElement;
    this.files = target.files;
  }

  selectAnnotation(anotation) {
    SELECTED_ANNOTATION_BLOCK.next(anotation.blockIndex);
    // SELECTED_ANNOTATION_BLOCK.complete();
  }

  downloadAnnotation(annotation) {
    const responseType = this.checkResponseType(annotation.fileName);
    this.anotationsService.downloadAnotation(annotation._id).subscribe((res) => {
      if (res.value) {
        const datas = new Uint8Array(res.value.Body.data);
        const blob = new Blob([datas], {type: responseType});
        // if (/MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent) ||
        //  /Edge\/\d./i.test(navigator.userAgent) || /MSIE 10/i.test(navigator.userAgent)) {
        //   this.downloadForMicrosoftBrowsers(annotation, blob);
        // } else {
        //   const urlCreator = window.URL;
        //   const fileUrl = urlCreator.createObjectURL(blob);
        //   window.open(fileUrl);
        // }
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob, annotation.fileName);
        } else {
          const urlCreator = window.URL;
          const fileUrl = urlCreator.createObjectURL(blob);
          window.open(fileUrl);
        }
        annotation.downloadIcon = false;
      }
    });
  }

  // downloadForMicrosoftBrowsers(annotation, blob) {
  //   if (window.navigator && window.navigator.msSaveBlob) {
  //     window.navigator.msSaveOrOpenBlob(blob, annotation.fileName);
  //   } else {
  //     // In FF link must be added to DOM to be clicked
  //     const link = document.createElement('a');
  //     link.href = window.URL.createObjectURL(blob);
  //     link.setAttribute('download', annotation.fileName);
  //     document.body.appendChild(link);
  //     link.click();
  //     document.body.removeChild(link);
  //   }
  // }

  onDeleteAnnotation(annotation) {
    this.anotationsService.deleteAnnotation(annotation._id).subscribe((res) => {
      if (res.value) {
        this.anotations = [];
        this.getAnnotation(this.dxfId);
      }
    });
  }

  getAnnotationScreenshot(data) {
    data.filter(element => {
      this.anotationsService.getScreenshot(element._id).subscribe((res) => {
        if (res.value) {
          const datas = new Uint8Array(res.value.Body.data);
          const blob = new Blob([datas], {type: 'image/png'});
          const urlCreator = window.URL;
          element.editable = false;
          element.screenshotBlob = this.sanitizer.bypassSecurityTrustUrl(urlCreator.createObjectURL(blob));
        }
      });
      this.anotations.push(element);
    });
    if (this.blockIndex.length > 0) {
      this.filteredAnotations = this.anotations.filter((anotation) => {
        return anotation.blockIndex === this.blockIndex;
      });
    } else {
      this.filteredAnotations = this.anotations;
    }
  }

  checkBeforeUpdate(anotation) {
    delete anotation.editable;
    if (typeof this.files !== 'undefined') {
      this.updateAnnotation(anotation, this.files);
    } else {
      const file = anotation.fileName;
      const responseType = this.checkResponseType(file);
      this.anotationsService.downloadAnotation(anotation._id).subscribe((res) => {
        if (res.value) {
          const datas = new Uint8Array(res.value.Body.data);
          const blob = new Blob([datas], {type: responseType});
          const files = [new File([blob], anotation.fileName)];
          this.updateAnnotation(anotation, files);
        }
      });
    }
  }

  updateAnnotation(anotation, files) {
    this.anotationsService.updateAnnotation(anotation, files, this.selectedImage).subscribe((res) => {
      if (res.value) {
        this.anotations = [];
        this.selectedImage = null;
        this.getAnnotation(this.dxfId);
      }
    });
  }

  uploadScreenshot(event, anotation) {
    const target = event.target || event.srcElement;
    this.selectedImage = target.files[0];
    const urlCreator = window.URL;
    const imageUrl = this.sanitizer.bypassSecurityTrustUrl(urlCreator.createObjectURL(this.selectedImage));
    anotation.screenshotBlob = imageUrl;
  }

  checkResponseType(file: any) {
    const type = /[.]/.exec(file) ? /[^.]+$/.exec(file) : undefined;
    switch (type[0]) {
      case 'doc':
      case 'docx':
        return  'application/msword';
      case 'pdf':
        return 'application/pdf';
      case 'csv':
        return 'text/csv';
      case 'jpg':
      case 'jpeg':
        return 'image/jpeg';
      case 'png':
        return 'image/png';
      case 'gif':
        return 'image/gif';
      case 'bmp':
        return 'image/vnd.wap.wbmp';
      case 'tiff':
        return 'image/tiff';
    }
  }

  trackByFn(index, item) {
    return item.id;
  }
}
