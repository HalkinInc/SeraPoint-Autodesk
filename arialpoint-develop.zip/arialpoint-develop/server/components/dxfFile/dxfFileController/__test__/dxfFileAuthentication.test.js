const assert = require("assert");

const request = require("supertest");
const jsonwebtoken = require("jsonwebtoken");
const config = require("config");

const { server } = require("../../../../server");
const { dxfFiles } = require("./seeds");

it("error if token is not provided", async () => {
    const dxfFileId = dxfFiles[0]._id.toString();

    const response = await request(server).get(`/dxf-file/${dxfFileId}`);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Token is not provided");

    assert.strictEqual(value, undefined);
});

it("error if token is invalid", async () => {
    const token = jsonwebtoken.sign("blabla", config.app.secret);
    const dxfFileId = dxfFiles[0]._id.toString();

    const response = await request(server).get(`/dxf-file/${dxfFileId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Supplied token is invalid");

    assert.strictEqual(value, undefined);
});

it("error if user with provided token not exists", async () => {
    const token = jsonwebtoken.sign({ email: "notExists@email.com" }, config.app.secret);
    const dxfFileId = dxfFiles[0]._id.toString();

    const response = await request(server).get(`/dxf-file/${dxfFileId}`).set("authorization", token);
    const { errors, value } = response.body;

    assert.notStrictEqual(errors, undefined);
    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "Supplied token is invalid");

    assert.strictEqual(value, undefined);
});