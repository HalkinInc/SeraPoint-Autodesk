const assert = require("assert");

const request = require("supertest");

const { server } = require("../../../../server");
const { users, filters } = require("./filterController.test");
const FilterModel = require("../../filterModel");

it("error if filter is empty", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user/filter")
        .set("Authorization", users.firstUser.jwt);

    assert.strictEqual(errors.length, 1);
    assert.strictEqual(errors[0], "'body' should NOT have fewer than 1 properties");

    assert.strictEqual(value, undefined);
});

it("creates new filter", async () => {
    const { body: { value, errors } } = await request(server)
        .post("/user/filter")
        .set("Authorization", users.firstUser.jwt)
        .send({ title: "new filter" });

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value, true);

    const userFilter = await FilterModel.findMany({ creatorId: users.firstUser._id.toString() });
    assert.strictEqual(Object.values(filters).filter((f) => f.creatorId === users.firstUser._id.toString()).length + 1, userFilter.length);
});