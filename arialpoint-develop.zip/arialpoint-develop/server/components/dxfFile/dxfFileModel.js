const { ObjectId } = require("mongodb");

const createModel = require("../../db/createModel");

const DxfFileModel = createModel("dxffiles");
const LocalUserModel = createModel("users");
const LocalTenantModel = createModel("tenants");

DxfFileModel.enrichDxfFile = async (dxfFile) => {
    if (dxfFile === null) return dxfFile;

    const enrichedDxfFile = { ...dxfFile };

    const foundCreator = await LocalUserModel.findOne({ _id: ObjectId(dxfFile.creatorId) });
    if (foundCreator !== null) {
        enrichedDxfFile.creatorFirstname = foundCreator.firstname;
        enrichedDxfFile.creatorLastname = foundCreator.lastname;
    }

    const foundTenant = await LocalTenantModel.findOne({ _id: ObjectId(dxfFile.tenantId) });
    if (foundTenant !== null) enrichedDxfFile.tenantName = foundTenant.name;

    return enrichedDxfFile;
};

DxfFileModel.findAndEnrichOne = async function (query) {
    const foundOne = await this.findOne(query);
    return await this.enrichDxfFile(foundOne);
};

DxfFileModel.enrichDxfFiles = async function (dxfFiles) {
    return await Promise.all(dxfFiles.map((cur) => this.enrichDxfFile(cur)));
};

DxfFileModel.findAndEnrichMany = async function (query, limit = 0, skip = 0) {
    const foundMany = await this.findMany(query, limit, skip);
    return this.enrichDxfFiles(foundMany);
};

module.exports = DxfFileModel;
