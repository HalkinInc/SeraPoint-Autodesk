import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDxfDialogComponent } from './update-dxf-dialog.component';

describe('UpdateDxfDialogComponent', () => {
  let component: UpdateDxfDialogComponent;
  let fixture: ComponentFixture<UpdateDxfDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateDxfDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDxfDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
