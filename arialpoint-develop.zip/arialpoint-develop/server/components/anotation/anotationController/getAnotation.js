const AnotationService = require("../anotationService");
const DxfFileService = require("../../dxfFile/dxfFileService");
const TenantService = require("../../tenant/tenantService");
const UserService = require("../../user/userService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const getAnotation = async (req, res, next) => {
    try {
        let { authUser, query: { dxfFileId, creatorId, tenantId, deleted } } = req;

        deleted = deleted === "true";

        if (dxfFileId !== undefined) {
            const foundDxfFile = await DxfFileService.getDxfFileById(dxfFileId);
            if (authUser.permissions.includes("anotation:read:tenant") && authUser.tenantId !== foundDxfFile.tenantId) throw new appErrors.AuthorizationError();

            return res.send({ errors: [], value: await AnotationService.getDxfFileAnotations(dxfFileId, deleted) });
        }

        if (creatorId !== undefined) {
            const foundUser = await UserService.getUserById(creatorId);
            if (authUser.permissions.includes("anotation:read:tenant") && authUser.tenantId !== foundUser.tenantId) throw new appErrors.AuthorizationError();

            return res.send({ errors: [], value: await AnotationService.getCreatorAnotations(creatorId, deleted) });
        }

        if (tenantId !== undefined) {
            await TenantService.getTenantById(tenantId);

            return res.send({ errors: [], value: await AnotationService.getTenantAnotations(tenantId, deleted) });
        }

        return res.send({ errors: [], value: await AnotationService.getAllAnotations(deleted) });
    } catch (error) { return next(error); }

};

const getAnotationSchema = {
    query: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            dxfFileId: { type: "string", objectId: true },
            creatorId: { type: "string", objectId: true },
            tenantId: { type: "string", objectId: true },
            deleted: { type: "string", enum: ["true", "false"] }
        }
    }
};

module.exports = [
    authorization(["anotation:read:any", "anotation:read:tenant"]),
    requestValidation(getAnotationSchema),
    getAnotation
];