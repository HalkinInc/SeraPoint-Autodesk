import { Component } from '@angular/core';
import { UsersService } from '../../../services/users.service';
import { AnotationsService } from '../../../services/anotations.service';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { UpdateAnnotationComponent } from './update-annotation/update-annotation.component';
import { Annotation } from '../../../models/annotation.model';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-annotation-files',
  templateUrl: './annotation-files.component.html',
  styleUrls: ['./annotation-files.component.scss']
})
export class AnnotationFilesComponent {
  annotationSort = 'newest';
  annotationFiles: Array<Annotation> = new Array();
  filteredAnnotationFiles: Array<Annotation> = new Array();
  currentUser: User;
  selectedImage: File;
  allUsers: Array<User> = new Array();
  activeFilters = false;

  constructor(
    public dialog: MatDialog,
    private usersService: UsersService,
    private anotationsService: AnotationsService,
    private router: Router) {
      this.getUser();
    }

  getUser() {
    this.usersService.getUser().subscribe((res) => {
      this.currentUser = res.value;
      this.getUsers();
      this.getAnnotationFiles();
    });
  }

  getUsers() {
    let id = '';
    if (this.currentUser.role !== 'root' && this.currentUser.role !== 'admin') {
      id = this.currentUser.tenantId;
    }
    return this.usersService.getUsers(id)
      .subscribe((res) => {
        const result = res['value'];
        this.allUsers = result;
      });
  }

  getAnnotationFiles() {
    this.anotationsService.getAnnotationFiles(this.currentUser.tenantId).subscribe((res) => {
      if (res.value) {
        this.annotationFiles = res.value.sort((a, b) => {
          return <number>b.createdAt - <number>a.createdAt;
        });
        this.filteredAnnotationFiles = this.annotationFiles;
      }
    });
  }

  deleteAnnotation(id: string) {
    this.anotationsService.deleteAnnotation(id).subscribe((res) => {
      if (res.value) {
        this.getAnnotationFiles();
      }
    });
  }

  onDownload(annotation, id: string) {
    const responseType = this.checkResponseType(annotation.fileName);
    this.anotationsService.downloadAnotation(id).subscribe((res) => {
      if (res.value) {
        const datas = new Uint8Array(res.value.Body.data);
        const blob = new Blob([datas], {type: responseType});
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob, annotation.fileName);
        } else {
          const urlCreator = window.URL;
          const fileUrl = urlCreator.createObjectURL(blob);
          window.open(fileUrl);
        }
        annotation.downloadIcon = false;
      }
    });
  }

  checkResponseType(file: any) {
    const type = /[.]/.exec(file) ? /[^.]+$/.exec(file) : undefined;
    switch (type[0]) {
      case 'doc':
      case 'docx':
        return  'application/msword';
      case 'pdf':
        return 'application/pdf';
      case 'csv':
        return 'text/csv';
      case 'jpg':
      case 'jpeg':
        return 'image/jpeg';
      case 'png':
        return 'image/png';
      case 'gif':
        return 'image/gif';
      case 'bmp':
        return 'image/vnd.wap.wbmp';
      case 'tiff':
        return 'image/tiff';
    }
  }

  get changeAnotationList() {
    switch (this.annotationSort) {
      case 'newest':
        return this.filteredAnnotationFiles = this.annotationFiles.sort((a, b) => {
          return <number>b.createdAt - <number>a.createdAt;
        });
      case 'oldest':
        return this.filteredAnnotationFiles = this.annotationFiles.sort((a, b) => {
          return <number>a.createdAt - <number>b.createdAt;
        });
      case 'name':
        return this.filteredAnnotationFiles = this.annotationFiles.sort((a, b) => {
          const nameA = a.name.toLowerCase();
          const nameB = b.name.toLowerCase();
          if (nameA < nameB) {
            return -1;
          } else if (nameA > nameB) {
            return 1;
          } else {
            return 0;
          }
        });
      case 'size':
        return this.filteredAnnotationFiles = this.annotationFiles.sort((a, b) => {
          return <number>b.fileSize - <number>a.fileSize;
        });
    }
  }

  previewDXF(id: string, annotationId: string = 'pure-dxf') {
    this.router.navigateByUrl(`/view-page/${id}/${annotationId}`);
  }

  onUpdate(annotation: Annotation) {
    const dialogRef = this.dialog.open(UpdateAnnotationComponent, {
      width: '685px',
      data: annotation
    });

    dialogRef.afterClosed().subscribe((result) => {
      const updatedAnnotation = annotation;
      updatedAnnotation.name = result.name;
      updatedAnnotation.text = result.text;
      this.anotationsService.updateAnnotation(updatedAnnotation, result.file, this.selectedImage).subscribe((res) => {
        this.getAnnotationFiles();
      });
    });
  }

  onChanged(event) {
    let filteredList;
    if (event.users.length > 0) {
      event.users.filter((user) => {
        filteredList = this.annotationFiles.filter((item) => {
          if (`${(item.creatorFirstname).toLowerCase()} ${(item.creatorLastname).toLowerCase()}` === user) {
            return item;
          }
        });
      });
      if (filteredList[0] === undefined) {
        filteredList = [];
      }
    } else {
      filteredList = this.annotationFiles;
    }
    const now = new Date();
    const dd = now.getDate();
    const mm = now.getMonth();
    const yyyy = now.getFullYear();
    const today = new Date(yyyy, mm, dd, 0, 0, 0);
    const todayUTC = today.getTime();
    const yesterday = new Date(yyyy, mm, dd - 1, 0, 0, 0);
    const thisMonth = new Date(yyyy, mm, 1, 0, 0, 0);
    const lastMonth = new Date(yyyy, mm - 1, 1, 0, 0, 0);
    const last3Month = new Date(yyyy, mm - 3, 1, 0, 0, 0);
    switch (event.date) {
      case 'anytime':
        this.filteredAnnotationFiles = filteredList;
        break;
      case 'yesterday':
        this.filteredAnnotationFiles = filteredList.filter((item) => {
          if (item.createdAt < todayUTC && item.createdAt > yesterday.getTime()) {
            return item;
          }
          return;
        });
        break;
      case 'today':
        this.filteredAnnotationFiles = filteredList.filter((item) => {
          if (item.createdAt > todayUTC) {
            return item;
          }
          return;
        });
        break;
      case 'thisWeek':
        this.filteredAnnotationFiles = filteredList.filter((item) => {
          if (item.createdAt > today.setDate(today.getDate() - (today.getDay() + 6) % 7)) {
            return item;
          }
          return;
        });
        break;
      case 'lastWeek':
        this.filteredAnnotationFiles = filteredList.filter((item) => {
          if (item.createdAt > today.setDate(today.getDate() - (today.getDay() + 6) % 14)) {
            return item;
          }
          return;
        });
        break;
      case 'thisMonth':
        this.filteredAnnotationFiles = filteredList.filter((item) => {
          if (item.createdAt > thisMonth.getTime()) {
            return item;
          }
          return;
        });
        break;
      case 'lastMonth':
        this.filteredAnnotationFiles = filteredList.filter((item) => {
          if (item.createdAt > lastMonth.getTime()) {
            return item;
          }
          return;
        });
        break;
      case 'last3Month':
        this.filteredAnnotationFiles = filteredList.filter((item) => {
          if (item.createdAt > last3Month.getTime()) {
            return item;
          }
          return;
        });
        break;
    }
  }

  trackByFn(index, item) {
    return item.id;
  }
}
