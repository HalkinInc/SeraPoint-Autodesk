const assert = require("assert");

const request = require("supertest");
const { server } = require("../../../../server");
const { users, filters } = require("./filterController.test");


it("returns all filters of authenticated user", async () => {
    const { body: { value, errors } } = await request(server)
        .get("/user/filter")
        .set("Authorization", users.firstUser.jwt);

    assert.strictEqual(errors.length, 0);

    assert.strictEqual(value.length, Object.values(filters).filter((f) => f.creatorId === users.firstUser._id.toString()).length);
});