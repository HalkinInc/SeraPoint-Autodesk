import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UsersService } from '../../services/users.service';
import { UserRegistrationFormGroup } from '../../models/user-registration-form.model';
import secretQuestions from '../../consts/secretQuestions';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.scss']
})
export class UserRegistrationComponent {
    userRegistrationForm: UserRegistrationFormGroup = new UserRegistrationFormGroup();
    formSubmitted = false;
    options: Array<string> = secretQuestions;
    hide = true;

    constructor(private route: ActivatedRoute,
        private usersService: UsersService,
        private router: Router) {}

    onSubmit(form: NgForm) {
        this.formSubmitted = true;
        if (form.valid) {
            const data = Object.assign(form.value);
            data['secretQuestionId'] = this.options.indexOf(form.value.secretQuestionId);
            this.usersService.finishRegistration(this.route.queryParams['value'].code, data)
                .subscribe((res) => {
                        this.router.navigateByUrl('/login');
                        form.reset();
                        this.formSubmitted = false;
                    }
                );
        }
    }
}
