const TenantService = require("../tenantService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const patchTenantById = async (req, res, next) => {
    try {
        const { authUser, params: { id }, body: { name, deleted } } = req;
        if (deleted === false) await TenantService.unflagTenantAsDeleted(id);

        if (authUser.permissions.includes("tenant:update:tenant") && authUser.tenantId !== id) throw new appErrors.AuthorizationError();

        if (name !== undefined) await TenantService.renameTenant(id, name);

        return res.send({ errors: [], value: true });
    } catch (error) { return next(error); }
};

const patchTenantByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true },
        }
    },
    body: {
        type: "object",
        required: [],
        additionalProperties: false,
        properties: {
            name: { type: "string" },
            deleted: { type: "boolean" }
        }
    }
};

module.exports = [
    authorization(["tenant:update:any", "tenant:update:tenant"]),
    requestValidation(patchTenantByIdSchema),
    patchTenantById
];