module.exports = {
    getUser: require("./getUser"),
    getUserById: require("./getUserById"),
    getUserByJwt: require("./getUserByJwt"),
    patchUserById: require("./patchUserById"),
    deleteUserById: require("./deleteUserById"),
    postUser: require("./postUser"),

    putUserAvatarById: require("./putUserAvatarById"),
    getUserAvatarById: require("./getUserAvatarById"),
    deleteUserAvatarById: require("./deleteUserAvatarById"),

    sendInvitation: require("./sendInvitation"),
    finishRegistration: require("./finishRegistration"),

    userLogin: require("./userLogin"),

    getSecretQuestion: require("./getSecretQuestion"),
    postSecretAnswer: require("./postSecretAnswer"),
};