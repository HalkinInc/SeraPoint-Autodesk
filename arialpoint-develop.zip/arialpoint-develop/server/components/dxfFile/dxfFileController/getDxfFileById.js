const DxfFileService = require("../dxfFileService");
const requestValidation = require("../../../middleware/requestValidation");
const authorization = require("../../../middleware/authorization");
const appErrors = require("../../../utils/appErrors");

const getDxfFileById = async (req, res, next) => {
    try {
        const { authUser, params: { id } } = req;

        const foundFile = await DxfFileService.getDxfFileById(id);

        if (authUser.permissions.includes("dxf-file:read:tenant") && authUser.tenantId !== foundFile.tenantId.toString()) throw new appErrors.AuthorizationError();

        return res.send({ errors: [], value: foundFile });
    } catch (error) { return next(error); }
};

const getDxfFileByIdSchema = {
    params: {
        type: "object",
        required: ["id"],
        additionalProperties: false,
        properties: {
            id: { type: "string", objectId: true }
        }
    }
};

module.exports = [
    authorization(["dxf-file:read:any", "dxf-file:read:tenant"]),
    requestValidation(getDxfFileByIdSchema),
    getDxfFileById
];