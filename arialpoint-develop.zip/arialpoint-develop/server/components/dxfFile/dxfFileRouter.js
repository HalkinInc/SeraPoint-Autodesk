const { Router } = require("express");

const authentication = require("../../middleware/authentication");
const dxfFileController = require("./dxfFileController/dxfFilController");

const dxfFileRouter = new Router();

dxfFileRouter.use(authentication());

dxfFileRouter.post("/dxf-file", dxfFileController.postDxfFile);
dxfFileRouter.get("/dxf-file", dxfFileController.getDxfFile);
dxfFileRouter.get("/dxf-file/:id", dxfFileController.getDxfFileById);
dxfFileRouter.patch("/dxf-file/:id", dxfFileController.patchDxfFileById);
dxfFileRouter.delete("/dxf-file/:id", dxfFileController.deleteDxfFileById);
dxfFileRouter.get("/authenticate-autodesk", dxfFileController.authenticateAutodesk);
dxfFileRouter.post("/autodesk", dxfFileController.autodesk);

module.exports = dxfFileRouter;