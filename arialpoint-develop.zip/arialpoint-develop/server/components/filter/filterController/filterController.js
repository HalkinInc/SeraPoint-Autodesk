module.exports = {
    getFilter: require("./getFilter"),
    postFilter: require("./postFilter"),
    patchFilterById: require("./patchFilterById"),
    deleteFilterById: require("./deleteFilterById")
};