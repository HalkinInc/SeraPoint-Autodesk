const { ObjectId } = require("mongodb");
const jsonwebtoken = require("jsonwebtoken");
const config = require("config");

const tenants = [
    { "_id": ObjectId(), "name": "adminTenant", },
    { "_id": ObjectId(), "name": "notAdminTenant", }
];

const users = [
    { _id: ObjectId(), email: "root@email.com", password: "$2a$10$ZNADAf5Er2kyUlMCF9gCGO.MUQhLCIsyBv231AbGfjw6PkAU9zs9m", role: "root", deleted: false, jwt: jsonwebtoken.sign({ email: "root@email.com", }, config.app.secret), avatar: "avatar.png" },
    { _id: ObjectId(), email: "moderator@email.com", password: "password", role: "moderator", tenantId: tenants[0]._id.toString(), secretQuestionId: 0, secretQuestionAnswer: "correct", deleted: false, jwt: jsonwebtoken.sign({ email: "moderator@email.com", }, config.app.secret), avatar: "avatar.png" },
    { _id: ObjectId(), email: "deleted@email.com", password: "password", role: "user", deleted: true, jwt: jsonwebtoken.sign({ email: "deleted@email.com", }, config.app.secret), avatar: "avatar.png" },
    { _id: ObjectId(), email: "user@email.com", password: "password", role: "user", tenantId: tenants[0]._id.toString(), deleted: false, jwt: jsonwebtoken.sign({ email: "user@email.com", }, config.app.secret), avatar: "avatar.png" },
    { _id: ObjectId(), email: "registrationIsNotFinished@email.com", role: "user", finishRegistrationCode: "correctCode", deleted: false, avatar: "avatar.png" },
    { _id: ObjectId(), email: "adminTenantUser@email.com", password: "password", role: "user", tenantId: tenants[0]._id.toString(), deleted: false, jwt: jsonwebtoken.sign({ email: "adminTenantUser@email.com", }, config.app.secret), avatar: "avatar.png" },
    { _id: ObjectId(), email: "anotherAdmin@email.com", password: "password", role: "moderator", deleted: false, jwt: jsonwebtoken.sign({ email: "anotherAdmin@email.com", }, config.app.secret), avatar: "avatar.png" },
    { _id: ObjectId(), email: "anotherUser@email.com", password: "password", role: "user", tenantName: "AnotherUserTenant", deleted: false, jwt: jsonwebtoken.sign({ email: "anotherUser@email.com", }, config.app.secret) },
    { _id: ObjectId(), email: "newAdmin@email.com", password: "password", role: "user", tenantId: tenants[0]._id.toString(), deleted: false, jwt: jsonwebtoken.sign({ email: "newAdmin@email.com", }, config.app.secret), avatar: "avatar.png" },
    { _id: ObjectId(), email: "adminUserNotFinishedRegistration@email.com", password: "password", role: "user", tenantId: tenants[0]._id.toString(), deleted: false, jwt: jsonwebtoken.sign({ email: "adminUserNotFinishedRegistration@email.com", }, config.app.secret), avatar: "avatar.png" },
    { _id: ObjectId(), email: "admin@email.com", password: "$2a$10$ZNADAf5Er2kyUlMCF9gCGO.MUQhLCIsyBv231AbGfjw6PkAU9zs9m", role: "admin", deleted: false, jwt: jsonwebtoken.sign({ email: "admin@email.com", }, config.app.secret), avatar: "avatar.png" },

];

module.exports = {
    tenants,
    users
};