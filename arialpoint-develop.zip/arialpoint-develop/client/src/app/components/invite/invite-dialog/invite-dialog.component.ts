import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, NgForm } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatStepper } from '@angular/material';
import { DialogData } from '../../../models/dialog-data.model';
import { User } from '../../../models/user.model';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-invite-dialog',
  templateUrl: './invite-dialog.component.html',
  styleUrls: ['./invite-dialog.component.scss']
})
export class InviteDialogComponent implements OnInit {
  user: User;
  isLinear = true;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  dialogResult: DialogData;
  formSubmitted = false;
  @ViewChild('stepper') stepper: MatStepper;

  myKeyup() {
    if (this.user.role !== 'moderator' && this.firstFormGroup.controls['roleCtrl'].value !== 'admin') {
      const emailField = this.firstFormGroup.controls['emailCtrl'].value;
      if (emailField) {
        const parseStr = emailField.split('@');
        if (parseStr && parseStr.length > 1) {
          const correctStr = parseStr[1].split('.');
          this.firstFormGroup.controls['tenantCtrl'].setValue(`${correctStr[0]}`);
        }
      }
    }
  }

  constructor(
    private _formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<InviteDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) {
    this.user = data['user'];
  }

  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['',
       Validators.compose([
         Validators.required,
         Validators.pattern('[A-Za-z\-]*'),
         Validators.minLength(1),
         Validators.maxLength(64)
      ])],
      lastCtrl: ['',
        Validators.compose([
          Validators.required,
          Validators.pattern('[A-Za-z\-]*'),
          Validators.minLength(1),
          Validators.maxLength(64)
      ])],
      emailCtrl: ['',
        Validators.compose([
          Validators.required,
          Validators.email,
          Validators.pattern('[0-Za-z\-._@]*'),
        ])
      ],
      tenantCtrl: [{value: this.data.tenant, disabled: this.user.role === 'moderator'}],
      roleCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      textareaCtrl: ['', Validators.required]
    });

    this.firstFormGroup.controls['firstCtrl'].setValue(this.data.firstName);
    this.firstFormGroup.controls['lastCtrl'].setValue(this.data.lastName);
    this.firstFormGroup.controls['emailCtrl'].setValue(this.data.email);
    this.firstFormGroup.controls['tenantCtrl'].setValue(this.data.tenant);
    this.firstFormGroup.controls['roleCtrl'].setValue(this.data.role || this.user.role === 'moderator' ? 'user' : '');
    this.secondFormGroup.controls['textareaCtrl'].setValue(this.data.message);
  }

  checkAndNavigateToNextStep(form: NgForm) {
    this.firstFormGroup.valueChanges.pipe(first()).subscribe(checked => {
      if (checked.roleCtrl === 'admin') {
        this.firstFormGroup.controls['tenantCtrl'].setValidators(null);
        this.firstFormGroup.get('tenantCtrl').clearValidators();
      } else if (checked.roleCtrl === 'moderator' || checked.roleCtrl === 'user') {
        this.firstFormGroup.get('tenantCtrl').setValidators([Validators.required, Validators.minLength(2)]);
      }
      this.firstFormGroup.get('tenantCtrl').updateValueAndValidity();
    });
    this.formSubmitted = true;
    if (form.valid) {
      this.stepper.next();
    }
  }

  submit(): void {
    this.dialogResult = {
      firstName: this.firstFormGroup.controls['firstCtrl'].value,
      lastName: this.firstFormGroup.controls['lastCtrl'].value,
      email: this.firstFormGroup.controls['emailCtrl'].value,
      tenant: this.firstFormGroup.controls['tenantCtrl'].value,
      role: this.firstFormGroup.controls['roleCtrl'].value,
      message: this.secondFormGroup.controls['textareaCtrl'].value
    };

    this.dialogRef.close(this.dialogResult);
  }

  getFormValidationMessages(state: any, thingName?: string) {
    const messages: string[] = [];
    if (state.errors) {
      Object.keys(state.errors).forEach(errorName => {
        switch (errorName) {
          case 'required':
            messages.push(`You must enter a ${thingName}`);
            break;
          case 'minlength':
            messages.push(`A ${thingName} must be aleast ${state.errors['minlength'].requiredLength} characters`);
            break;
          case 'pattern':
            messages.push(`The ${thingName} contains illegal characters`);
            break;
        }
      });
    }
    return messages;
  }
}
