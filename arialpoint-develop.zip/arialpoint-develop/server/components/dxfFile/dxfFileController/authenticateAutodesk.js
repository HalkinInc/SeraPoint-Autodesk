const config = require("config");
const axios = require("axios");

const requestValidation = require("../../../middleware/requestValidation");

const authenticateAutodesk = async (req, res, next) => {
    try {
        const { data: credentials } = await axios.post(
            "https://developer.api.autodesk.com/authentication/v1/authenticate",
            `client_id=${config.forge.clientId}&client_secret=${config.forge.clientSecret}&grant_type=client_credentials&scope=${["data:read", "viewables:read"].join(" ")}`,
            { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
        );

        return res.send(credentials);
    } catch (error) { return next(error); }
};

const authenticateAutodeskSchema = {};

module.exports = [
    requestValidation(authenticateAutodeskSchema),
    authenticateAutodesk
];