import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { UsersService } from '../../../services/users.service';
import { SettingsService } from '../../../services/settings.service';
import { Tenant } from '../../../models/tenant.model';
import { TenantsService } from '../../../services/tenants.service';

@Component({
  selector: 'app-delete-tenant',
  templateUrl: './delete-tenant.component.html',
  styleUrls: ['./delete-tenant.component.scss']
})
export class DeleteTenantComponent implements OnInit {
  deleteTenants: Array<any> = new Array();
  searchTenant: string;
  tenantId: string;
  daysToDelete = 30;
  currentUserRole: string;

  constructor(
    private location: Location,
    private usersService: UsersService,
    private settingsService: SettingsService,
    private tenantService: TenantsService) { }

  ngOnInit() {
    this.getUser();
  }

  getUser() {
    this.usersService.getUser().subscribe((res) => {
      if (res.value.tenantId) {
        this.tenantId = res.value.tenantId;
      }
      this.currentUserRole = res.value.role;
      // this.getSettings();
      this.getTenants();
    });
  }

  getSettings() {
    this.settingsService.getSettings().subscribe((result) => {
      if (result.value) {
        this.daysToDelete = result.value.deletedUsersDaysLimit;
      }
    });
  }

  back() {
    this.location.back();
  }

  getTenants(search?: string) {
    this.tenantService.getDeletedTenants()
      .subscribe((res) => {
        let result = res.value;
        result.map(element => {
          element['select'] = false;
        });
        if (search) {
          search = search.toLowerCase();
          result = result.filter((item) => {
            return item ? (item.firstname.toLowerCase().indexOf(search) >= 0 || item.lastname.toLowerCase().indexOf(search) >= 0) : false;
          });
        }
        this.deleteTenants = result;
      });
  }

  search(search: string) {
    this.getTenants(search);
  }

  onRestoreSelect() {
    const selectedTenant = this.deleteTenants.filter((file) => {
      return file.select;
    });
    if (selectedTenant.length > 0) {
      selectedTenant.filter((element) => {
        this.tenantService.editTenant(element._id, { deleted: false }).subscribe((res) => {
          if (res.value) {
            this.getTenants();
          }
        });
      });
    }
  }

  onDeleteTenant() {
    const selectedTenant = this.deleteTenants.filter((user) => {
      return user.select;
    });
    if (selectedTenant.length > 0) {
      selectedTenant.filter((selectTenant) => {
        this.tenantService.deleteTenantForever(selectTenant._id)
          .subscribe((res) => {
            this.getTenants();
          });
      });
    }
  }
}
