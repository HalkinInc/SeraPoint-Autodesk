## First setup

Copy `.env.sample` and rename to `.env`

## Run development environment:
npm run dev -- --detach

## Run test environment:
npm run test

## Run production with https
npm run prod:ssl -- --detach

## Execute E2E tests locally:
cd client
npm start
npm run protractor

## Execute E2E test inside container (`npm run test` should working):
docker exec aerialpoint-dev-client npm run e2e

## Execute server tests (`npm run test` should working):
docker exec aerialpoint-dev-server npm run test-watch

## Watch server docker service logs:
docker logs -f aerialpoint-dev-server

## Watch server logs:
docker exec aerialpoint-dev-server npm run logs

